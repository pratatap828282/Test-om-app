package com.ominvesting.control

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

enum class TradingMode { NORMAL, MEDIUM, BOOST }

data class ControlState(val enabled: Boolean = false, val mode: TradingMode = TradingMode.NORMAL)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ControlScreen() }
    }
}

@Composable
private fun ControlScreen() {
    var state by rememberSaveable { mutableStateOf(ControlState()) }
    MaterialTheme {
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("OM Investing Control", style = MaterialTheme.typography.headlineSmall)
            Text(if (state.enabled) "BOT: ON" else "BOT: OFF")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { state = state.copy(enabled = !state.enabled) }) { Text(if (state.enabled) "Turn OFF" else "Turn ON") }
            }
            TradingMode.values().forEach { mode ->
                OutlinedButton(onClick = { state = state.copy(mode = mode) }, enabled = state.mode != mode) { Text(mode.name) }
            }
            Text("Broker session: captured from authenticated connector")
            Text("Live activation requires external evidence and reconciliation.")
        }
    }
}
