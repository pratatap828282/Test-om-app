package com.ominvesting.control

import org.junit.Assert.assertEquals
import org.junit.Test

class ControlStateTest {
    @Test fun defaults_are_safe() { assertEquals(ControlState(false, TradingMode.NORMAL), ControlState()) }
    @Test fun modes_are_locked_to_known_values() { assertEquals(3, TradingMode.values().size) }
}
