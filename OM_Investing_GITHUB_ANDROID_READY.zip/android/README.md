# OM Investing Android Control — Fresh Combined Build

This Android module is newly generated from the locked Master Target requirements; legacy Android source is not used as an implementation input.

The module provides the initial deploy-control shell for adaptive Compose UI, Bot ON/OFF, NORMAL/MEDIUM/BOOST selection, and broker-session capture status. Financial authority remains server-side; live activation requires external evidence and reconciliation.

APK build requires a real Android SDK + Gradle/AGP toolchain. This environment does not currently expose that toolchain, so no APK is claimed as built here.
