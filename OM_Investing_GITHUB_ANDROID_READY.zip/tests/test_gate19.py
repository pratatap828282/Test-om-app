import pytest

from backend.core.completeness import MasterTargetCompletenessGate
from backend.core.master_contract import MASTER_CONTRACT, TradingMode


def test_gate19_complete_master_target_baseline():
    report = MasterTargetCompletenessGate().evaluate()
    assert report.passed
    assert report.missing == ()


def test_target_marker():
    assert MASTER_CONTRACT.target == "S1 → $1T"


def test_live_and_analysis_scope_markers():
    assert MASTER_CONTRACT.live_symbol == "XAUUSD"
    assert "DXY" in MASTER_CONTRACT.analysis_only_symbols


def test_risk_marker_is_immutable():
    assert MASTER_CONTRACT.absolute_trade_risk_cap == 0.0020


def test_all_required_modes_exist():
    assert set(TradingMode) == {TradingMode.NORMAL, TradingMode.MEDIUM, TradingMode.BOOST}


def test_treasury_contract_is_90_10():
    assert MASTER_CONTRACT.treasury_pct == 0.90
    assert MASTER_CONTRACT.operating_reserve_pct == 0.10


def test_plan_b_server_hierarchy_marker():
    assert MASTER_CONTRACT.server_priority == ("Singapore", "Germany", "Asia", "USA", "India")


def test_required_marker_set_is_explicit():
    assert set(MasterTargetCompletenessGate.REQUIRED_MARKERS) == {
        "S1 → $1T", "XAUUSD", "DXY_ANALYSIS_ONLY", "RISK_CAP_0.20%",
        "MODES_NORMAL_MEDIUM_BOOST", "SAFE_MODE", "TREASURY_90_RESERVE_10",
        "PLAN_B_FAILOVER", "HINDI_ENGLISH"
    }
