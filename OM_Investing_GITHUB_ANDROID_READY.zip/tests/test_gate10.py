from backend.strategy.decision_engine import DecisionEngine, DecisionInput
from backend.strategy.market_contract import MarketAnalysisContract
from backend.strategy.decision_contract import Side
from backend.core.master_contract import TradingMode
from decimal import Decimal
import pytest
from backend.broker.contract import BrokerSnapshot, BrokerSubmission, BrokerBoundaryError
from backend.broker.coordinator import BrokerExecutionCoordinator


def snap(**kw):
    base=dict(account_id="acct", equity=Decimal("1000"), connected=True, reconciled=True, open_order_ids=frozenset())
    base.update(kw); return BrokerSnapshot(**base)

def order(cid="o10"):
    return BrokerSubmission(cid, "XAUUSD", "BUY", Decimal("0.01"))

def test_valid_reconciled_snapshot_allows_xauusd_submission():
    c=BrokerExecutionCoordinator(); assert c.submit(snap(), order(), auth_seal()) == "o10"

def test_disconnected_broker_blocks():
    with pytest.raises(BrokerBoundaryError): BrokerExecutionCoordinator().submit(snap(connected=False), order(), auth_seal())

def test_unreconciled_broker_blocks():
    with pytest.raises(BrokerBoundaryError): BrokerExecutionCoordinator().submit(snap(reconciled=False), order(), auth_seal())

def test_missing_account_identity_blocks():
    with pytest.raises(BrokerBoundaryError): BrokerExecutionCoordinator().submit(snap(account_id=""), order(), auth_seal())

def test_invalid_equity_blocks():
    with pytest.raises(BrokerBoundaryError): BrokerExecutionCoordinator().submit(snap(equity=Decimal("-1")), order(), auth_seal())

def test_existing_broker_order_id_blocks_duplicate():
    with pytest.raises(BrokerBoundaryError): BrokerExecutionCoordinator().submit(snap(open_order_ids=frozenset({"o10"})), order(), auth_seal())

def test_local_duplicate_submission_blocks():
    c=BrokerExecutionCoordinator(); c.submit(snap(), order(), auth_seal())
    with pytest.raises(BrokerBoundaryError): c.submit(snap(), order(), auth_seal())

def test_dxy_live_submission_blocks():
    bad=BrokerSubmission("o11", "DXY", "BUY", Decimal("0.01"))
    with pytest.raises(BrokerBoundaryError): BrokerExecutionCoordinator().submit(snap(), bad, auth_seal())

def test_invalid_side_blocks():
    bad=BrokerSubmission("o12", "XAUUSD", "HOLD", Decimal("0.01"))
    with pytest.raises(BrokerBoundaryError): BrokerExecutionCoordinator().submit(snap(), bad, auth_seal())

def test_nonpositive_quantity_blocks():
    bad=BrokerSubmission("o13", "XAUUSD", "SELL", Decimal("0"))
    with pytest.raises(BrokerBoundaryError): BrokerExecutionCoordinator().submit(snap(), bad, auth_seal())


def auth_seal():
    return DecisionEngine().authorize(DecisionInput(
        MarketAnalysisContract("XAUUSD", "M5", trend="bullish"), Side.BUY,
        TradingMode.NORMAL, True, True, 0.001, 0.2, True))
