import pytest
from backend.execution.close_authority import CloseRequest
from backend.execution.close_execution_guard import CloseExecutionBlocked, ClosePositionSnapshot, ReconciledCloseGuard
from backend.execution.lifecycle import OrderLifecycle


def funded_lifecycle():
    x = OrderLifecycle("c-49")
    x.submit_started(); x.broker_acknowledged("b-49"); x.filled()
    return x


def snap(**kw):
    base = dict(client_order_id="c-49", broker_order_id="b-49", position_open=True, reconciled=True)
    base.update(kw)
    return ClosePositionSnapshot(**base)


def test_reconciled_close_uses_original_position():
    x = funded_lifecycle()
    out = ReconciledCloseGuard().close(x, CloseRequest("c-49", "b-49"), snap())
    assert out == "c-49"
    assert x.record.state.value == "CLOSED"


def test_unreconciled_close_blocked():
    with pytest.raises(CloseExecutionBlocked):
        ReconciledCloseGuard().close(funded_lifecycle(), CloseRequest("c-49", "b-49"), snap(reconciled=False))


def test_non_open_position_blocked():
    with pytest.raises(CloseExecutionBlocked):
        ReconciledCloseGuard().close(funded_lifecycle(), CloseRequest("c-49", "b-49"), snap(position_open=False))

@pytest.mark.parametrize("field,value", [("client_order_id", "other"), ("broker_order_id", "other")])
def test_snapshot_identity_mismatch_blocked(field, value):
    with pytest.raises(CloseExecutionBlocked):
        ReconciledCloseGuard().close(funded_lifecycle(), CloseRequest("c-49", "b-49"), snap(**{field:value}))

@pytest.mark.parametrize("req", [CloseRequest("other", "b-49"), CloseRequest("c-49", "other")])
def test_request_identity_mismatch_blocked(req):
    with pytest.raises(CloseExecutionBlocked):
        ReconciledCloseGuard().close(funded_lifecycle(), req, snap())


def test_cannot_close_new_trade():
    with pytest.raises(CloseExecutionBlocked):
        ReconciledCloseGuard().close(OrderLifecycle("c-49"), CloseRequest("c-49", "b-49"), snap())
