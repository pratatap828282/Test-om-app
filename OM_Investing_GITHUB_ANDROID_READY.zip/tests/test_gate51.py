import pytest

from backend.execution.close_authority import CloseRequest
from backend.execution.close_confirmation import CloseConfirmation, BrokerConfirmedClose, CloseConfirmationBlocked
from backend.execution.close_execution_guard import ClosePositionSnapshot
from backend.execution.lifecycle import OrderLifecycle


def exiting(cid="c-51", bid="b-51"):
    x = OrderLifecycle(cid)
    x.submit_started(); x.broker_acknowledged(bid); x.filled(); x.begin_exit()
    return x


def evidence(cid="c-51", bid="b-51", **kw):
    base = dict(client_order_id=cid, broker_order_id=bid, position_open=False, reconciled=True)
    base.update(kw)
    return CloseConfirmation(**base)


def test_close_requires_broker_confirmed_closed_position():
    x = exiting(); r = CloseRequest("c-51", "b-51")
    assert BrokerConfirmedClose().confirm(x, r, evidence()) == "c-51"
    assert x.record.state.value == "CLOSED"


@pytest.mark.parametrize("changes", [
    {"reconciled": False},
    {"position_open": True},
    {"client_order_id": "other"},
    {"broker_order_id": "other"},
])
def test_invalid_broker_confirmation_fails_closed(changes):
    x = exiting(); r = CloseRequest("c-51", "b-51")
    with pytest.raises(CloseConfirmationBlocked):
        BrokerConfirmedClose().confirm(x, r, evidence(**changes))
    assert x.record.state.value == "EXITING"


def test_confirmation_cannot_close_from_filled_state():
    x = OrderLifecycle("c-51")
    x.submit_started(); x.broker_acknowledged("b-51"); x.filled()
    with pytest.raises(CloseConfirmationBlocked):
        BrokerConfirmedClose().confirm(x, CloseRequest("c-51", "b-51"), evidence())


def test_request_identity_is_also_bound_to_original_trade():
    x = exiting()
    with pytest.raises(CloseConfirmationBlocked):
        BrokerConfirmedClose().confirm(x, CloseRequest("other", "b-51"), evidence())
    assert x.record.state.value == "EXITING"


def test_confirmation_does_not_create_new_trade_identity():
    x = exiting()
    BrokerConfirmedClose().confirm(x, CloseRequest("c-51", "b-51"), evidence())
    assert x.record.client_order_id == "c-51"
    assert x.record.broker_order_id == "b-51"
