from backend.control.android_client import AndroidControllerContract, ClientBlocked, ControllerUiState, ScreenSize
import pytest


def good(auth=True, bot=False, ledger=True):
    return ControllerUiState(auth, bot, "NORMAL", 0.10, ledger, True)

def test_secure_state_validates():
    AndroidControllerContract.validate_state(good())

def test_unauthenticated_bot_control_blocked():
    with pytest.raises(ClientBlocked): AndroidControllerContract.validate_state(good(False, True))

def test_ledger_failure_blocks_bot_control():
    with pytest.raises(ClientBlocked): AndroidControllerContract.validate_state(good(True, True, False))

def test_cap_cannot_be_exceeded():
    with pytest.raises(ClientBlocked): AndroidControllerContract.validate_state(ControllerUiState(True, False, "NORMAL", .200001, True, True))

def test_invalid_mode_blocked():
    with pytest.raises(ClientBlocked): AndroidControllerContract.validate_state(ControllerUiState(True, False, "HACK", .1, True, True))

def test_screenshot_protection_required():
    with pytest.raises(ClientBlocked): AndroidControllerContract.validate_state(ControllerUiState(True, False, "NORMAL", .1, True, False))

def test_responsive_layout_clipping_blocked():
    with pytest.raises(ClientBlocked): AndroidControllerContract.validate_layout(ScreenSize.COMPACT, clipped=True, overlapped=False)

def test_responsive_layout_overlap_blocked():
    with pytest.raises(ClientBlocked): AndroidControllerContract.validate_layout(ScreenSize.TABLET, clipped=False, overlapped=True)

def test_supported_layouts():
    for s in ScreenSize: AndroidControllerContract.validate_layout(s, clipped=False, overlapped=False)

def test_secret_is_masked():
    assert AndroidControllerContract.accept_secret_for_ui("abc123") == "★★★★★★"

def test_empty_secret_blocked():
    with pytest.raises(ClientBlocked): AndroidControllerContract.accept_secret_for_ui("")
