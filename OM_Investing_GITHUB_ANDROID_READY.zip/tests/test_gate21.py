import pytest
from backend.deployment.external_evidence_gate import (
    EvidenceState, ExternalEvidence, ExternalEvidenceGate, LiveReleaseBlocked,
)


def verified():
    return ExternalEvidence(**{name: EvidenceState.VERIFIED for name in ExternalEvidence.__dataclass_fields__})


def test_fresh_default_is_not_live_ready():
    report = ExternalEvidenceGate().assess(ExternalEvidence())
    assert not report.ready_for_live
    assert len(report.missing) == 7


def test_all_verified_is_live_ready():
    report = ExternalEvidenceGate().assess(verified())
    assert report.ready_for_live
    assert report.missing == ()
    assert report.rejected == ()


def test_missing_single_evidence_blocks():
    e = verified()
    e = ExternalEvidence(**{**e.__dict__, "broker": EvidenceState.MISSING})
    with pytest.raises(LiveReleaseBlocked):
        ExternalEvidenceGate().require_live(e)


def test_rejected_single_evidence_blocks():
    e = verified()
    e = ExternalEvidence(**{**e.__dict__, "blockchain": EvidenceState.REJECTED})
    report = ExternalEvidenceGate().assess(e)
    assert not report.ready_for_live
    assert report.rejected == ("blockchain",)
    with pytest.raises(LiveReleaseBlocked):
        ExternalEvidenceGate().require_live(e)


def test_plan_b_evidence_is_independent_requirement():
    e = verified()
    e = ExternalEvidence(**{**e.__dict__, "plan_b_servers": EvidenceState.MISSING})
    report = ExternalEvidenceGate().assess(e)
    assert report.missing == ("plan_b_servers",)


def test_market_feed_evidence_is_independent_requirement():
    e = verified()
    e = ExternalEvidence(**{**e.__dict__, "market_feed": EvidenceState.MISSING})
    assert not ExternalEvidenceGate().assess(e).ready_for_live


def test_local_verification_does_not_auto_verify_external_evidence():
    # Explicit construction is required; no local PASS flag is accepted as evidence.
    report = ExternalEvidenceGate().assess(ExternalEvidence())
    assert report.ready_for_live is False
