import pytest
from decimal import Decimal
from backend.core.master_contract import TradingMode
from backend.risk.opportunity_sizing import OpportunityRequest, authorize_opportunity, bound_requested_risk, slice_bounded_units

def test_mode_appetites_are_exact():
    assert authorize_opportunity(OpportunityRequest(TradingMode.NORMAL, 100, Decimal("0.0010"))) == 100
    assert authorize_opportunity(OpportunityRequest(TradingMode.MEDIUM, 50, Decimal("0.0010"))) == 50
    assert authorize_opportunity(OpportunityRequest(TradingMode.BOOST, 75, Decimal("0.0010"))) == 75

@pytest.mark.parametrize("mode,wrong", [(TradingMode.NORMAL,50),(TradingMode.MEDIUM,100),(TradingMode.BOOST,50)])
def test_wrong_appetite_is_rejected(mode, wrong):
    with pytest.raises(ValueError):
        authorize_opportunity(OpportunityRequest(mode, wrong, Decimal("0.0010")))

def test_risk_above_cap_rejected():
    with pytest.raises(ValueError):
        authorize_opportunity(OpportunityRequest(TradingMode.BOOST,75,Decimal("0.0021")))

def test_request_guard_never_increases_risk():
    assert bound_requested_risk(Decimal("0.0015")) == Decimal("0.0015")
    assert bound_requested_risk(Decimal("0.0030")) == Decimal("0.002")

def test_non_positive_request_rejected():
    with pytest.raises(ValueError): bound_requested_risk(Decimal("0"))

def test_slicing_conserves_total_and_bounds_children():
    parts = slice_bounded_units(Decimal("10"), Decimal("3"))
    assert sum(parts, Decimal("0")) == Decimal("10")
    assert all(p <= Decimal("3") for p in parts)
    assert len(parts) == 4

def test_invalid_slice_rejected():
    with pytest.raises(ValueError): slice_bounded_units(Decimal("0"), Decimal("3"))
