import pytest
from backend.deployment.deploy_gate import DeploymentBlocked, DeploymentEvidence, DeploymentGate, DeploymentStage


def evidence(**overrides):
    values = dict(owner_authenticated=True, integrity_valid=True,
                  compatibility_valid=True, master_target_valid=True,
                  health_valid=True, backup_checkpoint_valid=True)
    values.update(overrides)
    return DeploymentEvidence(**values)


def test_verified_deployment_can_activate():
    gate = DeploymentGate()
    gate.verify(evidence())
    assert gate.stage is DeploymentStage.VERIFIED
    gate.activate()
    assert gate.stage is DeploymentStage.ACTIVATED


@pytest.mark.parametrize("field", [
    "owner_authenticated", "integrity_valid", "compatibility_valid",
    "master_target_valid", "health_valid", "backup_checkpoint_valid",
])
def test_missing_required_deployment_evidence_blocks(field):
    gate = DeploymentGate()
    with pytest.raises(DeploymentBlocked):
        gate.verify(evidence(**{field: False}))
    assert gate.stage is DeploymentStage.STAGING


def test_activation_without_verification_is_blocked():
    with pytest.raises(DeploymentBlocked):
        DeploymentGate().activate()


def test_failed_verification_cannot_activate():
    gate = DeploymentGate()
    with pytest.raises(DeploymentBlocked):
        gate.verify(evidence(health_valid=False))
    with pytest.raises(DeploymentBlocked):
        gate.activate()


def test_rollback_is_explicit_terminal_state():
    gate = DeploymentGate()
    gate.verify(evidence())
    gate.rollback()
    assert gate.stage is DeploymentStage.ROLLED_BACK
    with pytest.raises(DeploymentBlocked):
        gate.activate()
