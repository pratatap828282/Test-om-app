import pytest
from backend.core.master_contract import TradingMode
from backend.strategy.decision_authority import DecisionAuthority, DecisionAuthorityBlocked, DecisionSeal
from backend.strategy.decision_contract import Decision, Side
from backend.strategy.decision_engine import DecisionEngine, DecisionInput
from backend.strategy.market_contract import MarketAnalysisContract
from backend.execution.authority_gate import ExecutionAuthorityGate, ExecutionAuthorityBlocked, ExecutionRequest

def seal():
    item = DecisionInput(MarketAnalysisContract("XAUUSD", "M5", trend="bullish"), Side.BUY,
                         TradingMode.NORMAL, True, True, 0.001, 0.1, True)
    return DecisionEngine().authorize(item)

def request(side=Side.BUY, symbol="XAUUSD", oid="o-1"):
    return ExecutionRequest(oid, symbol, side)

def test_valid_seal_authorizes_matching_execution():
    assert ExecutionAuthorityGate().authorize(request(), seal()).symbol == "XAUUSD"

def test_plain_decision_is_blocked():
    plain = Decision("XAUUSD", Side.BUY, TradingMode.NORMAL, True, True, True, True)
    with pytest.raises(ExecutionAuthorityBlocked):
        ExecutionAuthorityGate().authorize(request(), plain)

def test_forged_seal_is_blocked():
    plain = Decision("XAUUSD", Side.BUY, TradingMode.NORMAL, True, True, True, True)
    with pytest.raises(ExecutionAuthorityBlocked):
        ExecutionAuthorityGate().authorize(request(), DecisionSeal(plain, object()))

def test_wrong_symbol_is_blocked():
    with pytest.raises(ExecutionAuthorityBlocked):
        ExecutionAuthorityGate().authorize(request(symbol="DXY"), seal())

def test_wrong_side_is_blocked():
    with pytest.raises(ExecutionAuthorityBlocked):
        ExecutionAuthorityGate().authorize(request(side=Side.SELL), seal())

def test_missing_order_identity_is_blocked():
    with pytest.raises(ExecutionAuthorityBlocked):
        ExecutionAuthorityGate().authorize(request(oid=""), seal())

def test_invalid_seal_type_is_blocked():
    with pytest.raises(ExecutionAuthorityBlocked):
        ExecutionAuthorityGate().authorize(request(), object())

def test_decision_authority_public_capability_remains_blocked():
    with pytest.raises(DecisionAuthorityBlocked):
        DecisionAuthority.capability()
