import pytest
from backend.security.broker_login import (
    BrokerLoginDetails, BrokerLoginError, BrokerLoginGate,
)


class GoodVerifier:
    def verify(self, details):
        assert details.broker_name == "Configured Broker"
        assert details.server == "MT5-LIVE"
        assert details.account_id == "ACCOUNT-1"
        return "conn-evidence-1"


class BadVerifier:
    def verify(self, details):
        raise RuntimeError("connector failure")


class EmptyVerifier:
    def verify(self, details):
        return ""


def test_broker_details_are_verified_at_login():
    evidence = BrokerLoginGate(GoodVerifier()).verify_at_login(
        BrokerLoginDetails("Configured Broker", "MT5-LIVE", "ACCOUNT-1")
    )
    assert evidence.verified
    assert evidence.connection_id == "conn-evidence-1"


def test_missing_broker_details_fail_closed():
    with pytest.raises(BrokerLoginError):
        BrokerLoginGate(GoodVerifier()).verify_at_login(
            BrokerLoginDetails("", "MT5-LIVE", "ACCOUNT-1")
        )


def test_broker_connection_failure_fails_closed():
    with pytest.raises(BrokerLoginError):
        BrokerLoginGate(BadVerifier()).verify_at_login(
            BrokerLoginDetails("Configured Broker", "MT5-LIVE", "ACCOUNT-1")
        )


def test_missing_verification_evidence_fails_closed():
    with pytest.raises(BrokerLoginError):
        BrokerLoginGate(EmptyVerifier()).verify_at_login(
            BrokerLoginDetails("Configured Broker", "MT5-LIVE", "ACCOUNT-1")
        )
