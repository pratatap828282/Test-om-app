import pytest
from backend.strategy.market_contract import MarketAnalysisContract
from backend.strategy.decision_contract import Decision, Side
from backend.core.master_contract import TradingMode

def test_all_supported_timeframes_are_accepted():
    for tf in ("M1","M3","M5","M10","M15","M30","H1","H4","D1","W1","MN1"):
        MarketAnalysisContract("XAUUSD", tf).validate()

def test_dxy_is_analysis_only():
    a = MarketAnalysisContract("DXY", "H1", dxy_context="context")
    a.validate()
    assert not a.execution_eligible_symbol
    with pytest.raises(ValueError):
        Decision("DXY", Side.BUY, TradingMode.NORMAL, True, True, True, True).authorize()

def test_buy_and_sell_are_valid_but_require_all_gates():
    for side in (Side.BUY, Side.SELL):
        Decision("XAUUSD", side, TradingMode.NORMAL, True, True, True, True).authorize()

def test_incomplete_validation_blocks_execution():
    with pytest.raises(ValueError):
        Decision("XAUUSD", Side.BUY, TradingMode.NORMAL, False, True, True, True).authorize()
    with pytest.raises(ValueError):
        Decision("XAUUSD", Side.SELL, TradingMode.NORMAL, True, False, True, True).authorize()

def test_preferred_timeframes_are_explicit():
    assert all(MarketAnalysisContract("XAUUSD", tf).preferred_entry_timeframe for tf in ("M5","M10","M15"))
    assert not MarketAnalysisContract("XAUUSD", "M1").preferred_entry_timeframe
