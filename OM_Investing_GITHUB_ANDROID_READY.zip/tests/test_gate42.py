import hashlib
import pytest
from backend.recovery.doctor import DoctorBlocked, DoctorHealth, DoctorRepair, DoctorState, SupportDoctor


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def test_healthy_doctor_state():
    assert SupportDoctor().evaluate(DoctorHealth(1.0, True, True)) is DoctorState.HEALTHY


def test_degraded_doctor_state_on_old_heartbeat():
    assert SupportDoctor().evaluate(DoctorHealth(6.0, True, True)) is DoctorState.DEGRADED


def test_degraded_doctor_state_on_unhealthy_assistant():
    assert SupportDoctor().evaluate(DoctorHealth(1.0, True, False)) is DoctorState.DEGRADED


def test_invalid_heartbeat_is_safe_mode():
    assert SupportDoctor().evaluate(DoctorHealth(-1.0, True, True)) is DoctorState.SAFE_MODE


def test_invalid_integrity_is_safe_mode():
    assert SupportDoctor().evaluate(DoctorHealth(1.0, False, True)) is DoctorState.SAFE_MODE


def test_valid_support_repair_is_staged():
    content = b"authorized-support-repair"
    req = DoctorRepair("ASSISTANT_SUPPORT", content, True, digest(content))
    assert SupportDoctor().repair(req) == "STAGED_SUPPORT_REPAIR_READY"


def test_unauthorized_repair_fails_closed():
    content = b"repair"
    with pytest.raises(DoctorBlocked):
        SupportDoctor().repair(DoctorRepair("ASSISTANT_SUPPORT", content, False, digest(content)))


def test_financial_component_repair_fails_closed():
    content = b"repair"
    with pytest.raises(DoctorBlocked):
        SupportDoctor().repair(DoctorRepair("EXECUTION", content, True, digest(content)))


def test_repair_integrity_mismatch_fails_closed():
    with pytest.raises(DoctorBlocked):
        SupportDoctor().repair(DoctorRepair("ASSISTANT_SUPPORT", b"repair", True, "0" * 64))


def test_empty_or_invalid_repair_reference_fails_closed():
    with pytest.raises(DoctorBlocked):
        SupportDoctor().repair(DoctorRepair(" ", b"repair", True, digest(b"repair")))


def test_doctor_state_never_blocks_bot_execution():
    doctor = SupportDoctor()
    for state in DoctorState:
        assert doctor.bot_execution_dependency_ok(state) is True
