import pytest
from backend.recovery.bot_auto_heal import (
    AutoHealBlocked, BotAutoHealController, HealAction, HealRequest,
)


def test_bot_owned_heal_actions_are_allowed_when_valid():
    c = BotAutoHealController()
    for action in HealAction:
        assert c.can_heal_bot(HealRequest(action)) is True


@pytest.mark.parametrize("authorized", [False])
def test_unauthorized_heal_is_fail_closed(authorized):
    with pytest.raises(AutoHealBlocked):
        BotAutoHealController().validate(HealRequest(HealAction.RESTART_COMPONENT, authorized=authorized))


def test_invalid_integrity_is_fail_closed():
    with pytest.raises(AutoHealBlocked):
        BotAutoHealController().validate(HealRequest(HealAction.RECONNECT_FEED, integrity_valid=False))


def test_auto_heal_cannot_change_financial_state():
    with pytest.raises(AutoHealBlocked):
        BotAutoHealController().validate(HealRequest(HealAction.RESTART_COMPONENT, changes_financial_state=True))


def test_support_failure_never_blocks_bot_heal_path():
    c = BotAutoHealController()
    assert c.support_failure_blocks_bot(False) is False
    assert c.support_failure_blocks_bot(True) is False


def test_invalid_action_is_fail_closed():
    with pytest.raises(AutoHealBlocked):
        BotAutoHealController().validate(HealRequest("EXECUTE_TRADE"))
