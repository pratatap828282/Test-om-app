from decimal import Decimal
import pytest

from backend.audit.ledger import AuditLedger, LedgerIntegrityError
from backend.broker.contract import BrokerSnapshot, BrokerSubmission
from backend.broker.coordinator import BrokerExecutionCoordinator
from backend.core.final_verification import run_source_verification
from backend.core.execution_contract import ExecutionIntent, Side
from backend.core.master_contract import TradingMode
from backend.core.safety_contract import BrokerSnapshot as SafetySnapshot, ExecutionSafetyGate, SafetyError, SafetyMode
from backend.deployment.deploy_gate import DeploymentEvidence, DeploymentGate, DeploymentStage, DeploymentBlocked
from backend.deployment.release_gate import ExternalReleaseEvidence, ReleaseGate, ReleaseManifest, ReleaseStage, ReleaseBlocked
from backend.execution.lifecycle import LifecycleError, OrderLifecycle
from backend.execution.submission import OrderSubmissionCoordinator, SubmissionRequest
from backend.health.continuity import BotContinuity, SupportStatus
from backend.recovery.auto_heal import BotAutoHeal, HealthSnapshot, HealthState
from backend.strategy.decision_engine import DecisionEngine, DecisionInput
from backend.strategy.market_contract import MarketAnalysisContract


def valid_intent(order_id="e2e-1"):
    return ExecutionIntent("XAUUSD", Side.BUY, Decimal("0.001"), Decimal("0.5"), True, True)


def valid_analysis():
    return MarketAnalysisContract(
        symbol="XAUUSD", timeframe="M5", candle_pattern="bullish_engulfing", trend="bullish",
        cross_signal="confirmed", fibonacci_signal="0.618", cpi_context="validated",
        dxy_context="validated",
    )


def test_final_source_verification_passes():
    report = run_source_verification()
    assert report.passed
    assert report.external_live_evidence_required


def test_full_decision_to_broker_lifecycle():
    decision = DecisionEngine().authorize(DecisionInput(
        analysis=valid_analysis(), side=Side.BUY, mode=TradingMode.NORMAL,
        validated=True, reconciled=True, risk_fraction=0.001,
        feed_age_seconds=0.5, analysis_complete=True))
    coordinator = OrderSubmissionCoordinator()
    receipt = coordinator.prepare(SubmissionRequest("e2e-1", "fp-e2e-1", valid_intent()))
    lifecycle = OrderLifecycle(receipt.client_order_id)
    lifecycle.submit_started()
    broker = BrokerExecutionCoordinator()
    snapshot = BrokerSnapshot("acct", Decimal("1000"), True, True, frozenset())
    broker.submit(snapshot, BrokerSubmission("e2e-1", "XAUUSD", "BUY", Decimal("1")), decision)
    lifecycle.broker_acknowledged("broker-1")
    lifecycle.filled(); lifecycle.begin_exit(); lifecycle.closed()
    assert lifecycle.record.state.value == "CLOSED"


def test_ambiguous_broker_outcome_requires_reconciliation():
    lifecycle = OrderLifecycle("e2e-unknown")
    lifecycle.submit_started(); lifecycle.broker_outcome_unknown()
    with pytest.raises(LifecycleError):
        lifecycle.filled()
    lifecycle.reconcile_unknown("FILLED")
    lifecycle.begin_exit(); lifecycle.closed()


def test_safety_failure_enters_safe_mode():
    gate = ExecutionSafetyGate()
    with pytest.raises(SafetyError):
        gate.reconcile(SafetySnapshot(True, 1000, frozenset(), 90), 100)
    assert gate.mode is SafetyMode.SAFE_MODE
    with pytest.raises(SafetyError):
        gate.authorize_submit("blocked", 100)


def test_auto_heal_missing_reconciliation_is_fail_closed():
    state = BotAutoHeal().evaluate(HealthSnapshot(0.1, 30, 0, False))
    assert state is HealthState.SAFE_MODE
    assert not BotAutoHeal().can_continue_execution(state)


def test_support_failure_cannot_stop_bot():
    assert BotContinuity().trading_dependency_ok(SupportStatus(False, False))


def test_ledger_integrity_survives_valid_append():
    ledger = AuditLedger(); ledger.append("E2E", {"order": "e2e-1"})
    assert ledger.verify_integrity()


def test_ledger_tamper_is_detected():
    ledger = AuditLedger(); record = ledger.append("E2E", {"order": "e2e-1"})
    ledger._records[0] = type(record)(record.sequence, record.event_type, {"order": "tampered"}, record.previous_hash, record.record_hash)
    with pytest.raises(LedgerIntegrityError):
        ledger.verify_integrity()


def test_deployment_requires_all_verification_evidence():
    gate = DeploymentGate()
    with pytest.raises(DeploymentBlocked):
        gate.verify(DeploymentEvidence(True, True, True, False, True, True))
    assert gate.stage is DeploymentStage.STAGING


def test_release_live_requires_external_evidence():
    gate = ReleaseGate()
    manifest = ReleaseManifest("S1_TO_1T", "final", ReleaseStage.PRODUCTION, live=True)
    checks = {k: True for k in gate.REQUIRED_CHECKS}
    with pytest.raises(ReleaseBlocked):
        gate.evaluate(manifest, checks, True, True, True)
    assert gate.evaluate(manifest, checks, True, True, True,
        ExternalReleaseEvidence(True, True, True, True))


def test_live_release_does_not_accept_partial_external_evidence():
    gate = ReleaseGate()
    manifest = ReleaseManifest("S1_TO_1T", "final", ReleaseStage.PRODUCTION, live=True)
    checks = {k: True for k in gate.REQUIRED_CHECKS}
    with pytest.raises(ReleaseBlocked):
        gate.evaluate(manifest, checks, True, True, True,
            ExternalReleaseEvidence(True, True, False, True))


def auth_seal():
    return DecisionEngine().authorize(DecisionInput(
        MarketAnalysisContract("XAUUSD", "M5", trend="bullish"), Side.BUY,
        TradingMode.NORMAL, True, True, 0.001, 0.2, True))
