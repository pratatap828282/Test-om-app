import pytest
from backend.security.owner_auth import OwnerAuthenticator, AuthenticationError, AuthState
from backend.security.protected_operation import ProtectedOperation, require_owner_for_control

SECRET = b"test-owner-secret"


def test_valid_owner_authenticates():
    a = OwnerAuthenticator(SECRET)
    a.authenticate("test-owner-secret", 100.0)
    assert a.state is AuthState.AUTHENTICATED


def test_wrong_secret_fails_without_authentication():
    a = OwnerAuthenticator(SECRET)
    with pytest.raises(AuthenticationError):
        a.authenticate("wrong", 100.0)
    assert a.state is AuthState.LOCKED


def test_empty_secret_input_fails():
    a = OwnerAuthenticator(SECRET)
    with pytest.raises(AuthenticationError):
        a.authenticate("", 100.0)


def test_fifth_failure_starts_five_hour_lockout():
    a = OwnerAuthenticator(SECRET)
    for i in range(5):
        with pytest.raises(AuthenticationError):
            a.authenticate("wrong", 100.0 + i)
    with pytest.raises(AuthenticationError):
        a.authenticate("test-owner-secret", 101.0)
    assert a.state is AuthState.LOCKED


def test_lockout_expires_after_five_hours():
    a = OwnerAuthenticator(SECRET)
    for i in range(5):
        with pytest.raises(AuthenticationError):
            a.authenticate("wrong", 100.0 + i)
    a.authenticate("test-owner-secret", 104.0 + 5 * 60 * 60 + 1)
    assert a.state is AuthState.AUTHENTICATED


def test_authentication_failure_does_not_grant_control():
    a = OwnerAuthenticator(SECRET)
    with pytest.raises(AuthenticationError):
        require_owner_for_control(a, 100.0)


def test_authenticated_control_requires_integrity():
    op = ProtectedOperation("BOT_TOGGLE", True, False)
    with pytest.raises(PermissionError):
        op.authorize()


def test_unauthenticated_control_is_blocked():
    op = ProtectedOperation("BOT_TOGGLE", False, True)
    with pytest.raises(PermissionError):
        op.authorize()


def test_authenticated_integrity_valid_control_is_allowed():
    op = ProtectedOperation("BOT_TOGGLE", True, True)
    op.authorize()


def test_owner_authentication_does_not_equal_financial_authority():
    op = ProtectedOperation("CONTROL_PANEL", True, True)
    op.authorize()
    # The object authorizes the protected control boundary only; it has no order/withdrawal API.
    assert not hasattr(op, "submit_order")


def test_policy_constants_cannot_be_relaxed_on_construction():
    with pytest.raises(ValueError):
        OwnerAuthenticator(SECRET, max_failures=4)
    with pytest.raises(ValueError):
        OwnerAuthenticator(SECRET, lockout_seconds=60)
