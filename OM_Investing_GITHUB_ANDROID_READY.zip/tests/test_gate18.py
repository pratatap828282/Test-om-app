import pytest
from backend.deployment.release_gate import ReleaseGate, ReleaseManifest, ReleaseStage, ExternalReleaseEvidence, ReleaseBlocked

def checks():
    return {k: True for k in ReleaseGate.REQUIRED_CHECKS}

def test_live_release_requires_external_evidence():
    with pytest.raises(ReleaseBlocked, match="external release evidence incomplete"):
        ReleaseGate().evaluate(ReleaseManifest("S1_TO_1T", "0.1", ReleaseStage.PRODUCTION, True), checks(), True, True, True)

def test_incomplete_external_evidence_blocks_live_release():
    ev = ExternalReleaseEvidence(True, True, False, True)
    with pytest.raises(ReleaseBlocked):
        ReleaseGate().evaluate(ReleaseManifest("S1_TO_1T", "0.1", ReleaseStage.PRODUCTION, True), checks(), True, True, True, ev)

def test_complete_external_evidence_allows_live_release():
    ev = ExternalReleaseEvidence(True, True, True, True)
    assert ReleaseGate().evaluate(ReleaseManifest("S1_TO_1T", "0.1", ReleaseStage.PRODUCTION, True), checks(), True, True, True, ev)

def test_staging_does_not_require_external_evidence():
    assert ReleaseGate().evaluate(ReleaseManifest("S1_TO_1T", "0.1", ReleaseStage.STAGING, False), checks(), True, True, True)

def test_missing_required_check_blocks():
    c = checks(); c["security"] = False
    with pytest.raises(ReleaseBlocked):
        ReleaseGate().evaluate(ReleaseManifest("S1_TO_1T", "0.1", ReleaseStage.STAGING), c, True, True, True)

def test_live_release_cannot_use_staging_manifest():
    with pytest.raises(ReleaseBlocked):
        ReleaseGate().evaluate(ReleaseManifest("S1_TO_1T", "0.1", ReleaseStage.STAGING, True), checks(), True, True, True, ExternalReleaseEvidence(True,True,True,True))

def test_wrong_target_blocks():
    with pytest.raises(ReleaseBlocked):
        ReleaseGate().evaluate(ReleaseManifest("OTHER", "0.1", ReleaseStage.STAGING), checks(), True, True, True)

def test_owner_auth_required():
    with pytest.raises(ReleaseBlocked):
        ReleaseGate().evaluate(ReleaseManifest("S1_TO_1T", "0.1", ReleaseStage.STAGING), checks(), False, True, True)

def test_health_required():
    with pytest.raises(ReleaseBlocked):
        ReleaseGate().evaluate(ReleaseManifest("S1_TO_1T", "0.1", ReleaseStage.STAGING), checks(), True, True, False)

def test_target_validation_required():
    with pytest.raises(ReleaseBlocked):
        ReleaseGate().evaluate(ReleaseManifest("S1_TO_1T", "0.1", ReleaseStage.STAGING), checks(), True, False, True)
