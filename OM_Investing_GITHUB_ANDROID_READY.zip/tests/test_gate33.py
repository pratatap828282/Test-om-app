import pytest
from backend.fleet.server_control import ExecutionOwner, FleetControlBlocked, ServerFleet, ServerNode


def nodes():
    return [
        ServerNode("sg", "Singapore", latency_ns=100, jitter_ns=10, priority=0),
        ServerNode("de", "Germany", latency_ns=300, jitter_ns=5, priority=1),
        ServerNode("asia", "Asia", latency_ns=150, jitter_ns=20, priority=2),
        ServerNode("us", "USA", latency_ns=120, jitter_ns=30, priority=3),
    ]


def test_normal_operation_keeps_singapore_primary():
    assert ServerFleet().select(nodes()).region == "Singapore"


def test_normal_operation_does_not_choose_faster_plan_b():
    ns = nodes(); ns[2] = ServerNode("asia", "Asia", latency_ns=1, jitter_ns=1, priority=2)
    assert ServerFleet().select(ns).region == "Singapore"


def test_failover_chooses_lowest_latency_eligible_plan_b():
    ns = nodes(); ns[2] = ServerNode("asia", "Asia", latency_ns=80, jitter_ns=20, priority=2)
    assert ServerFleet().select(ns, failover=True).node_id == "asia"


def test_failover_uses_jitter_as_tiebreaker():
    ns = [ServerNode("de", "Germany", latency_ns=10, jitter_ns=20), ServerNode("asia", "Asia", latency_ns=10, jitter_ns=5)]
    assert ServerFleet().select(ns, failover=True).node_id == "asia"


def test_unauthorized_plan_b_is_excluded():
    ns = nodes(); ns[2] = ServerNode("asia", "Asia", authorized=False, latency_ns=1)
    assert ServerFleet().select(ns, failover=True).node_id == "us"


def test_unhealthy_plan_b_is_excluded():
    ns = nodes(); ns[2] = ServerNode("asia", "Asia", healthy=False, latency_ns=1)
    assert ServerFleet().select(ns, failover=True).node_id == "us"


def test_bad_feed_or_broker_excludes_node():
    ns = nodes(); ns[2] = ServerNode("asia", "Asia", feed_ok=False, latency_ns=1)
    assert ServerFleet().select(ns, failover=True).node_id == "us"


def test_no_primary_blocks_normal_operation():
    with pytest.raises(FleetControlBlocked): ServerFleet().select([nodes()[1]])


def test_no_plan_b_blocks_failover():
    with pytest.raises(FleetControlBlocked): ServerFleet().select([nodes()[0]], failover=True)


def test_acquire_establishes_fenced_owner():
    owner = ExecutionOwner(); epoch = owner.acquire(nodes()[0]); owner.assert_owner("sg", epoch)


def test_second_node_cannot_take_existing_owner():
    owner = ExecutionOwner(); owner.acquire(nodes()[0])
    with pytest.raises(FleetControlBlocked): owner.acquire(nodes()[1])


def test_transfer_requires_incident_and_reconciliation_and_fences_old_epoch():
    owner = ExecutionOwner(); old = owner.acquire(nodes()[0])
    with pytest.raises(FleetControlBlocked): owner.transfer(nodes()[1], incident_confirmed=False, reconciled=True)
    new = owner.transfer(nodes()[1], incident_confirmed=True, reconciled=True)
    assert new > old
    with pytest.raises(FleetControlBlocked): owner.assert_owner("sg", old)
    owner.assert_owner("de", new)
