from backend.recovery.auto_heal import BotAutoHeal, HealthSnapshot, HealthState
from backend.recovery.recovery_contract import RecoveryContract, RecoveryRequest
from backend.health.continuity import BotContinuity, SupportStatus

def test_healthy_snapshot_continues():
    h=BotAutoHeal(); assert h.evaluate(HealthSnapshot(1,50,10,True)) is HealthState.HEALTHY
    assert h.can_continue_execution(HealthState.HEALTHY)

def test_hung_bot_becomes_degraded():
    assert BotAutoHeal().evaluate(HealthSnapshot(5.1,50,10,True)) is HealthState.DEGRADED

def test_memory_limit_is_guarded():
    assert BotAutoHeal().evaluate(HealthSnapshot(1,92.1,10,True)) is HealthState.DEGRADED

def test_queue_limit_is_guarded():
    assert BotAutoHeal().evaluate(HealthSnapshot(1,50,1001,True)) is HealthState.DEGRADED

def test_missing_reconciliation_is_fail_closed():
    assert BotAutoHeal().evaluate(HealthSnapshot(1,50,1,False)) is HealthState.SAFE_MODE

def test_invalid_health_is_fail_closed():
    assert BotAutoHeal().evaluate(HealthSnapshot(-1,50,1,True)) is HealthState.SAFE_MODE

def test_unauthorized_recovery_blocked():
    try: RecoveryContract().authorize(RecoveryRequest('bot',False,True,True)); assert False
    except PermissionError: pass

def test_integrity_failure_blocks_recovery():
    try: RecoveryContract().authorize(RecoveryRequest('bot',True,False,True)); assert False
    except ValueError: pass

def test_recovery_requires_reconciliation():
    try: RecoveryContract().authorize(RecoveryRequest('bot',True,True,False)); assert False
    except ValueError: pass

def test_support_failure_never_becomes_bot_dependency():
    assert BotContinuity().trading_dependency_ok(SupportStatus(False,False))
