import pytest
from backend.security.broker_login import (
    BrokerLoginCredentials, BrokerLoginDetails, BrokerLoginError,
    BrokerLoginGate,
)

class Connector:
    def __init__(self):
        self.seen = None
    def login(self, credentials):
        self.seen = credentials
        return BrokerLoginDetails("Broker-A", "LIVE-SERVER", "ACC-42")
    def connection_evidence(self, details):
        return "verified-conn-42"

class BadConnector:
    def login(self, credentials):
        raise RuntimeError("auth failed")
    def connection_evidence(self, details):
        return "never"

def test_login_automatically_captures_session_metadata_without_returning_secret():
    connector = Connector()
    creds = BrokerLoginCredentials("user", "secret-password", "MT5")
    session = BrokerLoginGate(connector).login_and_capture(creds)
    assert session.authenticated is True
    assert session.platform == "MT5"
    assert session.broker_name == "Broker-A"
    assert session.server == "LIVE-SERVER"
    assert session.account_id == "ACC-42"
    assert session.connection_id == "verified-conn-42"
    assert not hasattr(session, "password")
    assert not hasattr(session, "username")
    assert connector.seen.password == "secret-password"

def test_mt4_mt5_and_trade_w_are_supported_login_platforms():
    for platform in ("MT4", "MT5", "Trade W"):
        connector = Connector()
        session = BrokerLoginGate(connector).login_and_capture(
            BrokerLoginCredentials("u", "p", platform)
        )
        assert session.platform == platform

def test_invalid_platform_fails_closed():
    with pytest.raises(BrokerLoginError):
        BrokerLoginGate(Connector()).login_and_capture(
            BrokerLoginCredentials("u", "p", "OTHER")
        )

def test_connector_auth_failure_fails_closed():
    with pytest.raises(BrokerLoginError):
        BrokerLoginGate(BadConnector()).login_and_capture(
            BrokerLoginCredentials("u", "p", "MT5")
        )

def test_blank_credentials_fail_closed():
    with pytest.raises(BrokerLoginError):
        BrokerLoginGate(Connector()).login_and_capture(
            BrokerLoginCredentials("", "p", "MT5")
        )
