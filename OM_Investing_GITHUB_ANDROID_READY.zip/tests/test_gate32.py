import hashlib
import pytest
from backend.trust.public_trust import PublicTrustGate, PublicTrustMaterial, TrustMaterialBlocked


def material(cert=b"public-cert"):
    return PublicTrustMaterial(
        anchor_id="om-root-1",
        subject="CN=OM Public Trust Root",
        sha256_fingerprint=hashlib.sha256(cert).hexdigest(),
        active=True,
    )


def test_valid_public_trust_passes():
    PublicTrustGate().verify(material(), b"public-cert")


def test_fingerprint_mismatch_blocks():
    with pytest.raises(TrustMaterialBlocked):
        PublicTrustGate().verify(material(), b"changed-cert")


def test_inactive_anchor_is_rejected():
    m = material()
    with pytest.raises(TrustMaterialBlocked):
        PublicTrustGate().verify(PublicTrustMaterial(**{**m.__dict__, "active": False}), b"public-cert")


def test_revoked_anchor_blocks():
    m = material()
    with pytest.raises(TrustMaterialBlocked):
        PublicTrustGate().verify(PublicTrustMaterial(**{**m.__dict__, "revoked": True}), b"public-cert")


def test_identity_required():
    m = material()
    with pytest.raises(TrustMaterialBlocked):
        PublicTrustGate().verify(PublicTrustMaterial(**{**m.__dict__, "anchor_id": ""}), b"public-cert")


def test_subject_required():
    m = material()
    with pytest.raises(TrustMaterialBlocked):
        PublicTrustGate().verify(PublicTrustMaterial(**{**m.__dict__, "subject": ""}), b"public-cert")


def test_empty_certificate_blocks():
    with pytest.raises(TrustMaterialBlocked):
        PublicTrustGate().verify(material(), b"")


def test_client_metadata_has_only_public_fields():
    metadata = PublicTrustGate.client_metadata(material())
    assert set(metadata) == {"anchor_id", "subject", "sha256_fingerprint"}


def test_private_key_marker_rejected_from_subject():
    m = material()
    with pytest.raises(TrustMaterialBlocked):
        PublicTrustGate().verify(PublicTrustMaterial(**{**m.__dict__, "subject": "PRIVATE KEY"}), b"public-cert")
