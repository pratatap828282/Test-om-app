from backend.evidence.external_verifier import (
    EvidenceKind, EvidenceItem, ExternalEvidenceVerifier, EvidenceValidationError,
)


def item(**overrides):
    base = dict(
        kind=EvidenceKind.BROKER,
        subject_id="authorized-subject",
        authorized=True,
        certificate_valid=True,
        integrity_valid=True,
        compatible=True,
        currently_valid=True,
        captured_at=1_000.0,
        nonce="n1",
        digest="d1",
    )
    base.update(overrides)
    return EvidenceItem(**base)


def test_valid_evidence_passes():
    assert ExternalEvidenceVerifier().verify(item(), now=1_100.0).verified


def test_missing_subject_blocks():
    assert not ExternalEvidenceVerifier().verify(item(subject_id=""), now=1_100.0).verified


def test_missing_nonce_blocks():
    assert not ExternalEvidenceVerifier().verify(item(nonce=""), now=1_100.0).verified


def test_missing_digest_blocks():
    assert not ExternalEvidenceVerifier().verify(item(digest=""), now=1_100.0).verified


def test_unauthorized_blocks():
    assert not ExternalEvidenceVerifier().verify(item(authorized=False), now=1_100.0).verified


def test_invalid_certificate_blocks():
    assert not ExternalEvidenceVerifier().verify(item(certificate_valid=False), now=1_100.0).verified


def test_integrity_failure_blocks():
    assert not ExternalEvidenceVerifier().verify(item(integrity_valid=False), now=1_100.0).verified


def test_incompatible_evidence_blocks():
    assert not ExternalEvidenceVerifier().verify(item(compatible=False), now=1_100.0).verified


def test_current_validity_failure_blocks():
    assert not ExternalEvidenceVerifier().verify(item(currently_valid=False), now=1_100.0).verified


def test_future_timestamp_blocks():
    assert not ExternalEvidenceVerifier().verify(item(captured_at=1_101.0), now=1_100.0).verified


def test_stale_timestamp_blocks():
    assert not ExternalEvidenceVerifier().verify(item(captured_at=700.0), now=1_100.0).verified


def test_require_raises_on_failure():
    try:
        ExternalEvidenceVerifier().require(item(authorized=False), now=1_100.0)
    except EvidenceValidationError:
        return
    raise AssertionError("expected EvidenceValidationError")
