from decimal import Decimal
import pytest
from backend.broker.contract import BrokerSnapshot, BrokerSubmission, BrokerBoundaryError
from backend.broker.coordinator import BrokerExecutionCoordinator
from backend.strategy.decision_authority import DecisionSeal
from backend.strategy.decision_contract import Decision, Side
from backend.strategy.decision_engine import DecisionEngine, DecisionInput
from backend.strategy.market_contract import MarketAnalysisContract
from backend.core.master_contract import TradingMode


def snap(**kw):
    base = dict(account_id="acct", equity=Decimal("1000"), connected=True,
                reconciled=True, open_order_ids=frozenset())
    base.update(kw)
    return BrokerSnapshot(**base)


def seal(side=Side.BUY, symbol="XAUUSD"):
    return DecisionEngine().authorize(DecisionInput(
        MarketAnalysisContract(symbol, "M5", trend="bullish"), side,
        TradingMode.NORMAL, True, True, 0.001, 0.2, True))


def order(cid="g47", symbol="XAUUSD", side="BUY"):
    return BrokerSubmission(cid, symbol, side, Decimal("0.01"))


def test_broker_submit_requires_authoritative_seal():
    with pytest.raises(BrokerBoundaryError):
        BrokerExecutionCoordinator().submit(snap(), order())


def test_valid_matching_seal_allows_submission():
    assert BrokerExecutionCoordinator().submit(snap(), order(), seal()) == "g47"


def test_wrong_side_seal_blocks_submission():
    with pytest.raises(BrokerBoundaryError):
        BrokerExecutionCoordinator().submit(snap(), order(), seal(Side.SELL))


def test_wrong_symbol_request_blocks_submission():
    with pytest.raises(BrokerBoundaryError):
        BrokerExecutionCoordinator().submit(snap(), order(symbol="DXY"), seal())


def test_forged_seal_blocks_submission():
    plain = Decision("XAUUSD", Side.BUY, TradingMode.NORMAL, True, True, True, True)
    forged = DecisionSeal(plain, object())
    with pytest.raises(BrokerBoundaryError):
        BrokerExecutionCoordinator().submit(snap(), order(), forged)
