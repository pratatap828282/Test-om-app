from backend.operations.mode_window import OperationalPolicy, SystemMode, WindowKind

def test_mode_appetite_contract():
    p=OperationalPolicy()
    assert p.policy().appetite_pct == 100
    p.set_mode(SystemMode.MEDIUM); assert p.policy().appetite_pct == 50
    p.set_mode(SystemMode.BOOST); assert p.policy().appetite_pct == 75

def test_modes_do_not_change_absolute_risk_cap():
    p=OperationalPolicy()
    for m in SystemMode:
        p.set_mode(m)
        assert p.policy().risk_cap_pct == 0.20
        assert p.authorize_execution(0.20, WindowKind.LIVE_24X5)
        assert not p.authorize_execution(0.2001, WindowKind.LIVE_24X5)

def test_live_execution_only_in_24x5():
    p=OperationalPolicy()
    assert p.authorize_execution(0.10, WindowKind.LIVE_24X5)
    assert not p.authorize_execution(0.10, WindowKind.RESEARCH_HEAL_24X2)

def test_research_heal_window_is_not_execution_window():
    p=OperationalPolicy()
    assert p.authorize_research_or_heal(WindowKind.RESEARCH_HEAL_24X2)
    assert not p.authorize_research_or_heal(WindowKind.LIVE_24X5)

def test_invalid_mode_rejected():
    try: OperationalPolicy().set_mode("AGGRESSIVE"); assert False
    except ValueError: pass

def test_invalid_window_rejected():
    try: OperationalPolicy().authorize_execution(0.1, "24x5"); assert False
    except ValueError: pass
