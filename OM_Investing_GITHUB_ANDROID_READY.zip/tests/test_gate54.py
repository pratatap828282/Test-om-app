from decimal import Decimal
import pytest

from backend.core.final_gate import run_final_source_gate, FinalGateReport
from backend.analysis.market_analysis import AnalysisSnapshot
from backend.strategy.market_contract import MarketAnalysisContract
from backend.strategy.decision_contract import Side
from backend.core.master_contract import TradingMode
from backend.core.trading_pipeline import TradingPipeline, TradingPipelineBlocked
from backend.deployment.external_evidence_gate import ExternalEvidence, EvidenceState, ExternalEvidenceGate
from backend.deployment.transactional_release import TransactionalRelease, ReleaseBlocked, ReleaseSnapshot


def valid_analysis(symbol="XAUUSD"):
    return AnalysisSnapshot(MarketAnalysisContract(
        symbol=symbol, timeframe="M5", trend="bullish",
        candle_pattern="engulfing", fibonacci_signal="valid",
        cross_signal="valid", cpi_context="neutral",
    ), corroborated=True, feed_valid=True)


def params():
    return dict(analysis=valid_analysis(), side=Side.BUY, mode=TradingMode.NORMAL,
                equity=Decimal("10000"), risk_fraction=Decimal("0.001"),
                stop_distance=Decimal("10"), value_per_unit_at_price=Decimal("1"),
                client_order_id="f54", broker_order_id="b54")


def test_gate54_final_source_gate_passes():
    report, result = run_final_source_gate()
    assert isinstance(report, FinalGateReport)
    assert report.passed
    assert result.settlement.final_net_profit == Decimal("0.90")


def test_gate54_buy_and_sell_paths():
    for side, cid, bid in ((Side.BUY, "fb", "bb"), (Side.SELL, "fs", "bs")):
        p = params(); p.update(side=side, client_order_id=cid, broker_order_id=bid)
        assert TradingPipeline().execute_controlled_trade(**p).side is side


def test_gate54_net_profit_is_after_fee():
    p = params(); p.update(fee=Decimal("0.10"), fee_margin=Decimal("0.20"))
    r = TradingPipeline().execute_controlled_trade(**p)
    assert r.settlement.final_net_profit == Decimal("0.90")
    assert r.settlement.treasury_amount == Decimal("0.810")
    assert r.settlement.operating_reserve == Decimal("0.090")


def test_gate54_risk_cap_boundary():
    p = params(); p["risk_fraction"] = Decimal("0.002")
    assert TradingPipeline().execute_controlled_trade(**p).quantity == Decimal("2")
    p["client_order_id"] = "over"; p["broker_order_id"] = "overb"
    p["risk_fraction"] = Decimal("0.00201")
    with pytest.raises(ValueError): TradingPipeline().execute_controlled_trade(**p)


def test_gate54_dxy_is_not_execution_symbol():
    p = params(); p["analysis"] = valid_analysis("DXY")
    with pytest.raises(ValueError): TradingPipeline().execute_controlled_trade(**p)


def test_gate54_missing_identity_blocks():
    p = params(); p["client_order_id"] = ""
    with pytest.raises(TradingPipelineBlocked): TradingPipeline().execute_controlled_trade(**p)


def test_gate54_external_evidence_is_explicitly_missing_by_default():
    report = ExternalEvidenceGate().assess(ExternalEvidence())
    assert not report.ready_for_live
    assert set(report.missing) == {"broker", "primary_server", "plan_b_servers", "network", "device", "market_feed", "blockchain"}


def test_gate54_all_external_evidence_is_required():
    kwargs = {name: EvidenceState.VERIFIED for name in ExternalEvidenceGate.FIELDS}
    report = ExternalEvidenceGate().assess(ExternalEvidence(**kwargs))
    assert report.ready_for_live
    assert report.missing == () and report.rejected == ()


def test_gate54_rejected_external_evidence_blocks():
    kwargs = {name: EvidenceState.VERIFIED for name in ExternalEvidenceGate.FIELDS}
    kwargs["broker"] = EvidenceState.REJECTED
    report = ExternalEvidenceGate().assess(ExternalEvidence(**kwargs))
    assert not report.ready_for_live
    assert report.rejected == ("broker",)


def test_gate54_release_transaction_requires_verification_before_checkpoint():
    r = TransactionalRelease(); r.stage_release(ReleaseSnapshot("r54", True, True, True, True))
    with pytest.raises(ReleaseBlocked): r.checkpoint()


def test_gate54_release_transaction_requires_checkpoint_before_activation():
    r = TransactionalRelease(); r.stage_release(ReleaseSnapshot("r54", True, True, True, True))
    r.verify()
    with pytest.raises(ReleaseBlocked):
        # verify does not implicitly checkpoint
        r.rollback()


def test_gate54_release_transaction_activation_after_checkpoint():
    r = TransactionalRelease(); r.stage_release(ReleaseSnapshot("r54", True, True, True, True))
    r.verify()
    r.checkpoint()
    r.activate()
    assert r.stage.value == "ACTIVATED"


def test_gate54_release_transaction_rollback_after_checkpoint():
    r = TransactionalRelease(); r.stage_release(ReleaseSnapshot("r54", True, True, True, True))
    r.verify()
    r.checkpoint()
    assert r.rollback() == "r54"
    assert r.stage.value == "ROLLED_BACK"


def test_gate54_invalid_integrity_cannot_activate():
    r = TransactionalRelease(); r.stage_release(ReleaseSnapshot("r54", True, True, True, True))
    with pytest.raises(ReleaseBlocked):
        r._snapshot = ReleaseSnapshot("r54", False, True, True, True)
        r.verify()


def test_gate54_invalid_compatibility_cannot_activate():
    r = TransactionalRelease(); r.stage_release(ReleaseSnapshot("r54", True, True, True, True))
    with pytest.raises(ReleaseBlocked):
        r._snapshot = ReleaseSnapshot("r54", True, False, True, True)
        r.verify()


def test_gate54_invalid_master_target_cannot_activate():
    r = TransactionalRelease(); r.stage_release(ReleaseSnapshot("r54", True, True, True, True))
    with pytest.raises(ReleaseBlocked):
        r._snapshot = ReleaseSnapshot("r54", True, True, False, True)
        r.verify()


def test_gate54_invalid_health_cannot_activate():
    r = TransactionalRelease(); r.stage_release(ReleaseSnapshot("r54", True, True, True, True))
    with pytest.raises(ReleaseBlocked):
        r._snapshot = ReleaseSnapshot("r54", True, True, True, False)
        r.verify()


def test_gate54_new_release_invalidates_old_checkpoint():
    r = TransactionalRelease(); r.stage_release(ReleaseSnapshot("old", True, True, True, True))
    r.verify(); r.checkpoint()
    assert r.checkpointed
    r.stage_release(ReleaseSnapshot("new", True, True, True, True))
    assert not r.checkpointed


def test_gate54_final_report_requires_external_block_boundary():
    report, _ = run_final_source_gate()
    assert report.live_release_blocked_without_external_evidence


def test_gate54_final_gate_does_not_fabricate_live_evidence():
    report = ExternalEvidenceGate().assess(ExternalEvidence())
    assert report.missing
    assert not report.ready_for_live
