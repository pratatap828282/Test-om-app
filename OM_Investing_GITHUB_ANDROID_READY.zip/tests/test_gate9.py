from decimal import Decimal
import pytest
from backend.core.execution_contract import ExecutionIntent, Side
from backend.execution.submission import OrderSubmissionCoordinator, SubmissionRequest
from backend.execution.order_state import OrderState


def req(cid="o-1", fp="fp-1", reconciled=True, validated=True, risk="0.001", age="0.5"):
    return SubmissionRequest(cid, fp, ExecutionIntent("XAUUSD", Side.BUY, Decimal(risk), Decimal(age), reconciled, validated))


def test_prepare_requires_valid_execution_intent():
    c=OrderSubmissionCoordinator()
    with pytest.raises(ValueError): c.prepare(req(reconciled=False))


def test_prepare_reserves_unique_order_identity():
    c=OrderSubmissionCoordinator()
    r=c.prepare(req())
    assert r.state is OrderState.NEW


def test_duplicate_order_is_blocked():
    c=OrderSubmissionCoordinator(); c.prepare(req())
    with pytest.raises(ValueError): c.prepare(req())


def test_same_id_with_different_fingerprint_is_blocked():
    c=OrderSubmissionCoordinator(); c.prepare(req())
    with pytest.raises(ValueError): c.prepare(req(fp="other"))


def test_submission_lifecycle_is_ordered():
    c=OrderSubmissionCoordinator()
    r=c.prepare(req())
    r=c.begin_submission(r); assert r.state is OrderState.SUBMITTING
    r=c.acknowledge(r); assert r.state is OrderState.ACKNOWLEDGED
    r=c.mark_filled(r); assert r.state is OrderState.FILLED


def test_stale_feed_blocks_before_submission():
    c=OrderSubmissionCoordinator()
    with pytest.raises(ValueError): c.prepare(req(age="2.01"))


def test_risk_above_immutable_cap_blocks_before_submission():
    c=OrderSubmissionCoordinator()
    with pytest.raises(ValueError): c.prepare(req(risk="0.0021"))


def test_non_xauusd_execution_blocks_before_submission():
    c=OrderSubmissionCoordinator()
    bad=req(); bad=SubmissionRequest(bad.client_order_id,bad.fingerprint,
        ExecutionIntent("DXY", Side.BUY, Decimal("0.001"), Decimal("0.5"), True, True))
    with pytest.raises(ValueError): c.prepare(bad)
