from dataclasses import replace
from backend.certification.certification_gate import (
    CertificationBlocked, CertificationEvidence, CertificationGate, OperationScope,
)


def evidence():
    return CertificationEvidence(True, True, True, True, True, True, True, True)


def test_full_certification_passes():
    assert CertificationGate().certify(OperationScope.EXECUTION, evidence()).certified


def test_all_critical_scopes_exist():
    assert len(OperationScope) == 17
    assert OperationScope.WITHDRAWAL in OperationScope
    assert OperationScope.RECOVERY in OperationScope


def test_identity_required():
    assert not CertificationGate().certify(OperationScope.SECURITY, replace(evidence(), identity=False)).certified


def test_trust_required():
    assert not CertificationGate().certify(OperationScope.APK, replace(evidence(), certificate_trust=False)).certified


def test_integrity_required():
    assert not CertificationGate().certify(OperationScope.LEDGER, replace(evidence(), integrity=False)).certified


def test_authorization_required():
    assert not CertificationGate().certify(OperationScope.WITHDRAWAL, replace(evidence(), authorization=False)).certified


def test_compatibility_required():
    assert not CertificationGate().certify(OperationScope.DEPLOYMENT, replace(evidence(), compatibility=False)).certified


def test_current_validity_required():
    assert not CertificationGate().certify(OperationScope.MARKET_FEED, replace(evidence(), currently_valid=False)).certified


def test_operation_validation_required():
    assert not CertificationGate().certify(OperationScope.RISK, replace(evidence(), operation_validated=False)).certified


def test_audit_evidence_required():
    assert not CertificationGate().certify(OperationScope.SETTLEMENT, replace(evidence(), audit_evidence=False)).certified


def test_require_is_fail_closed():
    try:
        CertificationGate().require(OperationScope.EXECUTION, replace(evidence(), integrity=False))
    except CertificationBlocked:
        return
    raise AssertionError("expected CertificationBlocked")
