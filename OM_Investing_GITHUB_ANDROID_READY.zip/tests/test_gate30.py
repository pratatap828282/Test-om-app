import pytest
from backend.operations.notifications import NotificationCenter, NotificationEvent, NotificationKind, NotificationContractError

def ev(i, kind=NotificationKind.BOT_EVENT):
    return NotificationEvent(kind, f"e-{i}", f"event {i}", i)

def test_persistent_and_push():
    n=NotificationCenter(); n.publish(ev(1)); assert len(n.persistent_history())==1; assert len(n.push_history())==1

def test_push_can_be_disabled_but_persistence_remains():
    n=NotificationCenter(); n.publish(ev(1), push=False); assert len(n.persistent_history())==1; assert not n.push_history()

def test_duplicate_event_blocked():
    n=NotificationCenter(); n.publish(ev(1));
    with pytest.raises(NotificationContractError): n.publish(ev(2)) if False else n.publish(ev(1))

def test_sequence_replay_blocked():
    n=NotificationCenter(); n.publish(ev(2));
    with pytest.raises(NotificationContractError): n.publish(ev(1))

def test_empty_fields_blocked():
    n=NotificationCenter()
    with pytest.raises(NotificationContractError): n.publish(NotificationEvent(NotificationKind.BOT_EVENT, '', 'x', 1))

def test_liquidation_is_supported():
    n=NotificationCenter(); n.publish(ev(1, NotificationKind.LIQUIDATION)); assert n.persistent_history()[0].kind is NotificationKind.LIQUIDATION

def test_assistant_and_doctor_events_supported():
    n=NotificationCenter(); n.publish(ev(1, NotificationKind.ASSISTANT_EVENT)); n.publish(ev(2, NotificationKind.DOCTOR_EVENT)); assert len(n.persistent_history())==2

def test_milestone_at_100_trades():
    n=NotificationCenter()
    for i in range(1,101): m=n.record_trade(i)
    assert m is not None and m.kind is NotificationKind.TRADE_MILESTONE and '100' in m.message

def test_no_premature_milestone():
    n=NotificationCenter()
    for i in range(1,100): assert n.record_trade(i) is None

def test_milestones_repeat_every_100():
    n=NotificationCenter(); got=[]
    for i in range(1,201):
        m=n.record_trade(i)
        if m: got.append(m)
    assert len(got)==2
