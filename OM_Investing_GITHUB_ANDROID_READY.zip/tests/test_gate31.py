import hashlib
import pytest
from backend.release.artifact_integrity import ReleaseArtifact, ReleaseArtifactGate, ReleaseBlocked


def artifact(payload=b"fresh-release"):
    return ReleaseArtifact(
        artifact_id="om-release",
        version="1.0.0",
        sha256=hashlib.sha256(payload).hexdigest(),
        signed=True,
        signature_valid=True,
        compatibility_valid=True,
        master_target_unchanged=True,
    )


def test_valid_artifact_passes():
    ReleaseArtifactGate().verify(artifact(), b"fresh-release")


def test_digest_mismatch_blocks():
    a = artifact()
    with pytest.raises(ReleaseBlocked):
        ReleaseArtifactGate().verify(a, b"tampered")


def test_unsigned_artifact_blocks():
    a = artifact()
    a = ReleaseArtifact(**{**a.__dict__, "signed": False})
    with pytest.raises(ReleaseBlocked):
        ReleaseArtifactGate().verify(a, b"fresh-release")


def test_invalid_signature_blocks():
    a = artifact()
    a = ReleaseArtifact(**{**a.__dict__, "signature_valid": False})
    with pytest.raises(ReleaseBlocked):
        ReleaseArtifactGate().verify(a, b"fresh-release")


def test_incompatible_artifact_blocks():
    a = artifact()
    a = ReleaseArtifact(**{**a.__dict__, "compatibility_valid": False})
    with pytest.raises(ReleaseBlocked):
        ReleaseArtifactGate().verify(a, b"fresh-release")


def test_master_target_mutation_blocks():
    a = artifact()
    a = ReleaseArtifact(**{**a.__dict__, "master_target_unchanged": False})
    with pytest.raises(ReleaseBlocked):
        ReleaseArtifactGate().verify(a, b"fresh-release")


def test_private_keys_blocked():
    a = artifact()
    a = ReleaseArtifact(**{**a.__dict__, "contains_private_keys": True})
    with pytest.raises(ReleaseBlocked):
        ReleaseArtifactGate().verify(a, b"fresh-release")


def test_broker_secrets_blocked():
    a = artifact()
    a = ReleaseArtifact(**{**a.__dict__, "contains_broker_secrets": True})
    with pytest.raises(ReleaseBlocked):
        ReleaseArtifactGate().verify(a, b"fresh-release")


def test_wallet_private_keys_blocked():
    a = artifact()
    a = ReleaseArtifact(**{**a.__dict__, "contains_wallet_private_keys": True})
    with pytest.raises(ReleaseBlocked):
        ReleaseArtifactGate().verify(a, b"fresh-release")


def test_empty_payload_blocks():
    a = artifact()
    with pytest.raises(ReleaseBlocked):
        ReleaseArtifactGate().verify(a, b"")


def test_identity_required():
    a = artifact()
    a = ReleaseArtifact(**{**a.__dict__, "artifact_id": ""})
    with pytest.raises(ReleaseBlocked):
        ReleaseArtifactGate().verify(a, b"fresh-release")


def test_version_required():
    a = artifact()
    a = ReleaseArtifact(**{**a.__dict__, "version": ""})
    with pytest.raises(ReleaseBlocked):
        ReleaseArtifactGate().verify(a, b"fresh-release")


def test_public_metadata_contains_no_secret_fields():
    metadata = ReleaseArtifactGate.public_metadata(artifact())
    assert set(metadata) == {"artifact_id", "version", "sha256", "signed", "signature_valid"}
