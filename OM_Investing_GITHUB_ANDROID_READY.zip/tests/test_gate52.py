import pytest

from backend.execution.close_authority import CloseRequest
from backend.execution.close_evidence import CloseEvidence, CloseEvidenceBlocked, EvidenceBoundBrokerClose
from backend.execution.lifecycle import OrderLifecycle


def exiting(cid="c-52", bid="b-52"):
    x = OrderLifecycle(cid)
    x.submit_started(); x.broker_acknowledged(bid); x.filled(); x.begin_exit()
    return x


def ev(eid="ev-52", cid="c-52", bid="b-52", **kw):
    base = dict(evidence_id=eid, client_order_id=cid, broker_order_id=bid,
                position_open=False, reconciled=True)
    base.update(kw)
    return CloseEvidence(**base)


def test_identity_bound_evidence_closes_original_trade():
    x = exiting(); req = CloseRequest("c-52", "b-52")
    gate = EvidenceBoundBrokerClose()
    assert gate.confirm(x, req, ev()) == "c-52"
    assert x.record.state.value == "CLOSED"
    assert gate.evidence_used("ev-52")

@pytest.mark.parametrize("changes", [
    {"evidence_id": ""},
    {"client_order_id": "other"},
    {"broker_order_id": "other"},
    {"position_open": True},
    {"reconciled": False},
])
def test_invalid_or_unbound_evidence_fails_closed(changes):
    x = exiting(); gate = EvidenceBoundBrokerClose()
    with pytest.raises(CloseEvidenceBlocked):
        gate.confirm(x, CloseRequest("c-52", "b-52"), ev(**changes))
    assert x.record.state.value == "EXITING"


def test_evidence_id_cannot_be_reused():
    x = exiting(); gate = EvidenceBoundBrokerClose(); req = CloseRequest("c-52", "b-52")
    gate.confirm(x, req, ev())
    y = exiting("c-53", "b-53")
    with pytest.raises(CloseEvidenceBlocked):
        gate.confirm(y, CloseRequest("c-53", "b-53"), ev())
    assert y.record.state.value == "EXITING"


def test_request_identity_must_match_original_trade():
    x = exiting(); gate = EvidenceBoundBrokerClose()
    with pytest.raises(CloseEvidenceBlocked):
        gate.confirm(x, CloseRequest("other", "b-52"), ev())
    assert x.record.state.value == "EXITING"
