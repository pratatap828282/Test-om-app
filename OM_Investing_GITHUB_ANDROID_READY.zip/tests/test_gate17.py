from decimal import Decimal
import pytest
from backend.audit.ledger import AuditLedger
from backend.broker.contract import BrokerSnapshot
from backend.deployment.activation_controller import ActivationController
from backend.deployment.deploy_gate import DeploymentGate, DeploymentBlocked, DeploymentStage
from backend.security.owner_auth import OwnerAuthenticator, AuthenticationError

def snap(**kw):
    base=dict(account_id="ACC", equity=Decimal("1000"), connected=True, reconciled=True, open_order_ids=frozenset())
    base.update(kw); return BrokerSnapshot(**base)

def controller(secret=b"owner-secret"):
    auth=OwnerAuthenticator(secret); auth.authenticate("owner-secret", 0)
    return ActivationController(DeploymentGate(), AuditLedger(), auth)

def test_activation_requires_authenticated_owner():
    auth=OwnerAuthenticator(b"owner-secret")
    c=ActivationController(DeploymentGate(), AuditLedger(), auth)
    with pytest.raises(DeploymentBlocked): c.activate(0, snap())

def test_verified_owner_ledger_and_reconciliation_activate():
    c=controller(); c.activate(1, snap()); assert c.gate.stage is DeploymentStage.ACTIVATED
    assert c.ledger.records[-1].event_type == "DEPLOYMENT_ACTIVATION_AUTHORIZED"

def test_ledger_tamper_blocks_activation():
    c=controller(); c.ledger.append("TEST", {"x": 1}); r=c.ledger.records[0]
    c.ledger._records[0]=type(r)(r.sequence,r.event_type,{"x":2},r.previous_hash,r.record_hash)
    with pytest.raises(DeploymentBlocked): c.activate(1, snap())
    assert c.gate.stage is DeploymentStage.STAGING

def test_missing_reconciliation_blocks_activation():
    c=controller()
    with pytest.raises(DeploymentBlocked): c.activate(1, snap(reconciled=False))
    assert c.gate.stage is DeploymentStage.STAGING

def test_disconnected_broker_blocks_activation():
    c=controller()
    with pytest.raises(DeploymentBlocked): c.activate(1, snap(connected=False))

def test_missing_account_identity_blocks_activation():
    c=controller()
    with pytest.raises(DeploymentBlocked): c.activate(1, snap(account_id=""))

def test_existing_activation_identity_does_not_authorize_trade_submission():
    c=controller(); c.activate(1, snap())
    # Activation evidence is a deployment authorization, not a trade authorization.
    assert c.gate.stage is DeploymentStage.ACTIVATED

def test_activation_records_audit_evidence_after_checks():
    c=controller(); c.activate(1, snap())
    assert c.ledger.verify_integrity() is True

def test_failed_authentication_remains_blocked():
    auth=OwnerAuthenticator(b"owner-secret")
    for i in range(5):
        with pytest.raises(AuthenticationError): auth.authenticate("bad", i)
    c=ActivationController(DeploymentGate(), AuditLedger(), auth)
    with pytest.raises(DeploymentBlocked): c.activate(18000, snap())

def test_activation_cannot_recover_from_rolled_back_state_without_reverification():
    c=controller(); c.gate.rollback()
    with pytest.raises(DeploymentBlocked): c.activate(1, snap())
