from backend.data.lifecycle import (
    CleanupBlocked, DataClass, DataLifecycleManager, DataRecord,
)


def record(i, cls, age, **kw):
    return DataRecord(i, cls, age, **kw)


def test_financial_evidence_is_retained():
    p = DataLifecycleManager().plan_cleanup([record("f", DataClass.FINANCIAL_EVIDENCE, 365)])
    assert p.record_ids == ()


def test_audit_evidence_is_retained():
    p = DataLifecycleManager().plan_cleanup([record("a", DataClass.AUDIT_EVIDENCE, 365)])
    assert p.record_ids == ()


def test_order_state_is_retained():
    p = DataLifecycleManager().plan_cleanup([record("o", DataClass.ORDER_STATE, 365)])
    assert p.record_ids == ()


def test_research_cache_compacts_at_monthly_boundary():
    p = DataLifecycleManager().plan_cleanup([record("r", DataClass.RESEARCH_CACHE, 30)])
    assert p.record_ids == ("r",)


def test_temporary_data_compacts_at_monthly_boundary():
    p = DataLifecycleManager().plan_cleanup([record("t", DataClass.TEMPORARY, 60)])
    assert p.record_ids == ("t",)


def test_young_cache_is_retained_for_now():
    p = DataLifecycleManager().plan_cleanup([record("r", DataClass.RESEARCH_CACHE, 29)])
    assert p.record_ids == ()


def test_active_order_reference_is_never_cleaned():
    p = DataLifecycleManager().plan_cleanup([record("r", DataClass.RESEARCH_CACHE, 90, active_order_reference=True)])
    assert p.record_ids == ()


def test_invalid_integrity_blocks_cleanup():
    try:
        DataLifecycleManager().plan_cleanup([record("r", DataClass.TEMPORARY, 90, integrity_valid=False)])
        assert False
    except CleanupBlocked:
        pass


def test_invalid_age_blocks_cleanup():
    try:
        DataLifecycleManager().plan_cleanup([record("r", DataClass.TEMPORARY, -1)])
        assert False
    except CleanupBlocked:
        pass


def test_blank_id_blocks_cleanup():
    try:
        DataLifecycleManager().plan_cleanup([record(" ", DataClass.TEMPORARY, 90)])
        assert False
    except CleanupBlocked:
        pass


def test_cleanup_does_not_block_trading():
    p = DataLifecycleManager().plan_cleanup([record("r", DataClass.TEMPORARY, 90)])
    assert DataLifecycleManager().can_cleanup_without_trading_block(p)
    assert p.trading_blocking is False


def test_hot_path_is_minimized_not_deleted_by_cleanup_policy():
    m = DataLifecycleManager()
    p = m.plan_cleanup([record("m", DataClass.MARKET_HOT, 365)])
    assert p.record_ids == ()
    assert m.classify(DataClass.MARKET_HOT) == "MINIMIZE_HOT_PATH"
