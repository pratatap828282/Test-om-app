from decimal import Decimal as D
import pytest
from backend.settlement.wallet import OwnerWallet, WalletDestination
from backend.settlement.profit_accounting import ProfitSettlement, SettlementBlocked
from backend.settlement.withdrawal import WithdrawalRequest, TreasuryWithdrawalEngine, WithdrawalBlocked

DEST = WalletDestination('USDT', 'TRC20', 'OWNER-ALLOWLISTED')

def engine():
    return TreasuryWithdrawalEngine(OwnerWallet([DEST]))

def req(**kw):
    base=dict(asset='USDT', network='TRC20', destination='OWNER-ALLOWLISTED', gross_amount=D('100'), fees=D('2'), fee_margin=D('1'))
    base.update(kw)
    return WithdrawalRequest(**base)

def test_net_profit_is_after_fees():
    r=ProfitSettlement().settle('100','7','2')
    assert r.final_net_profit == D('93')
    assert r.gross_profit == D('100') and r.fees == D('7')

def test_treasury_is_90_percent_of_verified_net():
    r=ProfitSettlement().settle('100','7')
    assert r.treasury_amount == D('83.7')
    assert r.operating_reserve == D('9.3')

def test_negative_profit_is_blocked():
    with pytest.raises(SettlementBlocked): ProfitSettlement().settle('-1','0')

def test_allowlisted_wallet_prepares():
    dest, net=engine().prepare(req())
    assert dest == DEST and net == D('98')

def test_unregistered_destination_is_blocked():
    with pytest.raises(PermissionError): engine().prepare(req(destination='UNKNOWN'))

def test_wrong_network_is_blocked():
    with pytest.raises(PermissionError): engine().prepare(req(network='ERC20'))

def test_missing_destination_fields_are_blocked():
    with pytest.raises(PermissionError): engine().prepare(req(destination=''))

def test_confirmation_requires_tx_confirmation():
    with pytest.raises(WithdrawalBlocked): engine().confirm(req(), DEST, D('98'), False)

def test_confirmation_requires_destination_match():
    other=WalletDestination('USDT','TRC20','OTHER')
    with pytest.raises(WithdrawalBlocked): engine().confirm(req(), other, D('98'), True)

def test_amount_must_reconcile():
    with pytest.raises(WithdrawalBlocked): engine().confirm(req(), DEST, D('97.99'), True)

def test_confirmed_delivery_returns_verified_net():
    r=engine().confirm(req(), DEST, D('98'), True)
    assert r.final_net_profit == D('98') and r.delivered_amount == D('98')

def test_fee_cannot_exceed_gross():
    with pytest.raises(WithdrawalBlocked): engine().prepare(req(fees=D('101')))
