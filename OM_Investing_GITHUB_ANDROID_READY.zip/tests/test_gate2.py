from decimal import Decimal

import pytest

from backend.core.master_contract import MASTER_CONTRACT
from backend.risk.position_sizing import SizeRequest, bounded_request, calculate_units, slice_units


def req(risk="0.001", requested=None):
    return SizeRequest(Decimal("10000"), Decimal(risk), Decimal("10"), Decimal("1"),
                       None if requested is None else Decimal(requested))


def test_baseline_size_uses_0_10_percent_risk_budget():
    assert calculate_units(req()) == Decimal("1")


def test_absolute_cap_is_enforced():
    calculate_units(req("0.002"))
    with pytest.raises(ValueError):
        calculate_units(req("0.0021"))


def test_requested_oversize_is_bounded_not_executed():
    assert bounded_request(req(requested="100")) == Decimal("1")


def test_requested_small_size_is_preserved():
    assert bounded_request(req(requested="0.25")) == Decimal("0.25")


def test_invalid_sizing_inputs_fail_closed():
    with pytest.raises(ValueError):
        calculate_units(SizeRequest(Decimal("10000"), Decimal("0.001"), Decimal("0"), Decimal("1")))


def test_slicing_keeps_total_and_bounds_each_child():
    parts = slice_units(Decimal("10"), Decimal("3"))
    assert len(parts) == 4
    assert sum(parts) == Decimal("10")
    assert all(p <= Decimal("3") for p in parts)


def test_cap_matches_master_contract():
    assert MASTER_CONTRACT.absolute_trade_risk_cap == 0.002
