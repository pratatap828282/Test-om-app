from dataclasses import replace
import pytest
from backend.update.update_center import UpdateBlocked, UpdateCandidate, UpdateCenter, UpdateStage


def candidate():
    return UpdateCandidate("v24.1", "S1_TO_1T", True, True, True, True, True)


def test_import_is_staging_only():
    c = UpdateCenter(); c.import_to_staging(candidate())
    assert c.stage is UpdateStage.STAGING


def test_unknown_target_is_blocked():
    c = UpdateCenter()
    with pytest.raises(UpdateBlocked):
        c.import_to_staging(replace(candidate(), target="OTHER"))


def test_blank_version_is_blocked():
    c = UpdateCenter()
    with pytest.raises(UpdateBlocked):
        c.import_to_staging(replace(candidate(), version=""))


def test_integrity_failure_blocks():
    c = UpdateCenter(); c.import_to_staging(replace(candidate(), payload_integrity_valid=False))
    with pytest.raises(UpdateBlocked): c.validate()


def test_security_failure_blocks():
    c = UpdateCenter(); c.import_to_staging(replace(candidate(), security_valid=False))
    with pytest.raises(UpdateBlocked): c.validate()


def test_compatibility_failure_blocks():
    c = UpdateCenter(); c.import_to_staging(replace(candidate(), compatibility_valid=False))
    with pytest.raises(UpdateBlocked): c.validate()


def test_master_target_change_blocks():
    c = UpdateCenter(); c.import_to_staging(replace(candidate(), master_target_unchanged=False))
    with pytest.raises(UpdateBlocked): c.validate()


def test_unauthorized_update_blocks():
    c = UpdateCenter(); c.import_to_staging(replace(candidate(), authorized=False))
    with pytest.raises(UpdateBlocked): c.validate()


def test_validation_then_checkpoint_then_activate():
    c = UpdateCenter(); c.import_to_staging(candidate()); c.validate(); c.checkpoint(); c.activate()
    assert c.stage is UpdateStage.ACTIVATED


def test_activation_without_validation_blocks():
    c = UpdateCenter(); c.import_to_staging(candidate())
    with pytest.raises(UpdateBlocked): c.activate()


def test_activation_without_checkpoint_blocks():
    c = UpdateCenter(); c.import_to_staging(candidate()); c.validate()
    with pytest.raises(UpdateBlocked): c.activate()


def test_rollback_is_terminal_for_current_candidate():
    c = UpdateCenter(); c.import_to_staging(candidate()); c.validate(); c.checkpoint(); c.rollback()
    assert c.stage is UpdateStage.ROLLED_BACK
