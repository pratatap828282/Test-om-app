import pytest
from backend.core.master_contract import TradingMode
from backend.strategy.decision_authority import DecisionAuthority, DecisionAuthorityBlocked, DecisionSeal
from backend.strategy.decision_contract import Decision, Side
from backend.strategy.decision_engine import DecisionEngine, DecisionInput
from backend.strategy.market_contract import MarketAnalysisContract


def valid_input():
    return DecisionInput(
        MarketAnalysisContract("XAUUSD", "M5", trend="bullish"),
        Side.BUY, TradingMode.NORMAL, True, True, 0.001, 0.1, True
    )


def test_engine_issues_authoritative_seal():
    seal = DecisionEngine().authorize(valid_input())
    assert isinstance(seal, DecisionSeal)
    assert DecisionAuthority.validate(seal).symbol == "XAUUSD"


def test_plain_decision_is_not_execution_authority():
    plain = Decision("XAUUSD", Side.BUY, TradingMode.NORMAL, True, True, True, True)
    with pytest.raises(DecisionAuthorityBlocked):
        DecisionAuthority.validate(plain)


def test_forged_seal_capability_is_blocked():
    plain = Decision("XAUUSD", Side.BUY, TradingMode.NORMAL, True, True, True, True)
    with pytest.raises(DecisionAuthorityBlocked):
        DecisionAuthority.validate(DecisionSeal(plain, object()))


def test_external_code_cannot_request_engine_capability():
    with pytest.raises(DecisionAuthorityBlocked):
        DecisionAuthority.capability()


def test_advisory_cannot_mint_decision_seal():
    plain = Decision("XAUUSD", Side.BUY, TradingMode.NORMAL, True, True, True, True)
    with pytest.raises(DecisionAuthorityBlocked):
        DecisionAuthority.issue(plain, object())


def test_engine_seal_does_not_bypass_authoritative_prerequisites():
    bad = valid_input()
    bad = DecisionInput(bad.analysis, bad.side, bad.mode, False, bad.reconciled, bad.risk_fraction, bad.feed_age_seconds, bad.analysis_complete)
    with pytest.raises(ValueError):
        DecisionEngine().authorize(bad)
