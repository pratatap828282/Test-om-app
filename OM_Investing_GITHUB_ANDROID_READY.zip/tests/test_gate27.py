from datetime import datetime, timedelta, timezone
import pytest
from backend.control.mobile_controller import MobileControllerLease, ControllerBlocked

T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)

def lease():
    c = MobileControllerLease()
    c.authenticate("device-A", authorized=True, at=T0)
    return c

def test_owner_authorized_device_acquires_lease():
    assert lease().state(T0).active_device_id == "device-A"

def test_unauthorized_device_rejected():
    with pytest.raises(ControllerBlocked): MobileControllerLease().authenticate("A", authorized=False, at=T0)

def test_empty_device_rejected():
    with pytest.raises(ControllerBlocked): MobileControllerLease().authenticate("", authorized=True, at=T0)

def test_second_device_cannot_take_active_lease():
    with pytest.raises(ControllerBlocked): lease().authenticate("device-B", authorized=True, at=T0 + timedelta(hours=1))

def test_recovery_hidden_before_72_hours():
    assert not lease().state(T0 + timedelta(hours=71, minutes=59)).recovery_visible

def test_recovery_visible_at_72_hours():
    assert lease().state(T0 + timedelta(hours=72)).recovery_visible

def test_recovery_requires_active_device():
    assert not lease().recovery_download_allowed("device-B", T0 + timedelta(hours=72))

def test_recovery_allowed_for_active_device():
    assert lease().recovery_download_allowed("device-A", T0 + timedelta(hours=72))

def test_old_device_auth_hides_recovery_again():
    c = lease()
    t = T0 + timedelta(hours=72)
    assert c.state(t).recovery_visible
    c.reauthenticate_old_device("device-A", authorized=True, at=t + timedelta(minutes=1))
    assert not c.state(t + timedelta(minutes=1)).recovery_visible

def test_deadman_sleep_at_9_days():
    s = lease().state(T0 + timedelta(days=9))
    assert s.sleep_mode and not s.recovery_visible

def test_recovery_window_ends_before_deadman():
    s = lease().state(T0 + timedelta(days=8, hours=23, minutes=59))
    assert s.recovery_visible and not s.sleep_mode

def test_backwards_clock_is_blocked():
    with pytest.raises(ControllerBlocked): lease().state(T0 - timedelta(seconds=1))
