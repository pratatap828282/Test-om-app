import pytest
from backend.execution.close_authority import CloseBlocked, CloseRequest, IndividualTradeCloser
from backend.execution.lifecycle import OrderLifecycle


def filled():
    x = OrderLifecycle("g48")
    x.submit_started(); x.broker_acknowledged("broker-g48"); x.filled()
    return x


def test_close_uses_original_trade_identity():
    x = filled()
    assert IndividualTradeCloser().close(x, CloseRequest("g48", "broker-g48")) == "g48"
    assert x.record.state.value == "CLOSED"


def test_wrong_client_order_is_blocked():
    with pytest.raises(CloseBlocked):
        IndividualTradeCloser().close(filled(), CloseRequest("other", "broker-g48"))


def test_wrong_broker_position_is_blocked():
    with pytest.raises(CloseBlocked):
        IndividualTradeCloser().close(filled(), CloseRequest("g48", "other"))


def test_missing_identity_is_blocked():
    with pytest.raises(CloseBlocked):
        IndividualTradeCloser().close(filled(), CloseRequest("", "broker-g48"))


def test_unfilled_trade_cannot_be_closed_as_a_position():
    x = OrderLifecycle("g48")
    with pytest.raises(CloseBlocked):
        IndividualTradeCloser().close(x, CloseRequest("g48", "broker-g48"))


def test_exiting_trade_can_finish_close_without_new_offset_order():
    x = filled(); x.begin_exit()
    assert IndividualTradeCloser().close(x, CloseRequest("g48", "broker-g48")) == "g48"
    assert x.record.state.value == "CLOSED"


def test_closed_trade_cannot_be_closed_again():
    x = filled(); IndividualTradeCloser().close(x, CloseRequest("g48", "broker-g48"))
    with pytest.raises((CloseBlocked, Exception)):
        IndividualTradeCloser().close(x, CloseRequest("g48", "broker-g48"))


def test_close_does_not_create_a_second_client_order():
    x = filled(); IndividualTradeCloser().close(x, CloseRequest("g48", "broker-g48"))
    assert x.record.client_order_id == "g48"
