import hashlib
import pytest
from backend.support.support_plane import (
    AssistantRequest, DoctorRepairRequest, SupportPlane, SupportPlaneBlocked
)


def test_assistant_is_advisory_only():
    r = SupportPlane().assistant_analyze(AssistantRequest("market research"))
    assert r.financial_authority is False


def test_assistant_empty_topic_blocked():
    with pytest.raises(SupportPlaneBlocked):
        SupportPlane().assistant_analyze(AssistantRequest("  "))


def test_unauthorized_assistant_request_blocked():
    with pytest.raises(SupportPlaneBlocked):
        SupportPlane().assistant_analyze(AssistantRequest("research", authorized=False))


@pytest.mark.parametrize("action", ["BUY", "SELL", "SUBMIT", "CLOSE", "WITHDRAW", "SETTLE", "CHANGE_RISK"])
def test_support_plane_cannot_authorize_financial_action(action):
    with pytest.raises(SupportPlaneBlocked):
        SupportPlane().authorize_financial_action(action)


def test_authorized_integrity_checked_repair_is_staged():
    content = b"validated support component"
    digest = hashlib.sha256(content).hexdigest()
    result = SupportPlane().doctor_repair(DoctorRepairRequest("assistant", content, True, digest))
    assert result == "STAGED_REPAIR_READY"


def test_unauthorized_repair_blocked():
    content = b"validated"
    digest = hashlib.sha256(content).hexdigest()
    with pytest.raises(SupportPlaneBlocked):
        SupportPlane().doctor_repair(DoctorRepairRequest("assistant", content, False, digest))


def test_repair_integrity_mismatch_blocked():
    with pytest.raises(SupportPlaneBlocked):
        SupportPlane().doctor_repair(DoctorRepairRequest("assistant", b"x", True, "0" * 64))


def test_invalid_integrity_reference_blocked():
    with pytest.raises(SupportPlaneBlocked):
        SupportPlane().doctor_repair(DoctorRepairRequest("assistant", b"x", True, "bad"))


def test_empty_repair_component_blocked():
    content = b"x"
    digest = hashlib.sha256(content).hexdigest()
    with pytest.raises(SupportPlaneBlocked):
        SupportPlane().doctor_repair(DoctorRepairRequest("", content, True, digest))


def test_bot_continues_when_assistant_and_doctor_unhealthy():
    assert SupportPlane().bot_execution_dependency_ok(False, False) is True
