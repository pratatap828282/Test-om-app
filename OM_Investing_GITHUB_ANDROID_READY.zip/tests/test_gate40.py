import pytest
from backend.hotpath.isolation import HotPathBlocked, HotPathIsolation, WorkClass, WorkRequest

def test_trading_work_may_use_hot_path():
    p = HotPathIsolation(); r = WorkRequest(WorkClass.TRADING, True)
    assert p.can_block_trading(r) is True
    assert p.can_authorize_financial_operation(r) is True

@pytest.mark.parametrize('kind', [WorkClass.SUPPORT, WorkClass.RESEARCH, WorkClass.DOCTOR, WorkClass.UI])
def test_support_plane_cannot_acquire_execution_authority(kind):
    with pytest.raises(HotPathBlocked):
        HotPathIsolation().validate(WorkRequest(kind, True))

@pytest.mark.parametrize('kind', [WorkClass.SUPPORT, WorkClass.RESEARCH, WorkClass.DOCTOR, WorkClass.UI])
def test_support_plane_cannot_block_trading(kind):
    assert HotPathIsolation().can_block_trading(WorkRequest(kind, False)) is False

@pytest.mark.parametrize('kind', [WorkClass.SUPPORT, WorkClass.RESEARCH, WorkClass.DOCTOR, WorkClass.UI])
def test_support_plane_cannot_authorize_finance(kind):
    assert HotPathIsolation().can_authorize_financial_operation(WorkRequest(kind, False)) is False

def test_invalid_work_class_is_fail_closed():
    with pytest.raises(HotPathBlocked):
        HotPathIsolation().validate(WorkRequest('unknown', False))

def test_trading_without_authority_cannot_authorize_finance():
    assert HotPathIsolation().can_authorize_financial_operation(WorkRequest(WorkClass.TRADING, False)) is False
