import threading
import pytest

from backend.execution.close_authority import CloseRequest
from backend.execution.close_execution_guard import ClosePositionSnapshot
from backend.execution.close_idempotency import AtomicCloseCoordinator, CloseIdempotencyBlocked
from backend.execution.lifecycle import OrderLifecycle


def filled(cid="c-50", bid="b-50"):
    x = OrderLifecycle(cid)
    x.submit_started(); x.broker_acknowledged(bid); x.filled()
    return x


def snap(cid="c-50", bid="b-50", **kw):
    base = dict(client_order_id=cid, broker_order_id=bid, position_open=True, reconciled=True)
    base.update(kw)
    return ClosePositionSnapshot(**base)


def test_same_close_intent_is_idempotently_blocked_after_success():
    x = filled(); c = AtomicCloseCoordinator(); r = CloseRequest("c-50", "b-50")
    assert c.close(x, r, snap()) == "c-50"
    assert c.completed(r)
    with pytest.raises(CloseIdempotencyBlocked):
        c.close(x, r, snap())


def test_failed_close_does_not_consume_intent():
    x = filled(); c = AtomicCloseCoordinator(); r = CloseRequest("c-50", "b-50")
    with pytest.raises(Exception):
        c.close(x, r, snap(reconciled=False))
    assert not c.completed(r)
    assert c.close(x, r, snap()) == "c-50"


def test_wrong_identity_is_not_marked_completed():
    x = filled(); c = AtomicCloseCoordinator(); r = CloseRequest("other", "b-50")
    with pytest.raises(Exception):
        c.close(x, r, snap())
    assert not c.completed(r)


def test_concurrent_duplicate_close_has_single_success():
    x = filled(); c = AtomicCloseCoordinator(); r = CloseRequest("c-50", "b-50")
    results, errors = [], []
    barrier = threading.Barrier(2)

    def worker():
        barrier.wait()
        try:
            results.append(c.close(x, r, snap()))
        except Exception as exc:
            errors.append(exc)

    threads = [threading.Thread(target=worker) for _ in range(2)]
    for t in threads: t.start()
    for t in threads: t.join()

    assert results == ["c-50"]
    assert len(errors) == 1
    assert isinstance(errors[0], CloseIdempotencyBlocked)
    assert x.record.state.value == "CLOSED"


def test_different_trade_identities_are_independent():
    c = AtomicCloseCoordinator()
    x1, x2 = filled("c-a", "b-a"), filled("c-b", "b-b")
    assert c.close(x1, CloseRequest("c-a", "b-a"), snap("c-a", "b-a")) == "c-a"
    assert c.close(x2, CloseRequest("c-b", "b-b"), snap("c-b", "b-b")) == "c-b"


def test_duplicate_does_not_create_new_trade_identity():
    x = filled(); c = AtomicCloseCoordinator(); r = CloseRequest("c-50", "b-50")
    c.close(x, r, snap())
    with pytest.raises(CloseIdempotencyBlocked):
        c.close(x, r, snap())
    assert x.record.client_order_id == "c-50"
    assert x.record.broker_order_id == "b-50"
