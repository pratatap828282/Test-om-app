import pytest
from backend.evidence.completeness import ExternalEvidenceSetGate, EvidenceSetError
from backend.evidence.external_verifier import EvidenceItem, EvidenceKind


def item(kind, **kw):
    base = dict(kind=kind, subject_id=f"live-{kind.value}", authorized=True,
                certificate_valid=True, integrity_valid=True, compatible=True,
                currently_valid=True, captured_at=1000.0, nonce="n", digest="d")
    base.update(kw)
    return EvidenceItem(**base)


def full_set():
    return [item(k) for k in EvidenceKind]


def test_complete_verified_external_set_passes():
    out = ExternalEvidenceSetGate().verify(full_set(), now=1100.0)
    assert out.complete is True
    assert len(out.items) == len(EvidenceKind)


def test_empty_set_blocks():
    with pytest.raises(EvidenceSetError):
        ExternalEvidenceSetGate().verify([], now=1100.0)


def test_missing_required_kind_blocks():
    values = full_set()[:-1]
    with pytest.raises(EvidenceSetError, match="required evidence missing"):
        ExternalEvidenceSetGate().verify(values, now=1100.0)


def test_duplicate_kind_blocks():
    values = full_set() + [item(EvidenceKind.BROKER, subject_id="second")]
    with pytest.raises(EvidenceSetError, match="duplicate evidence kind"):
        ExternalEvidenceSetGate().verify(values, now=1100.0)


def test_bad_item_type_blocks():
    values = full_set()
    values[0] = object()
    with pytest.raises(EvidenceSetError):
        ExternalEvidenceSetGate().verify(values, now=1100.0)


def test_untrusted_item_blocks_entire_set():
    values = full_set()
    values[2] = item(EvidenceKind.NETWORK, certificate_valid=False)
    with pytest.raises(EvidenceSetError):
        ExternalEvidenceSetGate().verify(values, now=1100.0)


def test_stale_item_blocks_entire_set():
    values = full_set()
    values[0] = item(EvidenceKind.BROKER, captured_at=0.0)
    with pytest.raises(EvidenceSetError):
        ExternalEvidenceSetGate().verify(values, now=1100.0)
