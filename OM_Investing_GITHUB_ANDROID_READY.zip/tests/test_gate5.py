import pytest
from backend.core.safety_contract import BrokerSnapshot, ExecutionSafetyGate, SafetyError, SafetyMode


def fresh():
    return BrokerSnapshot(True, 1000.0, frozenset(), 100.0)


def test_valid_reconciliation_allows_submit():
    g = ExecutionSafetyGate(); g.reconcile(fresh(), 101.0); g.authorize_submit("o1", 101.0)
    assert g.mode is SafetyMode.READY


def test_missing_reconciliation_fails_closed():
    g = ExecutionSafetyGate()
    with pytest.raises(SafetyError): g.authorize_submit("o1", 101.0)
    assert g.mode is SafetyMode.SAFE_MODE


def test_disconnected_broker_fails_closed():
    g = ExecutionSafetyGate()
    with pytest.raises(SafetyError): g.reconcile(BrokerSnapshot(False,1000,frozenset(),100),101)
    assert g.mode is SafetyMode.SAFE_MODE


def test_stale_feed_fails_closed():
    g = ExecutionSafetyGate()
    with pytest.raises(SafetyError): g.reconcile(BrokerSnapshot(True,1000,frozenset(),100),102.01)
    assert g.mode is SafetyMode.SAFE_MODE


def test_negative_equity_fails_closed():
    g = ExecutionSafetyGate()
    with pytest.raises(SafetyError): g.reconcile(BrokerSnapshot(True,-1,frozenset(),100),101)
    assert g.mode is SafetyMode.SAFE_MODE


def test_existing_broker_order_blocks_duplicate():
    g = ExecutionSafetyGate()
    g.reconcile(BrokerSnapshot(True,1000,frozenset({"o1"}),100),101)
    with pytest.raises(SafetyError): g.authorize_submit("o1",101)


def test_safe_mode_blocks_even_after_prior_reconciliation():
    g = ExecutionSafetyGate(); g.reconcile(fresh(),101); g.enter_safe_mode("operator safety stop")
    with pytest.raises(SafetyError): g.authorize_submit("o2",101)
