from decimal import Decimal
import pytest
from backend.broker.contract import BrokerSnapshot, BrokerSubmission
from backend.execution.submit_guard import FinalSubmitGuard, SubmitGuardError

def snap(**kw):
    base=dict(account_id="ACC", equity=Decimal("1000"), connected=True, reconciled=True, open_order_ids=frozenset())
    base.update(kw)
    return BrokerSnapshot(**base)

def order(i="o16"):
    return BrokerSubmission(i,"XAUUSD","BUY",Decimal("1"))

def test_final_snapshot_allows_submit():
    g=FinalSubmitGuard(); calls=[]
    r=g.submit(snap(),order(),lambda o:calls.append(o.client_order_id))
    assert r.state=="SUBMITTED" and calls==["o16"]

def test_missing_reconciliation_fails_closed():
    g=FinalSubmitGuard()
    with pytest.raises(SubmitGuardError): g.submit(snap(reconciled=False),order(),lambda o:None)
    assert g.safe_mode

def test_existing_broker_order_blocks_submission():
    g=FinalSubmitGuard()
    with pytest.raises(SubmitGuardError): g.submit(snap(open_order_ids=frozenset({"o16"})),order(),lambda o:None)
    assert g.safe_mode

def test_invalid_snapshot_fails_closed():
    g=FinalSubmitGuard()
    with pytest.raises(SubmitGuardError): g.submit(snap(account_id=""),order(),lambda o:None)
    assert g.safe_mode

def test_submission_exception_becomes_unknown_and_safe_mode():
    g=FinalSubmitGuard()
    def fail(_): raise TimeoutError("broker timeout")
    with pytest.raises(SubmitGuardError): g.submit(snap(),order(),fail)
    assert g.safe_mode and "o16" in g.unknown_order_ids

def test_unknown_cannot_continue_without_reconciliation():
    g=FinalSubmitGuard()
    with pytest.raises(SubmitGuardError): g.submit(snap(),order(),lambda o: (_ for _ in ()).throw(RuntimeError()))
    with pytest.raises(SubmitGuardError): g.resolve_unknown(snap(reconciled=False),"o16","FILLED")
    assert g.safe_mode

def test_unknown_resolves_only_to_recognized_state():
    g=FinalSubmitGuard()
    with pytest.raises(SubmitGuardError): g.submit(snap(),order(),lambda o: (_ for _ in ()).throw(RuntimeError()))
    with pytest.raises(SubmitGuardError): g.resolve_unknown(snap(),"o16","WEIRD")
    assert g.safe_mode

def test_unknown_filled_reconciles_and_releases_safe_mode():
    g=FinalSubmitGuard()
    with pytest.raises(SubmitGuardError): g.submit(snap(),order(),lambda o: (_ for _ in ()).throw(RuntimeError()))
    assert g.resolve_unknown(snap(),"o16","FILLED")=="FILLED"
    assert not g.safe_mode
