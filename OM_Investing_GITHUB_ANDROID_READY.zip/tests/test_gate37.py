import pytest
from backend.evidence.external_verifier import EvidenceItem, EvidenceKind
from backend.evidence.release_binding import ReleaseEvidenceBinder, EvidenceBindingError

NOW = 1_000_000.0

def item(kind, subject=None, captured=NOW):
    return EvidenceItem(kind=kind, subject_id=subject or kind.value, authorized=True,
                        certificate_valid=True, integrity_valid=True, compatible=True,
                        currently_valid=True, captured_at=captured, nonce="n-"+kind.value,
                        digest="d-"+kind.value)

def test_binding_requires_release_id():
    with pytest.raises(EvidenceBindingError):
        ReleaseEvidenceBinder().bind(" ", [item(EvidenceKind.BROKER)], now=NOW)

def test_binding_requires_evidence():
    with pytest.raises(EvidenceBindingError):
        ReleaseEvidenceBinder().bind("r1", [], now=NOW)

def test_binding_rejects_duplicate_kind():
    with pytest.raises(EvidenceBindingError):
        ReleaseEvidenceBinder().bind("r1", [item(EvidenceKind.BROKER), item(EvidenceKind.BROKER)], now=NOW)

def test_binding_rejects_invalid_evidence():
    bad = item(EvidenceKind.BROKER)
    bad = EvidenceItem(**{**bad.__dict__, "integrity_valid": False})
    with pytest.raises(EvidenceBindingError):
        ReleaseEvidenceBinder().bind("r1", [bad], now=NOW)

def test_binding_rejects_stale_evidence():
    with pytest.raises(EvidenceBindingError):
        ReleaseEvidenceBinder().bind("r1", [item(EvidenceKind.BROKER, captured=NOW-301)], now=NOW)

def test_binding_is_deterministic():
    b = ReleaseEvidenceBinder()
    a = [item(EvidenceKind.BROKER), item(EvidenceKind.NETWORK)]
    x = b.bind("r1", a, now=NOW)
    y = b.bind("r1", list(reversed(a)), now=NOW)
    assert x == y

def test_release_id_is_bound_in_manifest():
    m = ReleaseEvidenceBinder().bind("r1", [item(EvidenceKind.BROKER)], now=NOW)
    assert m.release_id == "r1" and len(m.evidence_digest) == 64

def test_count_is_exact():
    m = ReleaseEvidenceBinder().bind("r1", [item(EvidenceKind.BROKER), item(EvidenceKind.DEVICE)], now=NOW)
    assert m.evidence_count == 2
