import pytest
from backend.security.broker_login import (
    BrokerLoginCredentials, BrokerLoginDetails, BrokerLoginError, BrokerLoginGate,
)

class LiveLikeConnector:
    def __init__(self, platform):
        self.platform = platform
        self.received = None
    def login(self, credentials):
        self.received = credentials
        return BrokerLoginDetails(
            broker_name="ACTUAL-BROKER-FROM-SESSION",
            server="ACTUAL-SERVER-FROM-SESSION",
            account_id="ACTUAL-ACCOUNT-FROM-SESSION",
        )
    def connection_evidence(self, details):
        return "NON-SECRET-SESSION-EVIDENCE"

@pytest.mark.parametrize("platform", ["MT4", "MT5", "Trade W"])
def test_gate55_automatic_session_capture(platform):
    connector = LiveLikeConnector(platform)
    session = BrokerLoginGate(connector).login_and_capture(
        BrokerLoginCredentials("user", "ephemeral-secret", platform)
    )
    assert session.authenticated is True
    assert session.verified is True
    assert session.platform == platform
    assert session.broker_name == "ACTUAL-BROKER-FROM-SESSION"
    assert session.server == "ACTUAL-SERVER-FROM-SESSION"
    assert session.account_id == "ACTUAL-ACCOUNT-FROM-SESSION"
    assert session.connection_id == "NON-SECRET-SESSION-EVIDENCE"
    assert not hasattr(session, "password")
    assert not hasattr(session, "username")


def test_gate55_missing_session_evidence_fails_closed():
    class NoEvidence(LiveLikeConnector):
        def connection_evidence(self, details):
            return ""
    with pytest.raises(BrokerLoginError):
        BrokerLoginGate(NoEvidence("MT5")).login_and_capture(
            BrokerLoginCredentials("user", "secret", "MT5")
        )
