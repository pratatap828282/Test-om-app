import hashlib
import pytest
from backend.core.master_contract import TradingMode
from backend.strategy.advisory_bridge import AdvisoryDecisionBridge, AdvisoryIntegrationBlocked
from backend.strategy.decision_engine import DecisionInput
from backend.strategy.decision_contract import Side
from backend.strategy.market_contract import MarketAnalysisContract
from backend.support.assistant_boundary import Advisory, AssistantBlocked


def advisory():
    content = b"non-authoritative market context"
    return Advisory("research", content, True, hashlib.sha256(content).hexdigest())


def decision(**overrides):
    values = dict(
        analysis=MarketAnalysisContract("XAUUSD", "M5", trend="bullish"),
        side=Side.BUY,
        mode=TradingMode.NORMAL,
        validated=False,
        reconciled=False,
        risk_fraction=0.001,
        feed_age_seconds=0.1,
        analysis_complete=False,
    )
    values.update(overrides)
    return DecisionInput(**values)


def test_valid_advisory_attaches_as_context_only():
    original = decision()
    result, context = AdvisoryDecisionBridge().attach(original, advisory())
    assert result == original
    assert context.topic == "research"
    assert context.source == "ASSISTANT"


def test_advisory_cannot_turn_unvalidated_decision_into_validated():
    result, _ = AdvisoryDecisionBridge().attach(decision(), advisory())
    assert result.validated is False
    assert result.reconciled is False
    assert result.analysis_complete is False


def test_advisory_cannot_turn_unreconciled_decision_into_reconciled():
    result, _ = AdvisoryDecisionBridge().attach(decision(validated=True), advisory())
    assert result.validated is True
    assert result.reconciled is False


def test_advisory_cannot_replace_authoritative_analysis():
    original = decision()
    result, _ = AdvisoryDecisionBridge().attach(original, advisory())
    assert result.analysis is original.analysis
    assert result.side is original.side
    assert result.mode is original.mode


def test_invalid_advisory_is_blocked_before_attachment():
    content = b"x"
    bad = Advisory("research", content, True, "0" * 64)
    with pytest.raises(AssistantBlocked):
        AdvisoryDecisionBridge().attach(decision(), bad)


def test_unauthorized_advisory_is_blocked_before_attachment():
    a = advisory()
    bad = Advisory(a.topic, a.content, False, a.integrity_sha256)
    with pytest.raises(AssistantBlocked):
        AdvisoryDecisionBridge().attach(decision(), bad)


def test_advisory_cannot_authorize_financial_decision():
    with pytest.raises(AdvisoryIntegrationBlocked):
        AdvisoryDecisionBridge.authorize_from_advisory("BUY")


def test_advisory_cannot_be_promoted_to_execution():
    with pytest.raises(AdvisoryIntegrationBlocked):
        AdvisoryDecisionBridge.promote_to_execution(advisory())
