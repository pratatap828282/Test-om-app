import pytest
from backend.audit.ledger import AuditLedger, LedgerIntegrityError


def test_empty_ledger_is_integrity_valid():
    assert AuditLedger().verify_integrity() is True


def test_append_creates_ordered_record():
    ledger = AuditLedger()
    first = ledger.append("ORDER_CREATED", {"client_order_id": "c1"})
    second = ledger.append("ORDER_SUBMITTED", {"client_order_id": "c1"})
    assert first.sequence == 1
    assert second.sequence == 2
    assert second.previous_hash == first.record_hash


def test_genesis_anchor_is_fixed():
    ledger = AuditLedger()
    record = ledger.append("BOOT", {})
    assert record.previous_hash == AuditLedger.GENESIS


def test_hash_chain_integrity_passes():
    ledger = AuditLedger()
    ledger.append("A", {"v": 1})
    ledger.append("B", {"v": 2})
    assert ledger.verify_integrity() is True


def test_payload_tampering_is_detected():
    ledger = AuditLedger()
    ledger.append("A", {"v": 1})
    record = ledger.records[0]
    object.__setattr__(record, "payload", {"v": 999})
    with pytest.raises(LedgerIntegrityError):
        ledger.verify_integrity()


def test_hash_tampering_is_detected():
    ledger = AuditLedger()
    ledger.append("A", {})
    record = ledger.records[0]
    object.__setattr__(record, "record_hash", "f" * 64)
    with pytest.raises(LedgerIntegrityError):
        ledger.verify_integrity()


def test_previous_hash_tampering_is_detected():
    ledger = AuditLedger()
    ledger.append("A", {})
    ledger.append("B", {})
    record = ledger.records[1]
    object.__setattr__(record, "previous_hash", "f" * 64)
    with pytest.raises(LedgerIntegrityError):
        ledger.verify_integrity()


def test_sequence_tampering_is_detected():
    ledger = AuditLedger()
    ledger.append("A", {})
    record = ledger.records[0]
    object.__setattr__(record, "sequence", 2)
    with pytest.raises(LedgerIntegrityError):
        ledger.verify_integrity()


def test_invalid_event_is_rejected():
    ledger = AuditLedger()
    with pytest.raises(ValueError):
        ledger.append("", {})
    with pytest.raises(ValueError):
        ledger.append("A", [])


def test_integrity_can_be_required_before_sensitive_continuation():
    ledger = AuditLedger()
    ledger.append("EXECUTION", {"client_order_id": "c1"})
    ledger.require_integrity()
    object.__setattr__(ledger.records[0], "event_type", "TAMPERED")
    with pytest.raises(LedgerIntegrityError):
        ledger.require_integrity()
