import pytest
from backend.deployment.live_release_gate import LiveReleaseGate
from backend.deployment.external_evidence_gate import ExternalEvidence, EvidenceState, LiveReleaseBlocked
from backend.certification.certification_gate import CertificationEvidence
from backend.deployment.deploy_gate import DeploymentStage


def cert(**kw):
    base = dict(identity=True, certificate_trust=True, integrity=True,
                authorization=True, compatibility=True, currently_valid=True,
                operation_validated=True, audit_evidence=True)
    base.update(kw)
    return CertificationEvidence(**base)


def ext(**kw):
    base = dict(broker=EvidenceState.VERIFIED, primary_server=EvidenceState.VERIFIED,
                plan_b_servers=EvidenceState.VERIFIED, network=EvidenceState.VERIFIED,
                device=EvidenceState.VERIFIED, market_feed=EvidenceState.VERIFIED,
                blockchain=EvidenceState.VERIFIED)
    base.update(kw)
    return ExternalEvidence(**base)


def test_complete_boundaries_ready():
    d = LiveReleaseGate().assess(stage=DeploymentStage.STAGING, certification=cert(), external=ext())
    assert d.ready is True


def test_non_staging_blocks():
    d = LiveReleaseGate().assess(stage=DeploymentStage.ACTIVATED, certification=cert(), external=ext())
    assert d.ready is False


def test_certification_failure_blocks():
    d = LiveReleaseGate().assess(stage=DeploymentStage.STAGING, certification=cert(integrity=False), external=ext())
    assert d.ready is False


def test_external_missing_blocks():
    d = LiveReleaseGate().assess(stage=DeploymentStage.STAGING, certification=cert(), external=ext(blockchain=EvidenceState.MISSING))
    assert d.ready is False


def test_external_rejected_blocks():
    d = LiveReleaseGate().assess(stage=DeploymentStage.STAGING, certification=cert(), external=ext(broker=EvidenceState.REJECTED))
    assert d.ready is False


def test_require_ready_raises_when_not_ready():
    with pytest.raises(LiveReleaseBlocked):
        LiveReleaseGate().require_ready(stage=DeploymentStage.STAGING, certification=cert(), external=ext(network=EvidenceState.MISSING))


def test_complete_ready_does_not_mutate_evidence():
    evidence = ext()
    d = LiveReleaseGate().assess(stage=DeploymentStage.STAGING, certification=cert(), external=evidence)
    assert d.ready and evidence.blockchain is EvidenceState.VERIFIED


def test_certification_authorization_is_required():
    d = LiveReleaseGate().assess(stage=DeploymentStage.STAGING, certification=cert(authorization=False), external=ext())
    assert d.ready is False


def test_external_evidence_is_not_synthesized():
    d = LiveReleaseGate().assess(stage=DeploymentStage.STAGING, certification=cert(), external=ExternalEvidence())
    assert d.ready is False
