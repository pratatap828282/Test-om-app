import hashlib
import pytest
from backend.support.assistant_boundary import AssistantBlocked, Advisory, AdvisoryStatus, AssistantBoundary


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def valid():
    content = b"validated advisory"
    return Advisory("market-analysis", content, True, digest(content))


def test_valid_advisory_accepted():
    assert AssistantBoundary().validate_advisory(valid()) is AdvisoryStatus.ACCEPTED


def test_unauthorized_source_blocked():
    a = valid()
    with pytest.raises(AssistantBlocked):
        AssistantBoundary().validate_advisory(Advisory(a.topic, a.content, False, a.integrity_sha256))


def test_empty_topic_blocked():
    a = valid()
    with pytest.raises(AssistantBlocked):
        AssistantBoundary().validate_advisory(Advisory(" ", a.content, True, a.integrity_sha256))


def test_empty_content_blocked():
    with pytest.raises(AssistantBlocked):
        AssistantBoundary().validate_advisory(Advisory("analysis", b"", True, digest(b"")))


def test_invalid_integrity_reference_blocked():
    with pytest.raises(AssistantBlocked):
        AssistantBoundary().validate_advisory(Advisory("analysis", b"x", True, "bad"))


def test_integrity_mismatch_blocked():
    with pytest.raises(AssistantBlocked):
        AssistantBoundary().validate_advisory(Advisory("analysis", b"x", True, "0" * 64))


@pytest.mark.parametrize("operation", ["BUY", "SELL", "SUBMIT", "CLOSE", "MODIFY_ORDER", "CHANGE_RISK", "SETTLE", "WITHDRAW", "TREASURY", "ACTIVATE_RELEASE"])
def test_assistant_cannot_authorize_financial_operation(operation):
    with pytest.raises(AssistantBlocked):
        AssistantBoundary().authorize_operation(operation)


def test_assistant_cannot_authorize_nonfinancial_operation():
    with pytest.raises(AssistantBlocked):
        AssistantBoundary().authorize_operation("RESTART_COMPONENT")


def test_assistant_health_never_becomes_bot_execution_dependency():
    boundary = AssistantBoundary()
    assert boundary.is_execution_dependency(False) is False
    assert boundary.is_execution_dependency(True) is False
