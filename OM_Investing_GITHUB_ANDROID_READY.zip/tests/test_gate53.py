from decimal import Decimal
import pytest

from backend.analysis.market_analysis import AnalysisSnapshot
from backend.core.master_contract import TradingMode
from backend.strategy.decision_contract import Side
from backend.strategy.market_contract import MarketAnalysisContract
from backend.core.trading_pipeline import TradingPipeline, TradingPipelineBlocked


def analysis(symbol="XAUUSD", eligible=True):
    return AnalysisSnapshot(MarketAnalysisContract(
        symbol=symbol,
        timeframe="M5",
        trend="bullish",
        candle_pattern="engulfing",
        fibonacci_signal="valid",
        cross_signal="valid",
        cpi_context="neutral",
    ), corroborated=True, feed_valid=True)


def kwargs():
    return dict(
        analysis=analysis(), side=Side.BUY, mode=TradingMode.NORMAL,
        equity=Decimal("10000"), risk_fraction=Decimal("0.001"),
        stop_distance=Decimal("10"), value_per_unit_at_price=Decimal("1"),
        client_order_id="c53-1", broker_order_id="b53-1",
    )


def test_gate53_full_pipeline_completes_and_settles():
    result = TradingPipeline().execute_controlled_trade(**kwargs())
    assert result.client_order_id == "c53-1"
    assert result.broker_order_id == "b53-1"
    assert result.side is Side.BUY
    assert result.quantity == Decimal("1")
    assert result.settlement.final_net_profit == Decimal("1")
    assert result.ledger_records == 4


def test_gate53_sell_path():
    p = kwargs(); p["side"] = Side.SELL; p["client_order_id"] = "c53-s"; p["broker_order_id"] = "b53-s"
    result = TradingPipeline().execute_controlled_trade(**p)
    assert result.side is Side.SELL


def test_gate53_analysis_only_symbol_blocked():
    p = kwargs(); p["analysis"] = analysis("DXY", False)
    with pytest.raises(ValueError):
        TradingPipeline().execute_controlled_trade(**p)


def test_gate53_bad_identity_blocked():
    p = kwargs(); p["client_order_id"] = ""
    with pytest.raises(TradingPipelineBlocked):
        TradingPipeline().execute_controlled_trade(**p)


def test_gate53_risk_cap_still_applies():
    p = kwargs(); p["risk_fraction"] = Decimal("0.0021")
    with pytest.raises(ValueError):
        TradingPipeline().execute_controlled_trade(**p)
