import pytest
from backend.evidence.external_verifier import EvidenceItem, EvidenceKind
from backend.evidence.live_adapter import LiveEvidenceBoundary, LiveAdapterUnavailable


def item(kind=EvidenceKind.BROKER, **kw):
    base = dict(kind=kind, subject_id="live-1", authorized=True, certificate_valid=True,
                integrity_valid=True, compatible=True, currently_valid=True,
                captured_at=1000.0, nonce="n1", digest="d1")
    base.update(kw)
    return EvidenceItem(**base)


class Adapter:
    adapter_name = "broker-live"
    def __init__(self, evidence): self.evidence = evidence
    def collect(self): return self.evidence


def test_concrete_adapter_can_supply_current_verified_evidence():
    result = LiveEvidenceBoundary().collect_and_verify(Adapter(item()), now=1100.0)
    assert result.adapter_name == "broker-live"


def test_missing_adapter_blocks_live_boundary():
    with pytest.raises(LiveAdapterUnavailable):
        LiveEvidenceBoundary().collect_and_verify(None)


def test_missing_adapter_registry_blocks_all():
    with pytest.raises(LiveAdapterUnavailable):
        LiveEvidenceBoundary().require_all([], now=1100.0)


def test_non_typed_adapter_output_blocks():
    class Bad:
        def collect(self): return {"verified": True}
    with pytest.raises(LiveAdapterUnavailable):
        LiveEvidenceBoundary().collect_and_verify(Bad())


def test_stale_adapter_evidence_blocks():
    with pytest.raises(Exception):
        LiveEvidenceBoundary().collect_and_verify(Adapter(item(captured_at=0.0)), now=1000.0)


def test_unauthorized_adapter_evidence_blocks():
    with pytest.raises(Exception):
        LiveEvidenceBoundary().collect_and_verify(Adapter(item(authorized=False)), now=1100.0)


def test_invalid_certificate_blocks():
    with pytest.raises(Exception):
        LiveEvidenceBoundary().collect_and_verify(Adapter(item(certificate_valid=False)), now=1100.0)


def test_future_evidence_blocks():
    with pytest.raises(Exception):
        LiveEvidenceBoundary().collect_and_verify(Adapter(item(captured_at=1200.0)), now=1100.0)


def test_multiple_required_adapters_all_must_verify():
    adapters = [Adapter(item(EvidenceKind.BROKER)), Adapter(item(EvidenceKind.PRIMARY_SERVER))]
    out = LiveEvidenceBoundary().require_all(adapters, now=1100.0)
    assert len(out) == 2


def test_one_bad_adapter_blocks_whole_set():
    adapters = [Adapter(item(EvidenceKind.BROKER)), Adapter(item(EvidenceKind.DEVICE, integrity_valid=False))]
    with pytest.raises(Exception):
        LiveEvidenceBoundary().require_all(adapters, now=1100.0)


def test_adapter_identity_required():
    class NoName:
        def collect(self): return item()
    with pytest.raises(LiveAdapterUnavailable):
        LiveEvidenceBoundary().collect_and_verify(NoName(), now=1100.0)
