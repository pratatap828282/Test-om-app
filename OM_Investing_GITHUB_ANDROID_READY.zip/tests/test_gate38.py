import pytest
from backend.research.self_improvement import ImprovementCandidate, ImprovementStage, ImprovementBlocked, SelfImprovementGate

def candidate(**overrides):
    data = dict(candidate_id="imp-1", research_complete=True, analysis_complete=True,
                correlation_complete=True, tests_passed=True, validation_passed=True,
                security_valid=True, integrity_valid=True, master_target_unchanged=True,
                authorized=True, health_verified=True)
    data.update(overrides)
    return ImprovementCandidate(**data)

def test_full_controlled_pipeline():
    g=SelfImprovementGate(); g.submit(candidate())
    for s in [ImprovementStage.ANALYZED, ImprovementStage.CORRELATED, ImprovementStage.CANDIDATE,
              ImprovementStage.TESTED, ImprovementStage.VALIDATED, ImprovementStage.AUTHORIZED,
              ImprovementStage.STAGED, ImprovementStage.HEALTH_VERIFIED, ImprovementStage.ACTIVATED]:
        g.advance(s)
    assert g.stage is ImprovementStage.ACTIVATED

def test_missing_research_blocks_analysis():
    g=SelfImprovementGate(); g.submit(candidate(research_complete=False))
    with pytest.raises(ImprovementBlocked): g.advance(ImprovementStage.ANALYZED)

def test_missing_correlation_blocks():
    g=SelfImprovementGate(); g.submit(candidate(correlation_complete=False))
    g.advance(ImprovementStage.ANALYZED)
    with pytest.raises(ImprovementBlocked): g.advance(ImprovementStage.CORRELATED)

def test_failed_tests_block():
    g=SelfImprovementGate(); g.submit(candidate(tests_passed=False))
    for s in [ImprovementStage.ANALYZED, ImprovementStage.CORRELATED, ImprovementStage.CANDIDATE]: g.advance(s)
    with pytest.raises(ImprovementBlocked): g.advance(ImprovementStage.TESTED)

def test_validation_failure_blocks():
    g=SelfImprovementGate(); g.submit(candidate(validation_passed=False))
    for s in [ImprovementStage.ANALYZED, ImprovementStage.CORRELATED, ImprovementStage.CANDIDATE, ImprovementStage.TESTED]: g.advance(s)
    with pytest.raises(ImprovementBlocked): g.advance(ImprovementStage.VALIDATED)

def test_security_integrity_target_authorization_all_required():
    for field in ["security_valid", "integrity_valid", "master_target_unchanged", "authorized"]:
        g=SelfImprovementGate(); g.submit(candidate(**{field:False}))
        for s in [ImprovementStage.ANALYZED, ImprovementStage.CORRELATED, ImprovementStage.CANDIDATE, ImprovementStage.TESTED, ImprovementStage.VALIDATED]: g.advance(s)
        with pytest.raises(ImprovementBlocked): g.advance(ImprovementStage.AUTHORIZED)

def test_health_required_before_activation():
    g=SelfImprovementGate(); g.submit(candidate(health_verified=False))
    for s in [ImprovementStage.ANALYZED, ImprovementStage.CORRELATED, ImprovementStage.CANDIDATE, ImprovementStage.TESTED, ImprovementStage.VALIDATED, ImprovementStage.AUTHORIZED, ImprovementStage.STAGED]: g.advance(s)
    with pytest.raises(ImprovementBlocked): g.advance(ImprovementStage.HEALTH_VERIFIED)

def test_empty_identity_blocked():
    g=SelfImprovementGate()
    with pytest.raises(ImprovementBlocked): g.submit(candidate(candidate_id=" "))

def test_rejection_is_terminal_for_candidate():
    g=SelfImprovementGate(); g.submit(candidate()); g.advance(ImprovementStage.REJECTED)
    assert g.stage is ImprovementStage.REJECTED

def test_stage_regression_blocked():
    g=SelfImprovementGate(); g.submit(candidate()); g.advance(ImprovementStage.ANALYZED)
    with pytest.raises(ImprovementBlocked): g.advance(ImprovementStage.RESEARCH)
