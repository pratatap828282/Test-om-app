import pytest
from backend.deployment.transactional_release import (
    ReleaseBlocked, ReleaseSnapshot, ReleaseStage, TransactionalRelease,
)


def snap(**overrides):
    data = dict(release_id="release-39", integrity_valid=True,
                compatibility_valid=True, master_target_valid=True,
                health_valid=True)
    data.update(overrides)
    return ReleaseSnapshot(**data)


def test_full_transaction_and_rollback():
    r = TransactionalRelease(); r.stage_release(snap()); r.verify(); r.checkpoint(); r.activate()
    assert r.stage is ReleaseStage.ACTIVATED
    assert r.rollback() == "release-39"
    assert r.stage is ReleaseStage.ROLLED_BACK


def test_no_release_identity():
    r = TransactionalRelease()
    with pytest.raises(ReleaseBlocked): r.stage_release(snap(release_id=" "))


@pytest.mark.parametrize("field", ["integrity_valid", "compatibility_valid", "master_target_valid", "health_valid"])
def test_verification_failure_is_blocked(field):
    r = TransactionalRelease(); r.stage_release(snap(**{field: False}))
    with pytest.raises(ReleaseBlocked): r.verify()
    assert r.stage is ReleaseStage.STAGING


def test_checkpoint_requires_verified():
    r = TransactionalRelease(); r.stage_release(snap())
    with pytest.raises(ReleaseBlocked): r.checkpoint()


def test_activation_requires_checkpoint():
    r = TransactionalRelease(); r.stage_release(snap()); r.verify()
    with pytest.raises(ReleaseBlocked): r.activate()


def test_rollback_requires_checkpoint():
    r = TransactionalRelease(); r.stage_release(snap())
    with pytest.raises(ReleaseBlocked): r.rollback()
    assert r.stage is ReleaseStage.STAGING


def test_checkpoint_is_retained_for_rollback():
    r = TransactionalRelease(); r.stage_release(snap()); r.verify(); r.checkpoint()
    assert r.checkpointed is True
    r.activate(); r.rollback()
    assert r.checkpointed is True


def test_new_staged_release_invalidates_old_checkpoint():
    r = TransactionalRelease(); r.stage_release(snap()); r.verify(); r.checkpoint()
    r.stage_release(snap(release_id="release-new"))
    assert r.checkpointed is False
    with pytest.raises(ReleaseBlocked): r.rollback()
