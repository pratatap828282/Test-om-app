from backend.execution.order_state import OrderState, transition
from backend.execution.idempotency import IdempotencyRegistry


def test_valid_order_lifecycle():
    s = OrderState.NEW
    for nxt in (OrderState.SUBMITTING, OrderState.ACKNOWLEDGED, OrderState.FILLED, OrderState.EXITING, OrderState.CLOSED):
        s = transition(s, nxt)
    assert s is OrderState.CLOSED


def test_invalid_transition_blocked():
    try:
        transition(OrderState.NEW, OrderState.FILLED)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid transition was accepted")


def test_submit_exception_can_be_unknown():
    assert transition(OrderState.SUBMITTING, OrderState.UNKNOWN) is OrderState.UNKNOWN


def test_unknown_can_reconcile_forward():
    assert transition(OrderState.UNKNOWN, OrderState.ACKNOWLEDGED) is OrderState.ACKNOWLEDGED


def test_duplicate_order_blocked():
    r = IdempotencyRegistry(); r.reserve("o1", "fp1")
    try:
        r.reserve("o1", "fp1")
    except ValueError as e:
        assert "duplicate" in str(e)
    else:
        raise AssertionError("duplicate accepted")


def test_key_reuse_with_changed_fingerprint_blocked():
    r = IdempotencyRegistry(); r.reserve("o1", "fp1")
    try:
        r.reserve("o1", "fp2")
    except ValueError as e:
        assert "fingerprint" in str(e)
    else:
        raise AssertionError("mutated idempotency key accepted")
