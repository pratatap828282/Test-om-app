from decimal import Decimal
import pytest
from backend.core.execution_contract import ExecutionIntent, Side, validate_execution_intent


def valid():
    return ExecutionIntent("XAUUSD", Side.BUY, Decimal("0.001"), Decimal("0.5"), True, True)


def test_valid_buy():
    validate_execution_intent(valid())


def test_valid_sell():
    x = valid(); validate_execution_intent(ExecutionIntent(x.symbol, Side.SELL, x.risk_fraction, x.feed_age_seconds, True, True))

@pytest.mark.parametrize("symbol", ["EURUSD", "DXY"])
def test_non_xau_execution_rejected(symbol):
    x = valid();
    with pytest.raises(ValueError): validate_execution_intent(ExecutionIntent(symbol, x.side, x.risk_fraction, x.feed_age_seconds, True, True))


def test_stale_feed_rejected():
    x = valid();
    with pytest.raises(ValueError): validate_execution_intent(ExecutionIntent(x.symbol, x.side, x.risk_fraction, Decimal("2.0001"), True, True))


def test_unreconciled_rejected():
    x = valid();
    with pytest.raises(ValueError): validate_execution_intent(ExecutionIntent(x.symbol, x.side, x.risk_fraction, x.feed_age_seconds, False, True))


def test_unvalidated_decision_rejected():
    x = valid();
    with pytest.raises(ValueError): validate_execution_intent(ExecutionIntent(x.symbol, x.side, x.risk_fraction, x.feed_age_seconds, True, False))


def test_cap_boundary_allowed():
    x = valid(); validate_execution_intent(ExecutionIntent(x.symbol, x.side, Decimal("0.002"), x.feed_age_seconds, True, True))


def test_cap_above_rejected():
    x = valid();
    with pytest.raises(ValueError): validate_execution_intent(ExecutionIntent(x.symbol, x.side, Decimal("0.00201"), x.feed_age_seconds, True, True))


def test_negative_feed_rejected():
    x = valid();
    with pytest.raises(ValueError): validate_execution_intent(ExecutionIntent(x.symbol, x.side, x.risk_fraction, Decimal("-0.1"), True, True))


def test_zero_risk_rejected():
    x = valid();
    with pytest.raises(ValueError): validate_execution_intent(ExecutionIntent(x.symbol, x.side, Decimal("0"), x.feed_age_seconds, True, True))
