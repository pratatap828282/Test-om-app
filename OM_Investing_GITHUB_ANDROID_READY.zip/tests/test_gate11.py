import pytest
from backend.execution.lifecycle import OrderLifecycle, LifecycleError
from backend.execution.order_state import OrderState


def test_normal_lifecycle():
    o = OrderLifecycle("c1")
    assert o.submit_started().state is OrderState.SUBMITTING
    assert o.broker_acknowledged("b1").state is OrderState.ACKNOWLEDGED
    assert o.filled().state is OrderState.FILLED
    assert o.begin_exit().state is OrderState.EXITING
    assert o.closed().state is OrderState.CLOSED


def test_broker_identity_required():
    o = OrderLifecycle("c1")
    o.submit_started()
    with pytest.raises(LifecycleError):
        o.broker_acknowledged("")


def test_unknown_after_submit_is_allowed():
    o = OrderLifecycle("c1")
    o.submit_started()
    assert o.broker_outcome_unknown().state is OrderState.UNKNOWN


def test_unknown_requires_reconciliation():
    o = OrderLifecycle("c1")
    o.submit_started()
    o.broker_outcome_unknown()
    with pytest.raises(LifecycleError):
        o.filled()


def test_unknown_reconciles_to_filled():
    o = OrderLifecycle("c1")
    o.submit_started(); o.broker_outcome_unknown()
    assert o.reconcile_unknown("FILLED").state is OrderState.FILLED


def test_unknown_rejects_unrecognized_state():
    o = OrderLifecycle("c1")
    o.submit_started(); o.broker_outcome_unknown()
    with pytest.raises(LifecycleError):
        o.reconcile_unknown("UNKNOWN")


def test_unknown_never_auto_resubmits():
    o = OrderLifecycle("c1")
    o.submit_started(); o.broker_outcome_unknown()
    assert o.record.state is OrderState.UNKNOWN
    with pytest.raises(Exception):
        o.submit_started()


def test_reject_from_new():
    o = OrderLifecycle("c1")
    assert o.reject().state is OrderState.REJECTED


def test_closed_is_terminal():
    o = OrderLifecycle("c1")
    o.submit_started(); o.broker_acknowledged("b1"); o.filled(); o.begin_exit(); o.closed()
    with pytest.raises(Exception):
        o.closed()


def test_unknown_exit_requires_reconciliation():
    o = OrderLifecycle("c1")
    o.submit_started(); o.broker_acknowledged("b1"); o.filled(); o.begin_exit(); o.broker_outcome_unknown()
    with pytest.raises(LifecycleError):
        o.closed()
    assert o.reconcile_unknown("CLOSED").state is OrderState.CLOSED


def test_empty_client_order_id_rejected():
    with pytest.raises(ValueError):
        OrderLifecycle("")
