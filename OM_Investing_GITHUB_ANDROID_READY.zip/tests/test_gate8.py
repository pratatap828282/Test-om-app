from backend.analysis.market_analysis import AnalysisSnapshot
from backend.strategy.market_contract import MarketAnalysisContract
from backend.strategy.decision_contract import Side
from backend.strategy.decision_engine import DecisionEngine, DecisionInput
from backend.core.master_contract import TradingMode

TFS=("M1","M3","M5","M10","M15","M30","H1","H4","D1","W1","MN1")

def analysis(symbol="XAUUSD", tf="M15", dxy=None):
    return MarketAnalysisContract(symbol, tf, "engulfing", "bullish", "golden-cross", "retracement", "CPI-neutral", dxy)

def test_all_master_timeframes_supported():
    for tf in TFS: AnalysisSnapshot(analysis(tf=tf), True).validate()

def test_preferred_entry_timeframes_are_explicit():
    assert [analysis(tf=t).preferred_entry_timeframe for t in ("M5","M10","M15")] == [True,True,True]

def test_dxy_is_analysis_only():
    a=analysis("DXY","M15")
    assert not a.execution_eligible_symbol

def test_xauusd_can_use_dxy_context_without_changing_scope():
    a=analysis("XAUUSD","M15","strong")
    assert a.execution_eligible_symbol
    a.validate()

def test_missing_corroboration_blocks_snapshot():
    try: AnalysisSnapshot(analysis(), False).validate(); assert False
    except ValueError: pass

def test_invalid_feed_blocks_snapshot():
    try: AnalysisSnapshot(analysis(), True, False).validate(); assert False
    except ValueError: pass

def test_buy_authorized_only_after_all_gates():
    d=DecisionEngine().authorize(DecisionInput(analysis(),Side.BUY,TradingMode.NORMAL,True,True,0.001,0.5,True))
    assert d.side is Side.BUY

def test_sell_authorized_only_after_all_gates():
    d=DecisionEngine().authorize(DecisionInput(analysis(),Side.SELL,TradingMode.MEDIUM,True,True,0.001,0.5,True))
    assert d.side is Side.SELL

def test_dxy_execution_rejected():
    try: DecisionEngine().authorize(DecisionInput(analysis("DXY"),Side.BUY,TradingMode.NORMAL,True,True,0.001,0.5,True)); assert False
    except ValueError: pass

def test_stale_feed_rejected():
    try: DecisionEngine().authorize(DecisionInput(analysis(),Side.BUY,TradingMode.NORMAL,True,True,0.001,2.01,True)); assert False
    except ValueError: pass

def test_missing_validation_rejected():
    try: DecisionEngine().authorize(DecisionInput(analysis(),Side.BUY,TradingMode.NORMAL,False,True,0.001,0.5,True)); assert False
    except ValueError: pass

def test_missing_reconciliation_rejected():
    try: DecisionEngine().authorize(DecisionInput(analysis(),Side.BUY,TradingMode.NORMAL,True,False,0.001,0.5,True)); assert False
    except ValueError: pass

def test_risk_cap_rejected():
    try: DecisionEngine().authorize(DecisionInput(analysis(),Side.BUY,TradingMode.NORMAL,True,True,0.0021,0.5,True)); assert False
    except ValueError: pass
