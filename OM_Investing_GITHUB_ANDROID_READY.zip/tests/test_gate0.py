import pytest
from backend.core.master_contract import MASTER_CONTRACT, TradingMode
from backend.core.invariants import (
    validate_feed_age, validate_mode_appetite, validate_symbol_scope, validate_trade_risk,
)


def test_master_contract_is_self_consistent():
    MASTER_CONTRACT.validate()
    assert MASTER_CONTRACT.target == "S1 → $1T"
    assert MASTER_CONTRACT.treasury_pct == 0.90
    assert MASTER_CONTRACT.operating_reserve_pct == 0.10
    assert MASTER_CONTRACT.absolute_trade_risk_cap == 0.002
    assert MASTER_CONTRACT.server_priority == ("Singapore", "Germany", "Asia", "USA", "India")


def test_modes_are_strategy_appetite_not_monetary_risk():
    validate_mode_appetite(TradingMode.NORMAL, 100)
    validate_mode_appetite(TradingMode.MEDIUM, 50)
    validate_mode_appetite(TradingMode.BOOST, 75)
    with pytest.raises(ValueError):
        validate_mode_appetite(TradingMode.BOOST, 200)


def test_trade_risk_cap_is_immutable():
    validate_trade_risk(0.001)
    validate_trade_risk(0.002)
    with pytest.raises(ValueError):
        validate_trade_risk(0.0020001)


def test_scope_is_xauusd_execution_and_dxy_analysis_only():
    validate_symbol_scope("XAUUSD", execution=True)
    validate_symbol_scope("DXY", execution=False)
    with pytest.raises(ValueError):
        validate_symbol_scope("DXY", execution=True)


def test_feed_guard():
    validate_feed_age(0.5)
    validate_feed_age(2.0)
    with pytest.raises(ValueError):
        validate_feed_age(2.000001)
