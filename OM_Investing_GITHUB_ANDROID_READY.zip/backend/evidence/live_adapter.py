"""Gate 34: live-environment adapter boundary.

External evidence may satisfy live release only when it comes from an explicit
adapter implementation.  Synthetic/manual evidence is never accepted as a
substitute for a live adapter result.
"""
from dataclasses import dataclass
from typing import Protocol

from backend.evidence.external_verifier import EvidenceItem, ExternalEvidenceVerifier, EvidenceValidationError


class LiveAdapterUnavailable(RuntimeError):
    pass


class LiveEvidenceAdapter(Protocol):
    kind: object

    def collect(self) -> EvidenceItem: ...


@dataclass(frozen=True)
class AdapterCollection:
    adapter_name: str
    evidence: EvidenceItem


class LiveEvidenceBoundary:
    """Require a concrete adapter plus current evidence before live promotion."""

    def __init__(self, verifier: ExternalEvidenceVerifier | None = None) -> None:
        self.verifier = verifier or ExternalEvidenceVerifier()

    def collect_and_verify(self, adapter: LiveEvidenceAdapter, *, now: float | None = None) -> AdapterCollection:
        if adapter is None or not callable(getattr(adapter, "collect", None)):
            raise LiveAdapterUnavailable("live evidence adapter is unavailable")
        evidence = adapter.collect()
        if not isinstance(evidence, EvidenceItem):
            raise LiveAdapterUnavailable("adapter returned no typed external evidence")
        self.verifier.require(evidence, now=now)
        name = getattr(adapter, "adapter_name", None)
        if not isinstance(name, str) or not name.strip():
            raise LiveAdapterUnavailable("adapter identity is missing")
        return AdapterCollection(name.strip(), evidence)

    def require_all(self, adapters: list[LiveEvidenceAdapter], *, now: float | None = None) -> tuple[AdapterCollection, ...]:
        if not adapters:
            raise LiveAdapterUnavailable("no live evidence adapters registered")
        return tuple(self.collect_and_verify(a, now=now) for a in adapters)
