"""Gate 37: bind verified external evidence to a specific release decision.

The binding layer does not create live evidence. It makes a deterministic,
cryptographically bound manifest from evidence that has already passed the
live-evidence verifier, preventing evidence from one release/context being
silently reused for another.
"""
from dataclasses import dataclass
import hashlib
import json

from backend.evidence.external_verifier import EvidenceItem, ExternalEvidenceVerifier, EvidenceValidationError
from backend.evidence.live_adapter import LiveEvidenceBoundary, AdapterCollection


class EvidenceBindingError(ValueError):
    pass


@dataclass(frozen=True)
class ReleaseEvidenceManifest:
    release_id: str
    evidence_digest: str
    evidence_count: int


class ReleaseEvidenceBinder:
    def __init__(self, verifier: ExternalEvidenceVerifier | None = None) -> None:
        self.verifier = verifier or ExternalEvidenceVerifier()

    @staticmethod
    def _canonical(item: EvidenceItem) -> str:
        payload = {
            "kind": item.kind.value,
            "subject_id": item.subject_id,
            "authorized": item.authorized,
            "certificate_valid": item.certificate_valid,
            "integrity_valid": item.integrity_valid,
            "compatible": item.compatible,
            "currently_valid": item.currently_valid,
            "captured_at": item.captured_at,
            "nonce": item.nonce,
            "digest": item.digest,
        }
        return json.dumps(payload, sort_keys=True, separators=(",", ":"))

    def bind(self, release_id: str, items: list[EvidenceItem], *, now: float) -> ReleaseEvidenceManifest:
        if not release_id.strip():
            raise EvidenceBindingError("release identity is required")
        if not items:
            raise EvidenceBindingError("verified evidence is required")
        seen = set()
        canonical = []
        for item in items:
            if not isinstance(item, EvidenceItem):
                raise EvidenceBindingError("evidence item type is invalid")
            if item.kind in seen:
                raise EvidenceBindingError("duplicate evidence kind")
            seen.add(item.kind)
            try:
                self.verifier.require(item, now=now)
            except EvidenceValidationError as exc:
                raise EvidenceBindingError(str(exc)) from exc
            canonical.append(self._canonical(item))
        digest = hashlib.sha256("\n".join(sorted(canonical)).encode()).hexdigest()
        return ReleaseEvidenceManifest(release_id.strip(), digest, len(items))
