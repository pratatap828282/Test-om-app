"""Gate 35: complete, non-ambiguous external evidence set.

The gate validates that every required live-environment evidence category is
represented exactly once and that every item is independently verified.
"""
from dataclasses import dataclass
from backend.evidence.external_verifier import EvidenceItem, EvidenceValidationError, ExternalEvidenceVerifier, EvidenceKind


class EvidenceSetError(ValueError):
    pass


@dataclass(frozen=True)
class EvidenceSetResult:
    complete: bool
    items: tuple[EvidenceItem, ...]


class ExternalEvidenceSetGate:
    REQUIRED_KINDS = frozenset(EvidenceKind)

    def __init__(self, verifier: ExternalEvidenceVerifier | None = None) -> None:
        self.verifier = verifier or ExternalEvidenceVerifier()

    def verify(self, items: list[EvidenceItem], *, now: float) -> EvidenceSetResult:
        if not items:
            raise EvidenceSetError("external evidence set is empty")
        seen: set[EvidenceKind] = set()
        verified: list[EvidenceItem] = []
        for item in items:
            if not isinstance(item, EvidenceItem):
                raise EvidenceSetError("evidence set contains an invalid item")
            if item.kind in seen:
                raise EvidenceSetError(f"duplicate evidence kind: {item.kind.value}")
            seen.add(item.kind)
            try:
                self.verifier.require(item, now=now)
            except EvidenceValidationError as exc:
                raise EvidenceSetError(str(exc)) from exc
            verified.append(item)
        missing = self.REQUIRED_KINDS - seen
        if missing:
            names = ", ".join(sorted(k.value for k in missing))
            raise EvidenceSetError(f"required evidence missing: {names}")
        return EvidenceSetResult(True, tuple(verified))
