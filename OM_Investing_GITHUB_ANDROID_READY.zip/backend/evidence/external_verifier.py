"""Gate 22: verify the integrity and validity of externally supplied evidence.

No local test result is converted into external evidence.  Evidence must carry
identity, authorization, integrity, and current-validity assertions before it
can satisfy the live-release boundary.
"""
from dataclasses import dataclass
from enum import Enum
from time import time


class EvidenceKind(str, Enum):
    BROKER = "broker"
    PRIMARY_SERVER = "primary_server"
    PLAN_B_SERVERS = "plan_b_servers"
    NETWORK = "network"
    DEVICE = "device"
    MARKET_FEED = "market_feed"
    BLOCKCHAIN = "blockchain"


class EvidenceValidationError(ValueError):
    pass


@dataclass(frozen=True)
class EvidenceItem:
    kind: EvidenceKind
    subject_id: str
    authorized: bool
    certificate_valid: bool
    integrity_valid: bool
    compatible: bool
    currently_valid: bool
    captured_at: float
    nonce: str
    digest: str


@dataclass(frozen=True)
class VerificationResult:
    verified: bool
    reason: str


class ExternalEvidenceVerifier:
    """Strict verifier for evidence supplied by real deployment adapters."""

    MAX_AGE_SECONDS = 300.0

    def verify(self, item: EvidenceItem, now: float | None = None) -> VerificationResult:
        now = time() if now is None else now
        if not item.subject_id or not item.nonce or not item.digest:
            return VerificationResult(False, "missing identity/integrity fields")
        if not item.authorized:
            return VerificationResult(False, "unauthorized evidence subject")
        if not item.certificate_valid:
            return VerificationResult(False, "certificate/trust invalid")
        if not item.integrity_valid:
            return VerificationResult(False, "evidence integrity invalid")
        if not item.compatible:
            return VerificationResult(False, "evidence compatibility invalid")
        if not item.currently_valid:
            return VerificationResult(False, "evidence no longer valid")
        if item.captured_at > now:
            return VerificationResult(False, "evidence timestamp is in the future")
        if now - item.captured_at > self.MAX_AGE_SECONDS:
            return VerificationResult(False, "evidence is stale")
        return VerificationResult(True, "verified")

    def require(self, item: EvidenceItem, now: float | None = None) -> None:
        result = self.verify(item, now)
        if not result.verified:
            raise EvidenceValidationError(result.reason)
