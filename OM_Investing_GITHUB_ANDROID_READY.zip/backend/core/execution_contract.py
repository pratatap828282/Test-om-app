"""Fresh execution safety contract: validate before any order submission."""
from dataclasses import dataclass
from decimal import Decimal
from enum import Enum

from backend.core.invariants import validate_feed_age, validate_symbol_scope, validate_trade_risk


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


@dataclass(frozen=True)
class ExecutionIntent:
    symbol: str
    side: Side
    risk_fraction: Decimal
    feed_age_seconds: Decimal
    reconciled: bool
    decision_validated: bool


def validate_execution_intent(intent: ExecutionIntent) -> None:
    validate_symbol_scope(intent.symbol, execution=True)
    validate_feed_age(float(intent.feed_age_seconds))
    validate_trade_risk(float(intent.risk_fraction))
    if not intent.reconciled:
        raise ValueError("broker/account reconciliation is required before execution")
    if not intent.decision_validated:
        raise ValueError("authoritative decision validation is required before execution")
