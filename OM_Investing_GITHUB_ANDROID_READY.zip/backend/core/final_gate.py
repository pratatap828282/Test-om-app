"""Final source-level gate for the fresh OM Investing System.

This is the final internal release-candidate gate. It proves the consolidated
core path and the release boundary compose together. It deliberately keeps
live release blocked until independently verified external evidence exists.
"""
from dataclasses import dataclass
from decimal import Decimal

from backend.analysis.market_analysis import AnalysisSnapshot
from backend.core.master_contract import TradingMode
from backend.core.trading_pipeline import TradingPipeline, PipelineResult
from backend.strategy.decision_contract import Side
from backend.strategy.market_contract import MarketAnalysisContract
from backend.certification.certification_gate import (
    CertificationEvidence, CertificationGate, OperationScope,
)
from backend.deployment.external_evidence_gate import (
    ExternalEvidence, ExternalEvidenceGate,
)
from backend.deployment.deploy_gate import DeploymentStage
from backend.deployment.transactional_release import TransactionalRelease, ReleaseSnapshot


@dataclass(frozen=True)
class FinalGateReport:
    core_e2e_passed: bool
    certification_passed: bool
    release_transaction_passed: bool
    live_release_blocked_without_external_evidence: bool

    @property
    def passed(self) -> bool:
        return all((self.core_e2e_passed, self.certification_passed,
                    self.release_transaction_passed,
                    self.live_release_blocked_without_external_evidence))


def _analysis(symbol: str = "XAUUSD") -> AnalysisSnapshot:
    return AnalysisSnapshot(MarketAnalysisContract(
        symbol=symbol,
        timeframe="M5",
        trend="bullish",
        candle_pattern="engulfing",
        fibonacci_signal="valid",
        cross_signal="valid",
        cpi_context="neutral",
    ), corroborated=True, feed_valid=True)


def run_final_source_gate() -> tuple[FinalGateReport, PipelineResult]:
    pipeline = TradingPipeline()
    result = pipeline.execute_controlled_trade(
        analysis=_analysis(), side=Side.BUY, mode=TradingMode.NORMAL,
        equity=Decimal("10000"), risk_fraction=Decimal("0.001"),
        stop_distance=Decimal("10"), value_per_unit_at_price=Decimal("1"),
        client_order_id="final-gate-1", broker_order_id="final-broker-1",
        fee=Decimal("0.10"), fee_margin=Decimal("0.20"),
    )
    core_ok = (
        result.side is Side.BUY
        and result.quantity == Decimal("1")
        and result.settlement.final_net_profit == Decimal("0.90")
        and result.settlement.treasury_amount == Decimal("0.810")
        and result.settlement.operating_reserve == Decimal("0.090")
        and result.ledger_records == 4
    )

    cert = CertificationEvidence(True, True, True, True, True, True, True, True)
    cert_ok = CertificationGate().certify(OperationScope.EXECUTION, cert).certified

    release = TransactionalRelease()
    release.stage_release(ReleaseSnapshot("FINAL-RC", True, True, True, True))
    release.verify()
    release.checkpoint()
    release.activate()
    release_ok = release.stage.value == "ACTIVATED"

    external = ExternalEvidenceGate().assess(ExternalEvidence())
    blocked_without_external = not external.ready_for_live

    return FinalGateReport(core_ok, cert_ok, release_ok, blocked_without_external), result
