"""Fresh Gate 5: fail-closed execution safety and reconciliation contract."""
from dataclasses import dataclass
from enum import Enum


class SafetyMode(str, Enum):
    READY = "READY"
    SAFE_MODE = "SAFE_MODE"


class SafetyError(RuntimeError):
    pass


@dataclass(frozen=True)
class BrokerSnapshot:
    connected: bool
    equity: float
    open_order_ids: frozenset[str]
    price_timestamp: float


class ExecutionSafetyGate:
    STALE_FEED_SECONDS = 2.0

    def __init__(self) -> None:
        self.mode = SafetyMode.READY
        self._last_snapshot: BrokerSnapshot | None = None

    def enter_safe_mode(self, reason: str) -> None:
        if not reason.strip():
            raise SafetyError("SAFE_MODE requires a reason")
        self.mode = SafetyMode.SAFE_MODE

    def reconcile(self, snapshot: BrokerSnapshot, now: float) -> None:
        if snapshot.equity < 0:
            self.enter_safe_mode("invalid equity")
            raise SafetyError("invalid broker snapshot")
        if not snapshot.connected:
            self.enter_safe_mode("broker disconnected")
            raise SafetyError("broker disconnected")
        if now - snapshot.price_timestamp > self.STALE_FEED_SECONDS:
            self.enter_safe_mode("stale market feed")
            raise SafetyError("stale market feed")
        self._last_snapshot = snapshot
        self.mode = SafetyMode.READY

    def authorize_submit(self, order_id: str, now: float) -> None:
        if self.mode is SafetyMode.SAFE_MODE:
            raise SafetyError("submission blocked in SAFE_MODE")
        if self._last_snapshot is None:
            self.enter_safe_mode("missing reconciliation")
            raise SafetyError("submission blocked without reconciliation")
        if now - self._last_snapshot.price_timestamp > self.STALE_FEED_SECONDS:
            self.enter_safe_mode("snapshot became stale")
            raise SafetyError("submission blocked by stale snapshot")
        if order_id in self._last_snapshot.open_order_ids:
            raise SafetyError("duplicate broker order id")
