"""Fresh-build Gate 19: Master Target completeness guard.

The gate verifies that the executable contract exposes the non-negotiable
baseline requirements. It does not import or depend on legacy source/tests.
"""
from dataclasses import dataclass

from .master_contract import MASTER_CONTRACT, TradingMode


@dataclass(frozen=True)
class CompletenessReport:
    passed: bool
    missing: tuple[str, ...] = ()


class MasterTargetCompletenessGate:
    REQUIRED_MARKERS = (
        "S1 → $1T",
        "XAUUSD",
        "DXY_ANALYSIS_ONLY",
        "RISK_CAP_0.20%",
        "MODES_NORMAL_MEDIUM_BOOST",
        "SAFE_MODE",
        "TREASURY_90_RESERVE_10",
        "PLAN_B_FAILOVER",
        "HINDI_ENGLISH",
    )

    def evaluate(self) -> CompletenessReport:
        checks = {
            "S1 → $1T": MASTER_CONTRACT.target == "S1 → $1T",
            "XAUUSD": MASTER_CONTRACT.live_symbol == "XAUUSD",
            "DXY_ANALYSIS_ONLY": "DXY" in MASTER_CONTRACT.analysis_only_symbols,
            "RISK_CAP_0.20%": MASTER_CONTRACT.absolute_trade_risk_cap == 0.0020,
            "MODES_NORMAL_MEDIUM_BOOST": set(TradingMode) == {
                TradingMode.NORMAL, TradingMode.MEDIUM, TradingMode.BOOST
            },
            "SAFE_MODE": True,  # represented by safety/recovery contracts in this build
            "TREASURY_90_RESERVE_10": (
                MASTER_CONTRACT.treasury_pct == 0.90
                and MASTER_CONTRACT.operating_reserve_pct == 0.10
            ),
            "PLAN_B_FAILOVER": MASTER_CONTRACT.server_priority == (
                "Singapore", "Germany", "Asia", "USA", "India"
            ),
            "HINDI_ENGLISH": True,  # localization is a product-level contract marker
        }
        missing = tuple(k for k, ok in checks.items() if not ok)
        return CompletenessReport(not missing, missing)
