"""Fresh OM Investing System master contract.

This module contains requirements only; it intentionally does not import legacy
implementation modules or legacy tests.
"""
from dataclasses import dataclass
from enum import Enum


class TradingMode(str, Enum):
    NORMAL = "NORMAL"
    MEDIUM = "MEDIUM"
    BOOST = "BOOST"


@dataclass(frozen=True)
class MasterContract:
    target: str = "S1 → $1T"
    live_symbol: str = "XAUUSD"
    analysis_only_symbols: tuple[str, ...] = ("DXY",)
    absolute_trade_risk_cap: float = 0.0020
    baseline_trade_risk: float = 0.0010
    treasury_pct: float = 0.90
    operating_reserve_pct: float = 0.10
    live_operation_window: str = "24x5"
    research_health_window: str = "24x2"
    stale_feed_seconds: float = 2.0
    supported_timeframes: tuple[str, ...] = (
        "M1", "M3", "M5", "M10", "M15", "M30", "H1", "H4", "D1", "W1", "MN1"
    )
    preferred_entry_timeframes: tuple[str, ...] = ("M5", "M10", "M15")
    server_priority: tuple[str, ...] = ("Singapore", "Germany", "Asia", "USA", "India")

    def validate(self) -> None:
        if not self.target or not self.live_symbol:
            raise ValueError("master target and live symbol are required")
        if not 0 < self.baseline_trade_risk <= self.absolute_trade_risk_cap <= 0.0020:
            raise ValueError("invalid immutable trade-risk limits")
        if abs((self.treasury_pct + self.operating_reserve_pct) - 1.0) > 1e-12:
            raise ValueError("treasury allocation must equal 100%")
        if self.treasury_pct != 0.90 or self.operating_reserve_pct != 0.10:
            raise ValueError("current treasury contract must be 90/10")
        if self.stale_feed_seconds <= 0:
            raise ValueError("stale-feed threshold must be positive")
        if self.live_symbol in self.analysis_only_symbols:
            raise ValueError("live symbol cannot be analysis-only")
        if "M5" not in self.preferred_entry_timeframes or "M10" not in self.preferred_entry_timeframes or "M15" not in self.preferred_entry_timeframes:
            raise ValueError("preferred validation entry timeframes are incomplete")


MASTER_CONTRACT = MasterContract()
MASTER_CONTRACT.validate()
