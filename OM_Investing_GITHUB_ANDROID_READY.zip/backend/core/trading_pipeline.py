"""Gate 53: cohesive internal trading lifecycle integration.

Composes the fresh contracts without granting authority to any support subsystem.
This is a controlled internal integration boundary; it does not claim live broker
or live-market evidence.
"""
from dataclasses import dataclass
from decimal import Decimal

from backend.analysis.market_analysis import AnalysisSnapshot
from backend.audit.ledger import AuditLedger
from backend.broker.contract import BrokerSnapshot, BrokerSubmission
from backend.broker.coordinator import BrokerExecutionCoordinator
from backend.execution.authority_gate import ExecutionAuthorityGate, ExecutionRequest
from backend.execution.close_authority import CloseRequest, IndividualTradeCloser
from backend.execution.close_evidence import CloseEvidence, EvidenceBoundBrokerClose
from backend.execution.lifecycle import OrderLifecycle
from backend.execution.submission import OrderSubmissionCoordinator, SubmissionRequest
from backend.core.execution_contract import ExecutionIntent, Side as ExecutionSide
from backend.core.invariants import validate_trade_risk
from backend.core.master_contract import TradingMode
from backend.risk.position_sizing import SizeRequest, bounded_request
from backend.settlement.profit_accounting import ProfitSettlement, SettlementResult
from backend.strategy.decision_engine import DecisionEngine, DecisionInput
from backend.strategy.decision_contract import Side


@dataclass(frozen=True)
class PipelineResult:
    client_order_id: str
    broker_order_id: str
    side: Side
    quantity: Decimal
    close_evidence_id: str
    settlement: SettlementResult
    ledger_records: int


class TradingPipelineBlocked(RuntimeError):
    pass


class TradingPipeline:
    """Single internal path: analysis -> decision -> risk -> broker -> close -> ledger."""

    def __init__(self) -> None:
        self.decisions = DecisionEngine()
        self.authority = ExecutionAuthorityGate()
        self.submissions = OrderSubmissionCoordinator()
        self.broker = BrokerExecutionCoordinator()
        self.closer = IndividualTradeCloser()
        self.close_evidence = EvidenceBoundBrokerClose()
        self.settlement = ProfitSettlement()
        self.ledger = AuditLedger()

    def execute_controlled_trade(
        self,
        *,
        analysis: AnalysisSnapshot,
        side: Side,
        mode: TradingMode,
        equity: Decimal,
        risk_fraction: Decimal,
        stop_distance: Decimal,
        value_per_unit_at_price: Decimal,
        client_order_id: str,
        broker_order_id: str,
        fee: Decimal = Decimal("0"),
        fee_margin: Decimal = Decimal("0"),
    ) -> PipelineResult:
        if not client_order_id or not broker_order_id:
            raise TradingPipelineBlocked("trade identities are required")
        analysis.validate()
        validate_trade_risk(float(risk_fraction))
        quantity = bounded_request(SizeRequest(
            equity=equity,
            risk_fraction=risk_fraction,
            stop_distance=stop_distance,
            value_per_unit_at_price=value_per_unit_at_price,
        ))
        decision = self.decisions.authorize(DecisionInput(
            analysis=analysis.market,
            side=side,
            mode=mode,
            validated=True,
            reconciled=True,
            risk_fraction=float(risk_fraction),
            feed_age_seconds=0.0,
            analysis_complete=True,
        ))
        self.authority.authorize(
            ExecutionRequest(client_order_id, analysis.market.symbol, side), decision
        )
        intent = ExecutionIntent(
            symbol=analysis.market.symbol,
            side=ExecutionSide(side.value),
            risk_fraction=risk_fraction,
            feed_age_seconds=Decimal("0"),
            reconciled=True,
            decision_validated=True,
        )
        receipt = self.submissions.prepare(SubmissionRequest(
            client_order_id=client_order_id,
            fingerprint=f"{analysis.market.symbol}:{side.value}:{quantity}",
            intent=intent,
        ))
        receipt = self.submissions.begin_submission(receipt)
        broker_snapshot = BrokerSnapshot(
            account_id="CONTROLLED-ACCOUNT",
            equity=equity,
            connected=True,
            reconciled=True,
            open_order_ids=frozenset(),
        )
        self.broker.submit(broker_snapshot, BrokerSubmission(
            client_order_id=client_order_id,
            symbol=analysis.market.symbol,
            side=side.value,
            quantity=quantity,
        ), decision)
        lifecycle = OrderLifecycle(client_order_id)
        lifecycle.submit_started()
        lifecycle.broker_acknowledged(broker_order_id)
        lifecycle.filled()
        self.ledger.append("TRADE_AUTHORIZED", {"client_order_id": client_order_id, "symbol": analysis.market.symbol, "side": side.value})
        self.ledger.append("TRADE_FILLED", {"client_order_id": client_order_id, "broker_order_id": broker_order_id})
        lifecycle.begin_exit()
        evidence_id = f"close:{client_order_id}:{broker_order_id}"
        self.close_evidence.confirm(lifecycle, CloseRequest(client_order_id, broker_order_id), CloseEvidence(
            evidence_id=evidence_id,
            client_order_id=client_order_id,
            broker_order_id=broker_order_id,
            position_open=False,
            reconciled=True,
        ))
        self.ledger.append("TRADE_CLOSED", {"client_order_id": client_order_id, "broker_order_id": broker_order_id, "evidence_id": evidence_id})
        settlement = self.settlement.settle(gross_profit=Decimal("1"), fees=fee, fee_margin=fee_margin)
        self.ledger.append("SETTLEMENT_VERIFIED", {"client_order_id": client_order_id, "net_profit": str(settlement.final_net_profit)})
        self.ledger.require_integrity()
        return PipelineResult(client_order_id, broker_order_id, side, quantity, evidence_id, settlement, len(self.ledger.records))
