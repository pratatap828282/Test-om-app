"""Non-negotiable safety invariants for the fresh rebuild."""
from .master_contract import MASTER_CONTRACT, TradingMode


def validate_mode_appetite(mode: TradingMode, appetite: int) -> None:
    expected = {TradingMode.NORMAL: 100, TradingMode.MEDIUM: 50, TradingMode.BOOST: 75}[mode]
    if appetite != expected:
        raise ValueError(f"{mode.value} requires {expected}% strategy/opportunity appetite")


def validate_trade_risk(risk_fraction: float) -> None:
    if risk_fraction <= 0 or risk_fraction > MASTER_CONTRACT.absolute_trade_risk_cap:
        raise ValueError("trade risk exceeds immutable 0.20% cap or is non-positive")


def validate_symbol_scope(symbol: str, execution: bool) -> None:
    if execution and symbol != MASTER_CONTRACT.live_symbol:
        raise ValueError("execution scope is restricted to XAUUSD")
    if not execution and symbol == "DXY":
        return
    if symbol != MASTER_CONTRACT.live_symbol and not execution:
        raise ValueError("unsupported analysis symbol")


def validate_feed_age(age_seconds: float) -> None:
    if age_seconds < 0 or age_seconds > MASTER_CONTRACT.stale_feed_seconds:
        raise ValueError("stale or invalid market data")
