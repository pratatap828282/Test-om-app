"""Gate 20: final fresh-build verification orchestration.

This is a source-level certification harness. It proves the fail-closed contracts
compose correctly; it does not fabricate live broker/server/device/blockchain evidence.
"""
from dataclasses import dataclass

from backend.core.completeness import MasterTargetCompletenessGate
from backend.core.master_contract import MASTER_CONTRACT
from backend.core.safety_contract import BrokerSnapshot as SafetySnapshot, ExecutionSafetyGate
from backend.audit.ledger import AuditLedger


@dataclass(frozen=True)
class FinalVerificationReport:
    master_target: bool
    ledger_integrity: bool
    execution_safety: bool
    external_live_evidence_required: bool

    @property
    def passed(self) -> bool:
        return all((self.master_target, self.ledger_integrity,
                    self.execution_safety, self.external_live_evidence_required))


def run_source_verification() -> FinalVerificationReport:
    MASTER_CONTRACT.validate()
    completeness = MasterTargetCompletenessGate().evaluate()
    ledger = AuditLedger()
    ledger.append("FINAL_SOURCE_VERIFICATION", {"target": MASTER_CONTRACT.target})
    ledger.require_integrity()
    safety = ExecutionSafetyGate()
    safety.reconcile(SafetySnapshot(True, 1000.0, frozenset(), 100.0), 101.0)
    safety.authorize_submit("final-e2e-1", 101.0)
    return FinalVerificationReport(
        master_target=completeness.passed,
        ledger_integrity=True,
        execution_safety=True,
        external_live_evidence_required=True,
    )
