from dataclasses import dataclass
from enum import Enum

class NotificationKind(str, Enum):
    BOT_EVENT = "BOT_EVENT"
    ASSISTANT_EVENT = "ASSISTANT_EVENT"
    DOCTOR_EVENT = "DOCTOR_EVENT"
    LIQUIDATION = "LIQUIDATION"
    TRADE_MILESTONE = "TRADE_MILESTONE"

@dataclass(frozen=True)
class NotificationEvent:
    kind: NotificationKind
    event_id: str
    message: str
    sequence: int

class NotificationContractError(ValueError):
    pass

class NotificationCenter:
    MILESTONE=100
    def __init__(self):
        self._persistent=[]
        self._push=[]
        self._seen=set()
        self._trade_count=0
        self._last_sequence=0

    def publish(self, event: NotificationEvent, *, push=True):
        if not event.event_id or not event.message or event.sequence <= self._last_sequence:
            raise NotificationContractError("invalid or replayed notification")
        if event.event_id in self._seen:
            raise NotificationContractError("duplicate notification")
        self._seen.add(event.event_id)
        self._last_sequence=event.sequence
        self._persistent.append(event)
        if push:
            self._push.append(event)

    def record_trade(self, sequence: int):
        self._trade_count += 1
        if self._trade_count % self.MILESTONE == 0:
            event=NotificationEvent(NotificationKind.TRADE_MILESTONE, f"trade-{self._trade_count}", f"{self._trade_count}-trade milestone", sequence)
            self.publish(event)
            return event
        return None

    def persistent_history(self):
        return tuple(self._persistent)

    def push_history(self):
        return tuple(self._push)
