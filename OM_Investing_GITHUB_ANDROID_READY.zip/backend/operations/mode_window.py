from dataclasses import dataclass
from enum import Enum

class SystemMode(str, Enum):
    NORMAL = "NORMAL"
    MEDIUM = "MEDIUM"
    BOOST = "BOOST"

class WindowKind(str, Enum):
    LIVE_24X5 = "24x5"
    RESEARCH_HEAL_24X2 = "24x2"

@dataclass(frozen=True)
class ModePolicy:
    appetite_pct: int
    risk_cap_pct: float = 0.20

    def allows_risk(self, requested_pct: float) -> bool:
        return 0 <= requested_pct <= self.risk_cap_pct

POLICIES = {
    SystemMode.NORMAL: ModePolicy(100),
    SystemMode.MEDIUM: ModePolicy(50),
    SystemMode.BOOST: ModePolicy(75),
}

class OperationalPolicy:
    def __init__(self, mode: SystemMode = SystemMode.NORMAL):
        self.mode = mode

    def set_mode(self, mode: SystemMode) -> None:
        if not isinstance(mode, SystemMode):
            raise ValueError("invalid mode")
        self.mode = mode

    def policy(self) -> ModePolicy:
        return POLICIES[self.mode]

    def authorize_execution(self, requested_risk_pct: float, window: WindowKind) -> bool:
        if not isinstance(window, WindowKind):
            raise ValueError("invalid operational window")
        if window is not WindowKind.LIVE_24X5:
            return False
        return self.policy().allows_risk(requested_risk_pct)

    def authorize_research_or_heal(self, window: WindowKind) -> bool:
        if not isinstance(window, WindowKind):
            raise ValueError("invalid operational window")
        return window is WindowKind.RESEARCH_HEAL_24X2
