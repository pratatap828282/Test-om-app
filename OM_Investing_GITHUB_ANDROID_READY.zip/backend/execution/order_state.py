"""Fresh crash-safe order lifecycle for Gate 4."""
from enum import Enum

class OrderState(str, Enum):
    NEW = "NEW"
    SUBMITTING = "SUBMITTING"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    FILLED = "FILLED"
    EXITING = "EXITING"
    CLOSED = "CLOSED"
    REJECTED = "REJECTED"
    UNKNOWN = "UNKNOWN"

_ALLOWED = {
    OrderState.NEW: {OrderState.SUBMITTING, OrderState.REJECTED},
    OrderState.SUBMITTING: {OrderState.ACKNOWLEDGED, OrderState.REJECTED, OrderState.UNKNOWN},
    OrderState.ACKNOWLEDGED: {OrderState.FILLED, OrderState.REJECTED, OrderState.UNKNOWN},
    OrderState.FILLED: {OrderState.EXITING},
    OrderState.EXITING: {OrderState.CLOSED, OrderState.UNKNOWN},
    OrderState.CLOSED: set(),
    OrderState.REJECTED: set(),
    OrderState.UNKNOWN: {OrderState.ACKNOWLEDGED, OrderState.FILLED, OrderState.EXITING, OrderState.CLOSED},
}

def transition(current: OrderState, target: OrderState) -> OrderState:
    if target not in _ALLOWED[current]:
        raise ValueError(f"invalid order transition: {current.value} -> {target.value}")
    return target
