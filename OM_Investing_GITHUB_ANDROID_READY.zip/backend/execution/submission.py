"""Fresh fail-closed order submission coordinator for Gate 9."""
from dataclasses import dataclass
from decimal import Decimal

from backend.core.execution_contract import ExecutionIntent, validate_execution_intent
from backend.execution.idempotency import IdempotencyRegistry
from backend.execution.order_state import OrderState, transition


@dataclass(frozen=True)
class SubmissionRequest:
    client_order_id: str
    fingerprint: str
    intent: ExecutionIntent


@dataclass(frozen=True)
class SubmissionReceipt:
    client_order_id: str
    state: OrderState


class OrderSubmissionCoordinator:
    """Validates and reserves an order before any broker submission occurs."""

    def __init__(self, registry: IdempotencyRegistry | None = None):
        self.registry = registry or IdempotencyRegistry()

    def prepare(self, request: SubmissionRequest) -> SubmissionReceipt:
        validate_execution_intent(request.intent)
        if not request.client_order_id or not request.fingerprint:
            raise ValueError("order identity is required")
        self.registry.reserve(request.client_order_id, request.fingerprint)
        return SubmissionReceipt(request.client_order_id, OrderState.NEW)

    @staticmethod
    def begin_submission(receipt: SubmissionReceipt) -> SubmissionReceipt:
        return SubmissionReceipt(receipt.client_order_id,
                                  transition(receipt.state, OrderState.SUBMITTING))

    @staticmethod
    def acknowledge(receipt: SubmissionReceipt) -> SubmissionReceipt:
        return SubmissionReceipt(receipt.client_order_id,
                                  transition(receipt.state, OrderState.ACKNOWLEDGED))

    @staticmethod
    def mark_filled(receipt: SubmissionReceipt) -> SubmissionReceipt:
        return SubmissionReceipt(receipt.client_order_id,
                                  transition(receipt.state, OrderState.FILLED))
