"""Gate 46: execution-boundary enforcement for authoritative decision seals."""
from dataclasses import dataclass
from backend.strategy.decision_authority import DecisionAuthority, DecisionAuthorityBlocked, DecisionSeal
from backend.strategy.decision_contract import Side

class ExecutionAuthorityBlocked(PermissionError):
    """Raised when an execution request lacks matching authoritative provenance."""

@dataclass(frozen=True)
class ExecutionRequest:
    client_order_id: str
    symbol: str
    side: Side

class ExecutionAuthorityGate:
    """Final local boundary: only a valid Decision Engine seal may authorize execution."""
    def authorize(self, request: ExecutionRequest, seal: DecisionSeal):
        if not request.client_order_id:
            raise ExecutionAuthorityBlocked("order identity is required")
        try:
            decision = DecisionAuthority.validate(seal)
        except (DecisionAuthorityBlocked, ValueError) as exc:
            raise ExecutionAuthorityBlocked("invalid execution authority") from exc
        if request.symbol != decision.symbol or request.side != decision.side:
            raise ExecutionAuthorityBlocked("execution request does not match authoritative decision")
        return decision
