"""Gate 49: reconciled close boundary for an individual live trade."""
from dataclasses import dataclass

from backend.execution.close_authority import CloseBlocked, CloseRequest, IndividualTradeCloser
from backend.execution.lifecycle import OrderLifecycle
from backend.execution.order_state import OrderState


class CloseExecutionBlocked(PermissionError):
    """Raised when a close cannot be safely bound to the reconciled position."""


@dataclass(frozen=True)
class ClosePositionSnapshot:
    client_order_id: str
    broker_order_id: str
    position_open: bool
    reconciled: bool


class ReconciledCloseGuard:
    """Final local gate before closing one existing broker position."""

    def __init__(self):
        self._closer = IndividualTradeCloser()

    def close(self, lifecycle: OrderLifecycle, request: CloseRequest,
              snapshot: ClosePositionSnapshot) -> str:
        record = lifecycle.record
        if not snapshot.reconciled:
            raise CloseExecutionBlocked("reconciliation is required before close")
        if not snapshot.position_open:
            raise CloseExecutionBlocked("broker position is not open")
        if snapshot.client_order_id != record.client_order_id:
            raise CloseExecutionBlocked("snapshot client identity mismatch")
        if snapshot.broker_order_id != record.broker_order_id:
            raise CloseExecutionBlocked("snapshot broker identity mismatch")
        try:
            return self._closer.close(lifecycle, request)
        except CloseBlocked as exc:
            raise CloseExecutionBlocked(str(exc)) from exc
