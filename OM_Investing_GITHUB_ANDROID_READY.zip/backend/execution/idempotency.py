"""Fresh idempotency guard: one client order key cannot create duplicates."""
from dataclasses import dataclass, field

@dataclass
class IdempotencyRegistry:
    _keys: dict[str, str] = field(default_factory=dict)

    def reserve(self, client_order_id: str, fingerprint: str) -> None:
        if not client_order_id or not fingerprint:
            raise ValueError("client order id and fingerprint are required")
        existing = self._keys.get(client_order_id)
        if existing is not None:
            if existing != fingerprint:
                raise ValueError("idempotency key reused with different order fingerprint")
            raise ValueError("duplicate order blocked")
        self._keys[client_order_id] = fingerprint
