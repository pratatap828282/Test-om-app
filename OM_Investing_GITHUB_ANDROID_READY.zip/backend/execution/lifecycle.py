"""Fresh crash/fault-safe order lifecycle orchestration for Gate 11."""
from dataclasses import dataclass
from enum import Enum

from backend.execution.order_state import OrderState, transition


class LifecycleError(RuntimeError):
    pass


class Outcome(str, Enum):
    ACCEPTED = "ACCEPTED"
    REJECTED = "REJECTED"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class LifecycleRecord:
    client_order_id: str
    state: OrderState
    broker_order_id: str | None = None


class OrderLifecycle:
    """Owns state transitions and fail-closed handling of ambiguous broker outcomes."""

    def __init__(self, client_order_id: str):
        if not client_order_id:
            raise ValueError("client_order_id is required")
        self._record = LifecycleRecord(client_order_id, OrderState.NEW)

    @property
    def record(self) -> LifecycleRecord:
        return self._record

    def submit_started(self) -> LifecycleRecord:
        self._require_resolved()
        self._transition(OrderState.SUBMITTING)
        return self._record

    def broker_acknowledged(self, broker_order_id: str) -> LifecycleRecord:
        self._require_resolved()
        if not broker_order_id:
            raise LifecycleError("broker order identity is required")
        self._transition(OrderState.ACKNOWLEDGED)
        self._record = LifecycleRecord(self._record.client_order_id,
                                       self._record.state, broker_order_id)
        return self._record

    def filled(self) -> LifecycleRecord:
        self._require_resolved()
        self._transition(OrderState.FILLED)
        return self._record

    def begin_exit(self) -> LifecycleRecord:
        self._require_resolved()
        self._transition(OrderState.EXITING)
        return self._record

    def closed(self) -> LifecycleRecord:
        self._require_resolved()
        self._transition(OrderState.CLOSED)
        return self._record

    def reject(self) -> LifecycleRecord:
        self._require_resolved()
        if self._record.state not in {OrderState.NEW, OrderState.SUBMITTING, OrderState.ACKNOWLEDGED}:
            raise LifecycleError("order cannot be rejected from current state")
        self._transition(OrderState.REJECTED)
        return self._record

    def broker_outcome_unknown(self) -> LifecycleRecord:
        """Ambiguous broker result always enters UNKNOWN; no automatic resubmission."""
        if self._record.state not in {OrderState.SUBMITTING, OrderState.ACKNOWLEDGED, OrderState.EXITING}:
            raise LifecycleError("unknown outcome is not valid from current state")
        self._transition(OrderState.UNKNOWN)
        return self._record

    def reconcile_unknown(self, broker_state: str) -> LifecycleRecord:
        """Reconcile UNKNOWN before allowing any further authoritative action."""
        if self._record.state is not OrderState.UNKNOWN:
            raise LifecycleError("order is not awaiting reconciliation")
        mapping = {
            "ACKNOWLEDGED": OrderState.ACKNOWLEDGED,
            "FILLED": OrderState.FILLED,
            "EXITING": OrderState.EXITING,
            "CLOSED": OrderState.CLOSED,
        }
        target = mapping.get(broker_state)
        if target is None:
            raise LifecycleError("unrecognized broker reconciliation state")
        self._transition(target)
        return self._record

    def _require_resolved(self) -> None:
        if self._record.state is OrderState.UNKNOWN:
            raise LifecycleError("order outcome requires broker reconciliation before continuation")

    def _transition(self, target: OrderState) -> None:
        self._record = LifecycleRecord(self._record.client_order_id,
                                       transition(self._record.state, target),
                                       self._record.broker_order_id)
