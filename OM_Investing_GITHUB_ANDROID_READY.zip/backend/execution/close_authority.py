"""Gate 48: individual-trade close authority.

A losing/open trade is closed through its own lifecycle/position identity.
A separate offsetting order is never treated as a valid close instruction.
"""
from dataclasses import dataclass

from backend.execution.lifecycle import OrderLifecycle, LifecycleError
from backend.execution.order_state import OrderState


class CloseBlocked(PermissionError):
    """Raised when an attempted close does not belong to the original trade."""


@dataclass(frozen=True)
class CloseRequest:
    client_order_id: str
    broker_order_id: str


class IndividualTradeCloser:
    """Closes one authoritative trade through its existing lifecycle only."""

    def close(self, lifecycle: OrderLifecycle, request: CloseRequest) -> str:
        record = lifecycle.record
        if not request.client_order_id or not request.broker_order_id:
            raise CloseBlocked("trade identity is required")
        if request.client_order_id != record.client_order_id:
            raise CloseBlocked("close must target the original client order")
        if record.broker_order_id != request.broker_order_id:
            raise CloseBlocked("close must target the original broker position")
        if record.state is OrderState.FILLED:
            lifecycle.begin_exit()
        elif record.state is not OrderState.EXITING:
            raise CloseBlocked("trade is not closable in its current state")
        lifecycle.closed()
        return record.client_order_id
