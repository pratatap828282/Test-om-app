"""Gate 51: broker-confirmed individual-trade close completion.

A local close request is not treated as financially complete merely because the
local lifecycle entered an exit path. CLOSED requires an authoritative,
reconciled broker snapshot proving the original position is no longer open.
"""
from dataclasses import dataclass

from backend.execution.close_authority import CloseRequest
from backend.execution.close_execution_guard import ClosePositionSnapshot
from backend.execution.lifecycle import LifecycleError, OrderLifecycle
from backend.execution.order_state import OrderState


class CloseConfirmationBlocked(PermissionError):
    """Raised when broker evidence cannot prove the original position closed."""


@dataclass(frozen=True)
class CloseConfirmation:
    client_order_id: str
    broker_order_id: str
    position_open: bool
    reconciled: bool


class BrokerConfirmedClose:
    """Marks an existing trade CLOSED only after broker-confirmed evidence."""

    def confirm(
        self,
        lifecycle: OrderLifecycle,
        request: CloseRequest,
        evidence: CloseConfirmation | ClosePositionSnapshot,
    ) -> str:
        record = lifecycle.record
        if record.state is not OrderState.EXITING:
            raise CloseConfirmationBlocked("trade must be in EXITING state")
        if not evidence.reconciled:
            raise CloseConfirmationBlocked("close confirmation requires reconciliation")
        if evidence.position_open:
            raise CloseConfirmationBlocked("broker still reports the position open")
        if evidence.client_order_id != record.client_order_id:
            raise CloseConfirmationBlocked("close confirmation client identity mismatch")
        if evidence.broker_order_id != record.broker_order_id:
            raise CloseConfirmationBlocked("close confirmation broker identity mismatch")
        if request.client_order_id != record.client_order_id or request.broker_order_id != record.broker_order_id:
            raise CloseConfirmationBlocked("confirmation request does not target the original trade")
        try:
            lifecycle.closed()
        except LifecycleError as exc:
            raise CloseConfirmationBlocked(str(exc)) from exc
        return record.client_order_id
