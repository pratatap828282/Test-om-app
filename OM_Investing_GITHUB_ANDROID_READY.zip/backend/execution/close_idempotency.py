"""Gate 50: atomic idempotency boundary for individual-trade close operations.

A close intent is keyed to the original client/broker position identity.  The
same intent may not be executed twice, including concurrent attempts.  This
module never creates an offsetting order and does not grant financial authority;
it only prevents duplicate close execution at the final local boundary.
"""
from dataclasses import dataclass
from threading import Lock

from backend.execution.close_authority import CloseRequest
from backend.execution.close_execution_guard import (
    CloseExecutionBlocked,
    ClosePositionSnapshot,
    ReconciledCloseGuard,
)
from backend.execution.lifecycle import OrderLifecycle


class CloseIdempotencyBlocked(PermissionError):
    """Raised when the same individual close intent has already been consumed."""


@dataclass(frozen=True)
class CloseIntent:
    client_order_id: str
    broker_order_id: str


class AtomicCloseCoordinator:
    """Serializes and de-duplicates one close intent per original trade identity."""

    def __init__(self) -> None:
        self._guard = ReconciledCloseGuard()
        self._lock = Lock()
        self._completed: set[CloseIntent] = set()
        self._inflight: set[CloseIntent] = set()

    def close(
        self,
        lifecycle: OrderLifecycle,
        request: CloseRequest,
        snapshot: ClosePositionSnapshot,
    ) -> str:
        intent = CloseIntent(request.client_order_id, request.broker_order_id)
        with self._lock:
            if intent in self._completed or intent in self._inflight:
                raise CloseIdempotencyBlocked("duplicate close intent is blocked")
            self._inflight.add(intent)

        try:
            result = self._guard.close(lifecycle, request, snapshot)
        except CloseExecutionBlocked:
            with self._lock:
                self._inflight.discard(intent)
            raise
        except Exception:
            with self._lock:
                self._inflight.discard(intent)
            raise
        else:
            with self._lock:
                self._inflight.discard(intent)
                self._completed.add(intent)
            return result

    def completed(self, request: CloseRequest) -> bool:
        return CloseIntent(request.client_order_id, request.broker_order_id) in self._completed
