"""Gate 16: final pre-submit broker snapshot and fail-closed submission guard."""
from dataclasses import dataclass
from decimal import Decimal
from backend.broker.contract import BrokerSnapshot, BrokerSubmission, BrokerBoundaryError

class SubmitGuardError(RuntimeError):
    pass

@dataclass(frozen=True)
class SubmitResult:
    client_order_id: str
    state: str

class FinalSubmitGuard:
    """Requires a fresh reconciled snapshot immediately before broker submission.

    A submission exception is treated as ambiguous: the order becomes UNKNOWN and
    SAFE_MODE is entered until broker reconciliation resolves ownership/state.
    """
    def __init__(self) -> None:
        self.safe_mode = False
        self.unknown_order_ids: set[str] = set()

    def reconcile_snapshot(self, snapshot: BrokerSnapshot, order_id: str) -> None:
        if not snapshot.connected or not snapshot.reconciled:
            self.safe_mode = True
            raise SubmitGuardError("reconciliation snapshot is not valid")
        if not snapshot.account_id or snapshot.equity < Decimal("0"):
            self.safe_mode = True
            raise SubmitGuardError("invalid reconciliation snapshot")
        if order_id in snapshot.open_order_ids:
            self.safe_mode = True
            raise SubmitGuardError("existing broker order blocks submission")

    def submit(self, snapshot: BrokerSnapshot, order: BrokerSubmission, broker_submit) -> SubmitResult:
        if self.safe_mode:
            raise SubmitGuardError("submission blocked in SAFE_MODE")
        # This is deliberately the last local check before invoking the broker.
        self.reconcile_snapshot(snapshot, order.client_order_id)
        try:
            broker_submit(order)
        except Exception as exc:
            self.unknown_order_ids.add(order.client_order_id)
            self.safe_mode = True
            raise SubmitGuardError("broker submission outcome UNKNOWN; reconciliation required") from exc
        return SubmitResult(order.client_order_id, "SUBMITTED")

    def resolve_unknown(self, snapshot: BrokerSnapshot, order_id: str, broker_state: str) -> str:
        if order_id not in self.unknown_order_ids:
            raise SubmitGuardError("order is not awaiting UNKNOWN reconciliation")
        if not snapshot.connected or not snapshot.reconciled:
            self.safe_mode = True
            raise SubmitGuardError("reconciliation failed while resolving UNKNOWN")
        if broker_state not in {"ABSENT", "ACKNOWLEDGED", "FILLED", "CLOSED"}:
            self.safe_mode = True
            raise SubmitGuardError("unrecognized reconciliation state")
        self.unknown_order_ids.remove(order_id)
        if not self.unknown_order_ids:
            self.safe_mode = False
        return broker_state
