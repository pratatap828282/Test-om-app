"""Gate 52: tamper-resistant provenance boundary for individual-trade close evidence.

CLOSED completion must carry a non-empty broker evidence identifier that is
bound to the original client/broker position identity and the reconciled
closed-position state. This module records provenance only; it grants no
financial authority and creates no offsetting order.
"""
from dataclasses import dataclass

from backend.execution.close_confirmation import CloseConfirmation, CloseConfirmationBlocked, BrokerConfirmedClose
from backend.execution.close_authority import CloseRequest
from backend.execution.lifecycle import OrderLifecycle
from backend.execution.order_state import OrderState


@dataclass(frozen=True)
class CloseEvidence:
    evidence_id: str
    client_order_id: str
    broker_order_id: str
    position_open: bool
    reconciled: bool


class CloseEvidenceBlocked(PermissionError):
    """Raised when close provenance is missing or does not bind to the trade."""


class EvidenceBoundBrokerClose:
    """Completes an EXITING trade only with identity-bound broker evidence."""

    def __init__(self) -> None:
        self._confirmer = BrokerConfirmedClose()
        self._used: set[str] = set()

    def confirm(self, lifecycle: OrderLifecycle, request: CloseRequest,
                evidence: CloseEvidence) -> str:
        if lifecycle.record.state is not OrderState.EXITING:
            raise CloseEvidenceBlocked("trade must be in EXITING state")
        if not evidence.evidence_id:
            raise CloseEvidenceBlocked("close evidence identity is required")
        if evidence.evidence_id in self._used:
            raise CloseEvidenceBlocked("close evidence cannot be reused")
        if evidence.client_order_id != lifecycle.record.client_order_id:
            raise CloseEvidenceBlocked("close evidence client identity mismatch")
        if evidence.broker_order_id != lifecycle.record.broker_order_id:
            raise CloseEvidenceBlocked("close evidence broker identity mismatch")
        if not evidence.reconciled or evidence.position_open:
            raise CloseEvidenceBlocked("evidence must prove a reconciled closed position")
        confirmation = CloseConfirmation(
            client_order_id=evidence.client_order_id,
            broker_order_id=evidence.broker_order_id,
            position_open=evidence.position_open,
            reconciled=evidence.reconciled,
        )
        try:
            result = self._confirmer.confirm(lifecycle, request, confirmation)
        except CloseConfirmationBlocked as exc:
            raise CloseEvidenceBlocked(str(exc)) from exc
        self._used.add(evidence.evidence_id)
        return result

    def evidence_used(self, evidence_id: str) -> bool:
        return evidence_id in self._used
