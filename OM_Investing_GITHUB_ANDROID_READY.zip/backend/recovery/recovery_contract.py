"""Recovery must preserve financial authority and require reconciliation."""
from dataclasses import dataclass

@dataclass(frozen=True)
class RecoveryRequest:
    component: str
    authorized: bool
    integrity_valid: bool
    broker_reconciled: bool

class RecoveryContract:
    def authorize(self, req: RecoveryRequest) -> None:
        if not req.component.strip():
            raise ValueError("component is required")
        if not req.authorized:
            raise PermissionError("unauthorized recovery blocked")
        if not req.integrity_valid:
            raise ValueError("integrity failure blocks recovery")
        if not req.broker_reconciled:
            raise ValueError("broker reconciliation required before recovery activation")
