"""Fresh Gate 6: bot continuity and fail-closed auto-heal contract."""
from dataclasses import dataclass
from enum import Enum

class HealthState(str, Enum):
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    SAFE_MODE = "SAFE_MODE"

@dataclass(frozen=True)
class HealthSnapshot:
    heartbeat_age_seconds: float
    memory_pct: float
    queue_depth: int
    broker_reconciled: bool

class BotAutoHeal:
    MAX_HEARTBEAT_AGE = 5.0
    MAX_MEMORY_PCT = 92.0
    MAX_QUEUE_DEPTH = 1000

    def evaluate(self, s: HealthSnapshot) -> HealthState:
        if s.heartbeat_age_seconds < 0 or s.memory_pct < 0 or s.memory_pct > 100 or s.queue_depth < 0:
            return HealthState.SAFE_MODE
        if not s.broker_reconciled:
            return HealthState.SAFE_MODE
        if s.heartbeat_age_seconds > self.MAX_HEARTBEAT_AGE or s.memory_pct > self.MAX_MEMORY_PCT:
            return HealthState.DEGRADED
        if s.queue_depth > self.MAX_QUEUE_DEPTH:
            return HealthState.DEGRADED
        return HealthState.HEALTHY

    def can_continue_execution(self, state: HealthState) -> bool:
        return state is HealthState.HEALTHY
