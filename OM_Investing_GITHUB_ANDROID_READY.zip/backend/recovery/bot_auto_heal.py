"""Gate 41: authoritative Bot auto-heal, independent of support-plane recovery."""
from dataclasses import dataclass
from enum import Enum


class AutoHealBlocked(RuntimeError):
    """Raised when an unsafe or unauthorized heal request is attempted."""


class HealAction(str, Enum):
    RESTART_COMPONENT = "RESTART_COMPONENT"
    RECONNECT_FEED = "RECONNECT_FEED"
    RECONCILE_BROKER = "RECONCILE_BROKER"
    ENTER_SAFE_MODE = "ENTER_SAFE_MODE"


@dataclass(frozen=True)
class HealRequest:
    action: HealAction
    authorized: bool = True
    integrity_valid: bool = True
    changes_financial_state: bool = False


class BotAutoHealController:
    """Bot-owned recovery boundary; assistants/doctors cannot be its dependency."""

    SAFE_ACTIONS = frozenset(HealAction)

    def validate(self, request: HealRequest) -> None:
        if not isinstance(request.action, HealAction):
            raise AutoHealBlocked("invalid heal action")
        if not request.authorized:
            raise AutoHealBlocked("unauthorized heal action")
        if not request.integrity_valid:
            raise AutoHealBlocked("heal artifact integrity invalid")
        if request.changes_financial_state:
            raise AutoHealBlocked("auto-heal cannot directly change financial state")

    def can_heal_bot(self, request: HealRequest) -> bool:
        self.validate(request)
        return request.action in self.SAFE_ACTIONS

    def support_failure_blocks_bot(self, support_healthy: bool) -> bool:
        # Support/Doctor health is intentionally not a trading-path dependency.
        return False
