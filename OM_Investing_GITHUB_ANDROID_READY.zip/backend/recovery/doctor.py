"""Gate 42: isolated Doctor health/recovery boundary.

Doctors monitor and repair Assistant/support components only. They never own
trading or financial authority, and their health/recovery state cannot gate
Bot execution.
"""
from dataclasses import dataclass
from enum import Enum
import hashlib


class DoctorBlocked(RuntimeError):
    """Raised when a Doctor operation is unsafe, unauthorized, or out of scope."""


class DoctorState(str, Enum):
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    SAFE_MODE = "SAFE_MODE"


@dataclass(frozen=True)
class DoctorHealth:
    heartbeat_age_seconds: float
    integrity_valid: bool
    assistant_healthy: bool


@dataclass(frozen=True)
class DoctorRepair:
    component: str
    content: bytes
    authorized: bool = True
    expected_sha256: str = ""


class SupportDoctor:
    MAX_HEARTBEAT_AGE = 5.0
    FINANCIAL_COMPONENTS = frozenset({
        "TRADING_BOT", "EXECUTION", "ORDER", "BROKER", "SETTLEMENT",
        "TREASURY", "WITHDRAWAL", "RISK", "LEDGER",
    })

    def evaluate(self, health: DoctorHealth) -> DoctorState:
        if health.heartbeat_age_seconds < 0:
            return DoctorState.SAFE_MODE
        if not health.integrity_valid:
            return DoctorState.SAFE_MODE
        if health.heartbeat_age_seconds > self.MAX_HEARTBEAT_AGE or not health.assistant_healthy:
            return DoctorState.DEGRADED
        return DoctorState.HEALTHY

    def repair(self, request: DoctorRepair) -> str:
        component = request.component.strip().upper()
        if not request.authorized:
            raise DoctorBlocked("unauthorized Doctor repair")
        if not component:
            raise DoctorBlocked("repair component is required")
        if component in self.FINANCIAL_COMPONENTS:
            raise DoctorBlocked("Doctor cannot repair financial or trading authority")
        if len(request.expected_sha256) != 64:
            raise DoctorBlocked("invalid repair integrity reference")
        if hashlib.sha256(request.content).hexdigest() != request.expected_sha256.lower():
            raise DoctorBlocked("repair integrity mismatch")
        return "STAGED_SUPPORT_REPAIR_READY"

    @staticmethod
    def bot_execution_dependency_ok(state: DoctorState) -> bool:
        # Doctor state is deliberately non-authoritative for Bot execution.
        return True
