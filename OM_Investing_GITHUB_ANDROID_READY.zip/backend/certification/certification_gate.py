"""Gate 23: centralized operation certification and trust boundary."""
from dataclasses import dataclass
from enum import Enum


class CertificationBlocked(PermissionError):
    pass


class OperationScope(str, Enum):
    SECURITY = "security"
    APK = "apk"
    API_GATEWAY = "api_gateway"
    PRIMARY_SERVER = "primary_server"
    PLAN_B_SERVERS = "plan_b_servers"
    MARKET_FEED = "market_feed"
    STRATEGY = "strategy"
    DECISION = "decision"
    RISK = "risk"
    EXECUTION = "execution"
    LEDGER = "ledger"
    SETTLEMENT = "settlement"
    WITHDRAWAL = "withdrawal"
    OWNER_AUTH = "owner_auth"
    DEPLOYMENT = "deployment"
    UPDATE_CENTER = "update_center"
    RECOVERY = "recovery"


@dataclass(frozen=True)
class CertificationEvidence:
    identity: bool
    certificate_trust: bool
    integrity: bool
    authorization: bool
    compatibility: bool
    currently_valid: bool
    operation_validated: bool
    audit_evidence: bool

    def complete(self) -> bool:
        return all((self.identity, self.certificate_trust, self.integrity,
                    self.authorization, self.compatibility, self.currently_valid,
                    self.operation_validated, self.audit_evidence))


@dataclass(frozen=True)
class CertificationResult:
    scope: OperationScope
    certified: bool
    reason: str


class CertificationGate:
    """Common fail-closed sequence for every critical operation."""

    REQUIRED_ORDER = (
        "identity", "certificate_trust", "integrity", "authorization",
        "compatibility", "currently_valid", "operation_validated", "audit_evidence",
    )

    def certify(self, scope: OperationScope, evidence: CertificationEvidence) -> CertificationResult:
        if not isinstance(scope, OperationScope):
            return CertificationResult(scope, False, "unknown operation scope")
        for name in self.REQUIRED_ORDER:
            if not getattr(evidence, name):
                return CertificationResult(scope, False, f"certification prerequisite failed: {name}")
        return CertificationResult(scope, True, "certified")

    def require(self, scope: OperationScope, evidence: CertificationEvidence) -> None:
        result = self.certify(scope, evidence)
        if not result.certified:
            raise CertificationBlocked(result.reason)
