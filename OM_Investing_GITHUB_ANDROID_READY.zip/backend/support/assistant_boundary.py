"""Gate 43: Assistant advisory boundary.

Assistant output is untrusted advisory input. It may inform analysis, but it
cannot authorize, submit, alter, or settle financial operations.
"""
from dataclasses import dataclass
from enum import Enum
import hashlib


class AssistantBlocked(PermissionError):
    """Raised when assistant output crosses its authority boundary."""


class AdvisoryStatus(str, Enum):
    ACCEPTED = "ACCEPTED"
    REJECTED = "REJECTED"


@dataclass(frozen=True)
class Advisory:
    topic: str
    content: bytes
    authorized_source: bool = True
    integrity_sha256: str = ""


class AssistantBoundary:
    FINANCIAL_OPERATIONS = frozenset({
        "BUY", "SELL", "SUBMIT", "CLOSE", "MODIFY_ORDER", "CHANGE_RISK",
        "SETTLE", "WITHDRAW", "TREASURY", "ACTIVATE_RELEASE",
    })

    def validate_advisory(self, advisory: Advisory) -> AdvisoryStatus:
        if not advisory.authorized_source:
            raise AssistantBlocked("assistant source is unauthorized")
        if not advisory.topic.strip() or not advisory.content:
            raise AssistantBlocked("assistant advisory is empty")
        if len(advisory.integrity_sha256) != 64:
            raise AssistantBlocked("invalid advisory integrity reference")
        if hashlib.sha256(advisory.content).hexdigest() != advisory.integrity_sha256.lower():
            raise AssistantBlocked("assistant advisory integrity mismatch")
        return AdvisoryStatus.ACCEPTED

    def authorize_operation(self, operation: str) -> None:
        # Explicitly never grants financial authority to an Assistant.
        op = operation.strip().upper()
        if op in self.FINANCIAL_OPERATIONS:
            raise AssistantBlocked("Assistant has no financial authority")
        raise AssistantBlocked("Assistant cannot authorize operations")

    @staticmethod
    def is_execution_dependency(assistant_healthy: bool) -> bool:
        # Bot execution must remain independent of Assistant health.
        return False
