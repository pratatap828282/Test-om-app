"""Isolated Assistant/Doctor support plane.

The Trading Bot remains the sole operational/financial authority. Assistants
may provide information; Doctors may validate/repair support components only
through an authorized, integrity-checked path. Neither can authorize, submit,
modify, or settle financial transactions.
"""
from dataclasses import dataclass
from enum import Enum
import hashlib


class SupportPlaneBlocked(PermissionError):
    pass


class SupportAction(str, Enum):
    ANALYZE = "ANALYZE"
    REPAIR = "REPAIR"


@dataclass(frozen=True)
class AssistantRequest:
    topic: str
    authorized: bool = True


@dataclass(frozen=True)
class AssistantResult:
    topic: str
    advisory_text: str
    financial_authority: bool = False


@dataclass(frozen=True)
class DoctorRepairRequest:
    component: str
    proposed_content: bytes
    authorized: bool
    integrity_expected_sha256: str


class SupportPlane:
    FINANCIAL_ACTIONS = frozenset({"BUY", "SELL", "SUBMIT", "CLOSE", "WITHDRAW", "SETTLE", "CHANGE_RISK"})

    def assistant_analyze(self, request: AssistantRequest) -> AssistantResult:
        if not request.authorized or not request.topic.strip():
            raise SupportPlaneBlocked("assistant request unauthorized or empty")
        return AssistantResult(request.topic, "advisory-only", False)

    def authorize_financial_action(self, action: str) -> None:
        raise SupportPlaneBlocked("support plane has no financial authority")

    def doctor_repair(self, request: DoctorRepairRequest) -> str:
        if not request.authorized:
            raise SupportPlaneBlocked("doctor repair is unauthorized")
        if not request.component.strip():
            raise SupportPlaneBlocked("repair component is required")
        if len(request.integrity_expected_sha256) != 64:
            raise SupportPlaneBlocked("invalid integrity reference")
        digest = hashlib.sha256(request.proposed_content).hexdigest()
        if digest != request.integrity_expected_sha256.lower():
            raise SupportPlaneBlocked("repair integrity mismatch")
        return "STAGED_REPAIR_READY"

    def bot_execution_dependency_ok(self, assistant_healthy: bool, doctor_healthy: bool) -> bool:
        # Support health never gates the Bot's execution dependency path.
        return True
