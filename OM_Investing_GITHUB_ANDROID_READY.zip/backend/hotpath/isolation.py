"""Gate 40: keep trading execution independent from support-plane work."""
from dataclasses import dataclass
from enum import Enum

class HotPathBlocked(RuntimeError):
    pass

class WorkClass(str, Enum):
    TRADING = 'TRADING'
    SUPPORT = 'SUPPORT'
    RESEARCH = 'RESEARCH'
    DOCTOR = 'DOCTOR'
    UI = 'UI'

@dataclass(frozen=True)
class WorkRequest:
    work_class: WorkClass
    execution_authority: bool = False

class HotPathIsolation:
    """Fail-closed policy: support work cannot acquire trading authority or block the Bot."""
    SUPPORT_CLASSES = frozenset({WorkClass.SUPPORT, WorkClass.RESEARCH, WorkClass.DOCTOR, WorkClass.UI})

    def validate(self, request: WorkRequest) -> None:
        if not isinstance(request.work_class, WorkClass):
            raise HotPathBlocked('invalid work class')
        if request.work_class in self.SUPPORT_CLASSES and request.execution_authority:
            raise HotPathBlocked('support-plane work cannot hold execution authority')

    def can_block_trading(self, request: WorkRequest) -> bool:
        self.validate(request)
        return request.work_class is WorkClass.TRADING

    def can_authorize_financial_operation(self, request: WorkRequest) -> bool:
        self.validate(request)
        return request.work_class is WorkClass.TRADING and request.execution_authority
