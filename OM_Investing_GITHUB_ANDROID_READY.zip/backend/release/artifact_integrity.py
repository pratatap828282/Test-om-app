"""Gate 31: release-artifact integrity and secret-boundary contract."""
from dataclasses import dataclass
import hashlib
import json


class ReleaseBlocked(PermissionError):
    pass


@dataclass(frozen=True)
class ReleaseArtifact:
    artifact_id: str
    version: str
    sha256: str
    signed: bool
    signature_valid: bool
    compatibility_valid: bool
    master_target_unchanged: bool
    contains_private_keys: bool = False
    contains_broker_secrets: bool = False
    contains_wallet_private_keys: bool = False


class ReleaseArtifactGate:
    """Fail-closed release boundary; private credentials never belong in an artifact."""

    @staticmethod
    def canonical_digest(payload: bytes) -> str:
        if not isinstance(payload, (bytes, bytearray)) or not payload:
            raise ReleaseBlocked("release payload is empty or invalid")
        return hashlib.sha256(bytes(payload)).hexdigest()

    def verify(self, artifact: ReleaseArtifact, payload: bytes) -> None:
        if not artifact.artifact_id.strip() or not artifact.version.strip():
            raise ReleaseBlocked("artifact identity/version required")
        digest = self.canonical_digest(payload)
        if artifact.sha256.lower() != digest:
            raise ReleaseBlocked("artifact integrity mismatch")
        if not artifact.signed or not artifact.signature_valid:
            raise ReleaseBlocked("artifact signature invalid")
        if not artifact.compatibility_valid:
            raise ReleaseBlocked("artifact compatibility invalid")
        if not artifact.master_target_unchanged:
            raise ReleaseBlocked("Master Target mutation rejected")
        if any((artifact.contains_private_keys, artifact.contains_broker_secrets,
                artifact.contains_wallet_private_keys)):
            raise ReleaseBlocked("private credential material cannot enter release artifact")

    @staticmethod
    def public_metadata(artifact: ReleaseArtifact) -> dict[str, str]:
        """Safe metadata for audit/UI; no secret or credential material is returned."""
        return json.loads(json.dumps({
            "artifact_id": artifact.artifact_id,
            "version": artifact.version,
            "sha256": artifact.sha256,
            "signed": str(artifact.signed).lower(),
            "signature_valid": str(artifact.signature_valid).lower(),
        }))
