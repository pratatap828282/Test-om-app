"""Fresh position-sizing contract for the OM Investing System.

Sizing is subordinate to the immutable trade-risk cap. Strategy appetite never
changes the monetary cap. Requested size may be sliced into individually
bounded child orders; this module does not execute orders.
"""
from dataclasses import dataclass
from decimal import Decimal
from math import floor

from backend.core.invariants import validate_trade_risk
from backend.core.master_contract import MASTER_CONTRACT


@dataclass(frozen=True)
class SizeRequest:
    equity: Decimal
    risk_fraction: Decimal
    stop_distance: Decimal
    value_per_unit_at_price: Decimal
    requested_units: Decimal | None = None


def _positive(*values: Decimal) -> None:
    if any(v <= 0 for v in values):
        raise ValueError("sizing inputs must be positive")


def calculate_units(req: SizeRequest) -> Decimal:
    _positive(req.equity, req.risk_fraction, req.stop_distance, req.value_per_unit_at_price)
    validate_trade_risk(float(req.risk_fraction))
    risk_budget = req.equity * req.risk_fraction
    units = risk_budget / (req.stop_distance * req.value_per_unit_at_price)
    if units <= 0:
        raise ValueError("calculated size is non-positive")
    return units


def bounded_request(req: SizeRequest) -> Decimal:
    """Return the engine-calculated size; caller requests cannot raise risk."""
    calculated = calculate_units(req)
    if req.requested_units is None:
        return calculated
    _positive(req.requested_units)
    # A requested size above the risk-derived bound is reduced, never executed as-is.
    return min(req.requested_units, calculated)


def slice_units(total_units: Decimal, max_child_units: Decimal) -> tuple[Decimal, ...]:
    _positive(total_units, max_child_units)
    count = int((total_units / max_child_units).to_integral_value(rounding="ROUND_CEILING"))
    base = total_units / Decimal(count)
    return tuple(base for _ in range(count))
