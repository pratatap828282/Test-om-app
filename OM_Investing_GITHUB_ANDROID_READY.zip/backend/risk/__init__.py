"""Fresh risk layer."""
