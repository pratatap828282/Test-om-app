"""Gate 15: authoritative opportunity appetite and request-side sizing guard."""
from dataclasses import dataclass
from decimal import Decimal
from backend.core.master_contract import TradingMode, MASTER_CONTRACT
from backend.core.invariants import validate_trade_risk, validate_mode_appetite

APPETITE_PCT = {TradingMode.NORMAL: 100, TradingMode.MEDIUM: 50, TradingMode.BOOST: 75}

@dataclass(frozen=True)
class OpportunityRequest:
    mode: TradingMode
    appetite_pct: int
    requested_risk_fraction: Decimal

    def validate(self) -> None:
        validate_mode_appetite(self.mode, self.appetite_pct)
        validate_trade_risk(float(self.requested_risk_fraction))


def authorize_opportunity(req: OpportunityRequest) -> int:
    req.validate()
    return APPETITE_PCT[req.mode]


def bound_requested_risk(requested: Decimal) -> Decimal:
    """Final request-side monetary risk guard; it can only reduce risk."""
    if requested <= 0:
        raise ValueError("requested risk must be positive")
    cap = Decimal(str(MASTER_CONTRACT.absolute_trade_risk_cap))
    return min(requested, cap)


def slice_bounded_units(total_units: Decimal, max_child_units: Decimal) -> tuple[Decimal, ...]:
    if total_units <= 0 or max_child_units <= 0:
        raise ValueError("units must be positive")
    count = int((total_units / max_child_units).to_integral_value(rounding="ROUND_CEILING"))
    if count < 1:
        count = 1
    base = total_units / Decimal(count)
    children = tuple(base for _ in range(count))
    if any(child > max_child_units for child in children):
        raise ValueError("child slice exceeds requested bound")
    if sum(children, Decimal("0")) != total_units:
        raise ValueError("slice conservation failure")
    return children
