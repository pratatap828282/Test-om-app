"""Fresh Gate 27 mobile-controller lease and recovery visibility policy."""
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

class ControllerBlocked(PermissionError):
    pass

@dataclass(frozen=True)
class ControllerState:
    active_device_id: str | None
    last_authenticated_at: datetime | None
    recovery_visible: bool
    sleep_mode: bool

class MobileControllerLease:
    RECOVERY_AFTER = timedelta(hours=72)
    DEADMAN_AFTER = timedelta(days=9)

    def __init__(self) -> None:
        self._active_device: str | None = None
        self._last_auth: datetime | None = None

    @staticmethod
    def _now(value: datetime | None) -> datetime:
        now = value or datetime.now(timezone.utc)
        if now.tzinfo is None:
            raise ControllerBlocked("time must be timezone-aware")
        return now

    def authenticate(self, device_id: str, *, authorized: bool, at: datetime) -> ControllerState:
        if not device_id or not authorized:
            raise ControllerBlocked("controller authentication rejected")
        now = self._now(at)
        if self._active_device is not None and self._active_device != device_id:
            raise ControllerBlocked("another controller lease is active")
        self._active_device = device_id
        self._last_auth = now
        return self.state(now)

    def state(self, at: datetime) -> ControllerState:
        now = self._now(at)
        if self._last_auth is None:
            return ControllerState(self._active_device, None, False, False)
        age = now - self._last_auth
        if age.total_seconds() < 0:
            raise ControllerBlocked("time moved backwards")
        sleep = age >= self.DEADMAN_AFTER
        recovery = self.RECOVERY_AFTER <= age < self.DEADMAN_AFTER
        return ControllerState(self._active_device, self._last_auth, recovery, sleep)

    def recovery_download_allowed(self, device_id: str, at: datetime) -> bool:
        s = self.state(at)
        return s.recovery_visible and device_id == s.active_device_id

    def reauthenticate_old_device(self, device_id: str, *, authorized: bool, at: datetime) -> ControllerState:
        if device_id != self._active_device:
            raise ControllerBlocked("unknown controller device")
        return self.authenticate(device_id, authorized=authorized, at=at)
