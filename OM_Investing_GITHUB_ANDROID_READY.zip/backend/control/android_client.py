"""Fresh Gate 29 Android controller security/UX contract.

The mobile client is a controller, never a financial authority. This contract
keeps sensitive controls authenticated, prevents secret material from entering
client state, and requires safe-state preservation across configuration changes.
"""
from dataclasses import dataclass
from enum import Enum

class ClientBlocked(PermissionError):
    pass

class ScreenSize(str, Enum):
    COMPACT = "COMPACT"
    LARGE = "LARGE"
    TABLET = "TABLET"

@dataclass(frozen=True)
class ControllerUiState:
    authenticated: bool
    bot_enabled: bool
    mode: str
    risk_pct: float
    ledger_integrity_valid: bool
    screenshot_protection: bool

class AndroidControllerContract:
    MODES = frozenset({"NORMAL", "MEDIUM", "BOOST"})
    MAX_RISK_PCT = 0.20

    @staticmethod
    def validate_state(state: ControllerUiState) -> None:
        if state.mode not in AndroidControllerContract.MODES:
            raise ClientBlocked("invalid trading mode")
        if not (0.0 <= state.risk_pct <= AndroidControllerContract.MAX_RISK_PCT):
            raise ClientBlocked("client risk exceeds immutable cap")
        if state.bot_enabled and not state.authenticated:
            raise ClientBlocked("bot control requires owner authentication")
        if state.bot_enabled and not state.ledger_integrity_valid:
            raise ClientBlocked("bot control requires valid ledger integrity")
        if not state.screenshot_protection:
            raise ClientBlocked("sensitive controller screen requires screenshot protection")

    @staticmethod
    def validate_layout(size: ScreenSize, *, clipped: bool, overlapped: bool) -> None:
        if clipped or overlapped:
            raise ClientBlocked("responsive layout safety failure")
        if size not in ScreenSize:
            raise ClientBlocked("unknown screen size")

    @staticmethod
    def accept_secret_for_ui(secret: str) -> str:
        # Only masked length is allowed to leave the secure input boundary.
        if not secret:
            raise ClientBlocked("empty secret")
        return "★" * len(secret)
