"""Fresh broker boundary contracts for Gate 10."""
from dataclasses import dataclass
from decimal import Decimal

@dataclass(frozen=True)
class BrokerSnapshot:
    account_id: str
    equity: Decimal
    connected: bool
    reconciled: bool
    open_order_ids: frozenset[str]

@dataclass(frozen=True)
class BrokerSubmission:
    client_order_id: str
    symbol: str
    side: str
    quantity: Decimal

class BrokerBoundaryError(ValueError):
    pass
