"""Fresh broker execution boundary: reconciliation is checked immediately before submit."""
from backend.broker.contract import BrokerSnapshot, BrokerSubmission, BrokerBoundaryError
from backend.reconciliation.guard import ReconciliationGuard
from backend.execution.authority_gate import ExecutionAuthorityGate, ExecutionRequest, ExecutionAuthorityBlocked
from backend.strategy.decision_authority import DecisionSeal
from backend.strategy.decision_contract import Side

class BrokerExecutionCoordinator:
    def __init__(self):
        self.submitted: dict[str, BrokerSubmission] = {}
        self.authority_gate = ExecutionAuthorityGate()

    def submit(self, snapshot: BrokerSnapshot, order: BrokerSubmission, seal: DecisionSeal | None = None) -> str:
        if seal is None:
            raise BrokerBoundaryError("authoritative decision seal is required")
        try:
            self.authority_gate.authorize(
                ExecutionRequest(order.client_order_id, order.symbol, Side(order.side)),
                seal,
            )
        except (ExecutionAuthorityBlocked, ValueError) as exc:
            raise BrokerBoundaryError("invalid or mismatched execution authority") from exc
        ReconciliationGuard.require_ready(snapshot, order.client_order_id)
        if order.client_order_id in self.submitted:
            raise BrokerBoundaryError("duplicate local broker submission")
        if not order.symbol or order.symbol != "XAUUSD":
            raise BrokerBoundaryError("live broker scope is XAUUSD only")
        if order.side not in {"BUY", "SELL"}:
            raise BrokerBoundaryError("unsupported execution side")
        if order.quantity <= 0:
            raise BrokerBoundaryError("quantity must be positive")
        self.submitted[order.client_order_id] = order
        return order.client_order_id
