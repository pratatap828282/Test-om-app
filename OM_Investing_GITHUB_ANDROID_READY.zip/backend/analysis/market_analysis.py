"""Fresh market-analysis aggregation contract for XAUUSD/DXY."""
from dataclasses import dataclass
from backend.strategy.market_contract import MarketAnalysisContract

@dataclass(frozen=True)
class AnalysisSnapshot:
    market: MarketAnalysisContract
    corroborated: bool
    feed_valid: bool = True

    def validate(self) -> None:
        self.market.validate()
        if not self.feed_valid:
            raise ValueError("market feed is not valid")
        if not self.corroborated:
            raise ValueError("analysis inputs are not corroborated")

    @property
    def execution_symbol(self) -> bool:
        return self.market.execution_eligible_symbol
