"""Gate 32: public trust anchors and certificate-pinning metadata boundary."""
from dataclasses import dataclass
import hashlib


class TrustMaterialBlocked(PermissionError):
    pass


@dataclass(frozen=True)
class PublicTrustMaterial:
    anchor_id: str
    subject: str
    sha256_fingerprint: str
    active: bool
    revoked: bool = False


class PublicTrustGate:
    """Allows only non-secret, active, non-revoked public trust material."""

    @staticmethod
    def fingerprint(certificate_der: bytes) -> str:
        if not isinstance(certificate_der, (bytes, bytearray)) or not certificate_der:
            raise TrustMaterialBlocked("certificate material is empty or invalid")
        return hashlib.sha256(bytes(certificate_der)).hexdigest()

    def verify(self, material: PublicTrustMaterial, certificate_der: bytes) -> None:
        if not material.anchor_id.strip() or not material.subject.strip():
            raise TrustMaterialBlocked("trust anchor identity required")
        if material.revoked or not material.active:
            raise TrustMaterialBlocked("trust anchor inactive or revoked")
        expected = self.fingerprint(certificate_der)
        if material.sha256_fingerprint.lower() != expected:
            raise TrustMaterialBlocked("trust anchor fingerprint mismatch")
        if "PRIVATE KEY" in material.subject.upper():
            raise TrustMaterialBlocked("private key material cannot be trust metadata")

    @staticmethod
    def client_metadata(material: PublicTrustMaterial) -> dict[str, str]:
        """Export only public trust metadata; no private credential fields."""
        return {
            "anchor_id": material.anchor_id,
            "subject": material.subject,
            "sha256_fingerprint": material.sha256_fingerprint,
        }
