"""Public trust-material boundary for release clients."""
