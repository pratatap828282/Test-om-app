"""Fresh data lifecycle controls for the OM Investing System.

Hot-path trading data stays minimal and fast.  Temporary/cache/research data
may be compacted under policy, while financial/audit evidence is protected.
Cleanup is represented as a bounded, non-trading operation so it cannot block
or mutate execution state.
"""
from dataclasses import dataclass
from enum import Enum


class DataClass(str, Enum):
    FINANCIAL_EVIDENCE = "FINANCIAL_EVIDENCE"
    AUDIT_EVIDENCE = "AUDIT_EVIDENCE"
    ORDER_STATE = "ORDER_STATE"
    MARKET_HOT = "MARKET_HOT"
    RESEARCH_CACHE = "RESEARCH_CACHE"
    TEMPORARY = "TEMPORARY"


class CleanupBlocked(PermissionError):
    pass


@dataclass(frozen=True)
class DataRecord:
    record_id: str
    data_class: DataClass
    age_days: int
    integrity_valid: bool = True
    active_order_reference: bool = False


@dataclass(frozen=True)
class CleanupPlan:
    record_ids: tuple[str, ...]
    trading_blocking: bool = False


class DataLifecycleManager:
    """Policy engine; it never deletes protected financial/audit evidence."""

    COMPACTION_CYCLE_DAYS = 30
    HOT_PATH_MAX_AGE_DAYS = 1

    PROTECTED = frozenset({
        DataClass.FINANCIAL_EVIDENCE,
        DataClass.AUDIT_EVIDENCE,
        DataClass.ORDER_STATE,
    })
    CLEANABLE = frozenset({
        DataClass.RESEARCH_CACHE,
        DataClass.TEMPORARY,
    })

    def plan_cleanup(self, records: list[DataRecord], now_age_days: int = 0) -> CleanupPlan:
        if now_age_days < 0:
            raise CleanupBlocked("invalid cleanup age")
        selected: list[str] = []
        for record in records:
            if not record.record_id.strip() or record.age_days < 0:
                raise CleanupBlocked("invalid data record")
            if not record.integrity_valid:
                raise CleanupBlocked("invalid/tampered data cannot be cleaned")
            if record.active_order_reference:
                continue
            if record.data_class in self.PROTECTED:
                continue
            if record.data_class in self.CLEANABLE and record.age_days >= self.COMPACTION_CYCLE_DAYS:
                selected.append(record.record_id)
        return CleanupPlan(tuple(selected), trading_blocking=False)

    def can_cleanup_without_trading_block(self, plan: CleanupPlan) -> bool:
        return not plan.trading_blocking

    def classify(self, data_class: DataClass) -> str:
        if data_class in self.PROTECTED:
            return "RETAIN"
        if data_class in self.CLEANABLE:
            return "COMPACT_OR_DELETE"
        if data_class is DataClass.MARKET_HOT:
            return "MINIMIZE_HOT_PATH"
        raise CleanupBlocked("unknown data class")
