"""Gate 33: primary/Plan-B server selection and execution-owner fencing."""
from dataclasses import dataclass

from backend.core.master_contract import MASTER_CONTRACT


class FleetControlBlocked(PermissionError):
    pass


@dataclass(frozen=True)
class ServerNode:
    node_id: str
    region: str
    authorized: bool = True
    healthy: bool = True
    feed_ok: bool = True
    broker_ok: bool = True
    latency_ns: int = 0
    jitter_ns: int = 0
    priority: int = 0

    def eligible(self) -> bool:
        return all((self.authorized, self.healthy, self.feed_ok, self.broker_ok))


class ServerFleet:
    """Keeps Singapore primary in normal operation; selects Plan-B only on incident."""

    PRIMARY = MASTER_CONTRACT.server_priority[0]
    PLAN_B = MASTER_CONTRACT.server_priority[1:]

    def select(self, nodes: list[ServerNode], failover: bool = False) -> ServerNode:
        if not nodes:
            raise FleetControlBlocked("no server nodes available")
        if not failover:
            primary = [n for n in nodes if n.region == self.PRIMARY and n.eligible()]
            if not primary:
                raise FleetControlBlocked("healthy authorized Singapore primary required")
            return sorted(primary, key=lambda n: (n.latency_ns, n.jitter_ns, n.priority, n.node_id))[0]
        candidates = [n for n in nodes if n.region in self.PLAN_B and n.eligible()]
        if not candidates:
            raise FleetControlBlocked("no eligible Plan-B server")
        return sorted(candidates, key=lambda n: (n.latency_ns, n.jitter_ns, n.priority, n.node_id))[0]


@dataclass
class ExecutionOwner:
    active_node_id: str | None = None
    fencing_epoch: int = 0

    def acquire(self, node: ServerNode) -> int:
        if not node.eligible():
            raise FleetControlBlocked("ineligible node cannot acquire execution ownership")
        if self.active_node_id is not None and self.active_node_id != node.node_id:
            raise FleetControlBlocked("execution ownership already held")
        if self.active_node_id is None:
            self.active_node_id = node.node_id
            self.fencing_epoch += 1
        return self.fencing_epoch

    def transfer(self, node: ServerNode, *, incident_confirmed: bool, reconciled: bool) -> int:
        if not incident_confirmed:
            raise FleetControlBlocked("confirmed primary incident required")
        if not reconciled:
            raise FleetControlBlocked("broker/order reconciliation required")
        if not node.eligible() or node.region not in ServerFleet.PLAN_B:
            raise FleetControlBlocked("eligible Plan-B node required")
        self.active_node_id = node.node_id
        self.fencing_epoch += 1
        return self.fencing_epoch

    def assert_owner(self, node_id: str, epoch: int) -> None:
        if node_id != self.active_node_id or epoch != self.fencing_epoch:
            raise FleetControlBlocked("stale or non-owner execution authority")
