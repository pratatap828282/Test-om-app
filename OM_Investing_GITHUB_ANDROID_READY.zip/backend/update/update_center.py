"""Fresh controlled Update Center: staging-only import and fail-closed activation."""
from dataclasses import dataclass
from enum import Enum


class UpdateBlocked(PermissionError):
    pass


class UpdateStage(str, Enum):
    STAGING = "STAGING"
    VALIDATED = "VALIDATED"
    CHECKPOINTED = "CHECKPOINTED"
    ACTIVATED = "ACTIVATED"
    ROLLED_BACK = "ROLLED_BACK"


@dataclass(frozen=True)
class UpdateCandidate:
    version: str
    target: str
    payload_integrity_valid: bool
    security_valid: bool
    compatibility_valid: bool
    master_target_unchanged: bool
    authorized: bool


@dataclass
class UpdateCenter:
    stage: UpdateStage = UpdateStage.STAGING
    _candidate: UpdateCandidate | None = None
    _checkpointed: bool = False

    def import_to_staging(self, candidate: UpdateCandidate) -> None:
        if not candidate.version.strip():
            raise UpdateBlocked("version is required")
        if candidate.target != "S1_TO_1T":
            raise UpdateBlocked("Master Target cannot be changed by update")
        self._candidate = candidate
        self.stage = UpdateStage.STAGING
        self._checkpointed = False

    def validate(self) -> None:
        if self._candidate is None:
            raise UpdateBlocked("no staged update")
        c = self._candidate
        if not all((c.payload_integrity_valid, c.security_valid,
                    c.compatibility_valid, c.master_target_unchanged,
                    c.authorized)):
            self.stage = UpdateStage.STAGING
            raise UpdateBlocked("update validation failed")
        self.stage = UpdateStage.VALIDATED

    def checkpoint(self) -> None:
        if self.stage is not UpdateStage.VALIDATED:
            raise UpdateBlocked("checkpoint requires validated update")
        self._checkpointed = True
        self.stage = UpdateStage.CHECKPOINTED

    def activate(self) -> None:
        if self.stage is not UpdateStage.CHECKPOINTED or not self._checkpointed:
            raise UpdateBlocked("activation requires validation and checkpoint")
        self.stage = UpdateStage.ACTIVATED

    def rollback(self) -> None:
        self.stage = UpdateStage.ROLLED_BACK
        self._candidate = None
        self._checkpointed = False
