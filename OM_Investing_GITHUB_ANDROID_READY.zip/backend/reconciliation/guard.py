"""Fresh fail-closed broker/account reconciliation guard."""
from backend.broker.contract import BrokerSnapshot, BrokerBoundaryError

class ReconciliationGuard:
    @staticmethod
    def require_ready(snapshot: BrokerSnapshot, client_order_id: str) -> None:
        if not snapshot.connected:
            raise BrokerBoundaryError("broker is not connected")
        if not snapshot.reconciled:
            raise BrokerBoundaryError("broker/account reconciliation is not valid")
        if not snapshot.account_id:
            raise BrokerBoundaryError("broker account identity is required")
        if snapshot.equity < 0:
            raise BrokerBoundaryError("invalid broker equity")
        if client_order_id in snapshot.open_order_ids:
            raise BrokerBoundaryError("existing broker order identity blocks duplicate submission")
