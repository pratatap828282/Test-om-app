"""Controlled research/self-improvement pipeline for the fresh system."""
from dataclasses import dataclass
from enum import Enum

class ImprovementStage(str, Enum):
    RESEARCH = "RESEARCH"
    ANALYZED = "ANALYZED"
    CORRELATED = "CORRELATED"
    CANDIDATE = "CANDIDATE"
    TESTED = "TESTED"
    VALIDATED = "VALIDATED"
    AUTHORIZED = "AUTHORIZED"
    STAGED = "STAGED"
    HEALTH_VERIFIED = "HEALTH_VERIFIED"
    ACTIVATED = "ACTIVATED"
    REJECTED = "REJECTED"

class ImprovementBlocked(PermissionError):
    pass

@dataclass(frozen=True)
class ImprovementCandidate:
    candidate_id: str
    research_complete: bool
    analysis_complete: bool
    correlation_complete: bool
    tests_passed: bool
    validation_passed: bool
    security_valid: bool
    integrity_valid: bool
    master_target_unchanged: bool
    authorized: bool
    health_verified: bool = False

class SelfImprovementGate:
    def __init__(self):
        self.stage = ImprovementStage.RESEARCH
        self._candidate = None

    def submit(self, candidate: ImprovementCandidate):
        if not candidate.candidate_id.strip():
            raise ImprovementBlocked("candidate identity required")
        self._candidate = candidate
        self.stage = ImprovementStage.RESEARCH

    def advance(self, stage: ImprovementStage):
        if self._candidate is None:
            raise ImprovementBlocked("no improvement candidate")
        c = self._candidate
        requirements = {
            ImprovementStage.ANALYZED: c.research_complete and c.analysis_complete,
            ImprovementStage.CORRELATED: c.correlation_complete,
            ImprovementStage.CANDIDATE: True,
            ImprovementStage.TESTED: c.tests_passed,
            ImprovementStage.VALIDATED: c.validation_passed,
            ImprovementStage.AUTHORIZED: c.security_valid and c.integrity_valid and c.master_target_unchanged and c.authorized,
            ImprovementStage.STAGED: True,
            ImprovementStage.HEALTH_VERIFIED: c.health_verified,
            ImprovementStage.ACTIVATED: c.health_verified,
        }
        if stage is ImprovementStage.REJECTED:
            self.stage = stage
            return
        if stage not in requirements or not requirements[stage]:
            raise ImprovementBlocked(f"improvement cannot advance to {stage.value}")
        order = list(ImprovementStage)[:10]
        if order.index(stage) < order.index(self.stage):
            raise ImprovementBlocked("stage regression is blocked")
        self.stage = stage
