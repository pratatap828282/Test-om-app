"""Gate 45: authoritative Decision Engine provenance seal.

Only the Decision Engine can mint an execution-authority seal.  A plain
Decision object, including one constructed by support/advisory code, is not
sufficient proof of authoritative decision provenance.
"""
from dataclasses import dataclass
from typing import Final
from .decision_contract import Decision

class DecisionAuthorityBlocked(PermissionError):
    """Raised when an unsealed or invalid decision crosses into execution."""

_SEAL_CAPABILITY: Final = object()

@dataclass(frozen=True)
class DecisionSeal:
    decision: Decision
    _capability: object

    def __getattr__(self, name: str):
        # Backward-compatible read-only view; authority remains sealed.
        return getattr(self.decision, name)

class DecisionAuthority:
    @staticmethod
    def issue(decision: Decision, capability: object) -> DecisionSeal:
        if capability is not _SEAL_CAPABILITY:
            raise DecisionAuthorityBlocked("only the authoritative Decision Engine may issue a seal")
        decision.authorize()
        return DecisionSeal(decision, _SEAL_CAPABILITY)

    @staticmethod
    def validate(seal: DecisionSeal) -> Decision:
        if not isinstance(seal, DecisionSeal) or seal._capability is not _SEAL_CAPABILITY:
            raise DecisionAuthorityBlocked("invalid or unsealed decision authority")
        seal.decision.authorize()
        return seal.decision

    @staticmethod
    def capability() -> object:
        """Internal capability; callers must not receive it through public API."""
        raise DecisionAuthorityBlocked("decision authority capability is engine-private")

# Private engine-only hook. Kept in this module so advisory/support code has no
# public minting API or transferable capability.
def _engine_capability() -> object:
    return _SEAL_CAPABILITY
