"""Gate 44: advisory-to-decision integration firewall.

Assistant information may be carried as non-authoritative context, but it can
never populate or strengthen the authoritative decision prerequisites.
"""
from dataclasses import dataclass, replace
from backend.support.assistant_boundary import Advisory, AssistantBoundary
from .decision_engine import DecisionInput


class AdvisoryIntegrationBlocked(PermissionError):
    """Raised when advisory data attempts to cross the authority boundary."""


@dataclass(frozen=True)
class AdvisoryContext:
    topic: str
    content: bytes
    source: str = "ASSISTANT"


class AdvisoryDecisionBridge:
    """Attach validated advisory context without changing decision authority."""

    def __init__(self, boundary: AssistantBoundary | None = None):
        self._boundary = boundary or AssistantBoundary()

    def attach(self, decision: DecisionInput, advisory: Advisory) -> tuple[DecisionInput, AdvisoryContext]:
        self._boundary.validate_advisory(advisory)
        if decision.validated or decision.reconciled or decision.analysis_complete:
            # Existing authoritative state remains untouched; advisory cannot
            # upgrade, downgrade, or replace any prerequisite.
            pass
        context = AdvisoryContext(advisory.topic, advisory.content)
        return replace(decision), context

    @staticmethod
    def authorize_from_advisory(*_args, **_kwargs) -> None:
        raise AdvisoryIntegrationBlocked(
            "Assistant advisory cannot authorize a financial decision"
        )

    @staticmethod
    def promote_to_execution(*_args, **_kwargs) -> None:
        raise AdvisoryIntegrationBlocked(
            "Assistant advisory cannot be promoted to execution authority"
        )
