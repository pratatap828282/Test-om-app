"""Authoritative decision contract for the fresh rebuild."""
from dataclasses import dataclass
from enum import Enum
from backend.core.master_contract import TradingMode

class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"

@dataclass(frozen=True)
class Decision:
    symbol: str
    side: Side
    mode: TradingMode
    validated: bool
    reconciled: bool
    risk_valid: bool
    analysis_complete: bool

    def authorize(self) -> None:
        if self.symbol != "XAUUSD":
            raise ValueError("only XAUUSD can receive an execution decision")
        if not self.validated or not self.reconciled or not self.risk_valid or not self.analysis_complete:
            raise ValueError("decision prerequisites are incomplete")
        if self.side not in (Side.BUY, Side.SELL):
            raise ValueError("invalid execution side")
