"""Authoritative, fail-closed decision gate for XAUUSD."""
from dataclasses import dataclass
from .decision_contract import Decision, Side
from .decision_authority import DecisionAuthority, DecisionSeal, _engine_capability
from .market_contract import MarketAnalysisContract
from backend.core.master_contract import TradingMode
from backend.core.invariants import validate_feed_age, validate_trade_risk

@dataclass(frozen=True)
class DecisionInput:
    analysis: MarketAnalysisContract
    side: Side
    mode: TradingMode
    validated: bool
    reconciled: bool
    risk_fraction: float
    feed_age_seconds: float
    analysis_complete: bool

class DecisionEngine:
    def authorize(self, item: DecisionInput) -> DecisionSeal:
        item.analysis.validate()
        validate_feed_age(item.feed_age_seconds)
        validate_trade_risk(item.risk_fraction)
        if not item.validated or not item.reconciled or not item.analysis_complete:
            raise ValueError("decision prerequisites are incomplete")
        if not item.analysis.execution_eligible_symbol:
            raise ValueError("analysis-only symbol cannot execute")
        decision = Decision(item.analysis.symbol, item.side, item.mode,
                            item.validated, item.reconciled,
                            True, item.analysis_complete)
        return DecisionAuthority.issue(decision, _engine_capability())
