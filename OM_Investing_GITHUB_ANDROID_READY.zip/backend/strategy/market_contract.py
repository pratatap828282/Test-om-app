"""Fresh market-analysis contract; no legacy implementation dependencies."""
from dataclasses import dataclass
from backend.core.master_contract import MASTER_CONTRACT

@dataclass(frozen=True)
class MarketAnalysisContract:
    symbol: str
    timeframe: str
    candle_pattern: str | None = None
    trend: str | None = None
    cross_signal: str | None = None
    fibonacci_signal: str | None = None
    cpi_context: str | None = None
    dxy_context: str | None = None

    def validate(self) -> None:
        if self.symbol not in (MASTER_CONTRACT.live_symbol, *MASTER_CONTRACT.analysis_only_symbols):
            raise ValueError("unsupported analysis symbol")
        if self.timeframe not in MASTER_CONTRACT.supported_timeframes:
            raise ValueError("unsupported timeframe")
        if self.symbol == MASTER_CONTRACT.live_symbol and self.dxy_context is not None:
            # DXY may inform analysis, but it never changes execution scope.
            return

    @property
    def execution_eligible_symbol(self) -> bool:
        return self.symbol == MASTER_CONTRACT.live_symbol

    @property
    def preferred_entry_timeframe(self) -> bool:
        return self.timeframe in MASTER_CONTRACT.preferred_entry_timeframes
