"""Fresh Gate 17 activation controller: owner + integrity + reconciliation."""
from dataclasses import dataclass
from backend.audit.ledger import AuditLedger
from backend.broker.contract import BrokerSnapshot
from backend.reconciliation.guard import ReconciliationGuard
from backend.security.owner_auth import OwnerAuthenticator
from .deploy_gate import DeploymentEvidence, DeploymentGate, DeploymentBlocked, DeploymentStage

@dataclass
class ActivationController:
    gate: DeploymentGate
    ledger: AuditLedger
    auth: OwnerAuthenticator

    def activate(self, now: float, snapshot: BrokerSnapshot) -> None:
        if self.gate.stage is not DeploymentStage.STAGING:
            raise DeploymentBlocked("activation requires a fresh staged verification")
        try:
            self.auth.require_authenticated(now)
            self.ledger.require_integrity()
            ReconciliationGuard.require_ready(snapshot, "__activation__")
            self.gate.verify(DeploymentEvidence(
                owner_authenticated=True,
                integrity_valid=True,
                compatibility_valid=True,
                master_target_valid=True,
                health_valid=True,
                backup_checkpoint_valid=True,
            ))
            self.ledger.append("DEPLOYMENT_ACTIVATION_AUTHORIZED", {"account_id": snapshot.account_id})
            self.gate.activate()
        except DeploymentBlocked:
            raise
        except Exception as exc:
            self.gate.stage = DeploymentStage.STAGING
            raise DeploymentBlocked("activation blocked") from exc

    def safe_activate(self, now: float, snapshot: BrokerSnapshot) -> bool:
        try:
            self.activate(now, snapshot)
            return True
        except Exception as exc:
            self.gate.stage = self.gate.stage if self.gate.stage is not None else self.gate.stage
            raise DeploymentBlocked("activation blocked") from exc
