"""Gate 36: final live-release decision composition.

Combines the already-separated certification, external-evidence completeness,
and staged-deployment boundaries.  This gate never manufactures live evidence.
"""
from dataclasses import dataclass

from backend.certification.certification_gate import CertificationEvidence, CertificationGate, OperationScope
from backend.deployment.external_evidence_gate import ExternalEvidence, ExternalEvidenceGate, LiveReleaseBlocked
from backend.deployment.deploy_gate import DeploymentStage


@dataclass(frozen=True)
class LiveReleaseDecision:
    ready: bool
    reason: str


class LiveReleaseGate:
    """Fail closed unless every independent live-release boundary is satisfied."""

    def __init__(self, certification=None, evidence=None):
        self.certification = certification or CertificationGate()
        self.evidence = evidence or ExternalEvidenceGate()

    def assess(self, *, stage: DeploymentStage, certification: CertificationEvidence,
               external: ExternalEvidence) -> LiveReleaseDecision:
        if stage is not DeploymentStage.STAGING:
            return LiveReleaseDecision(False, "live release requires staged state")
        cert = self.certification.certify(OperationScope.DEPLOYMENT, certification)
        if not cert.certified:
            return LiveReleaseDecision(False, cert.reason)
        report = self.evidence.assess(external)
        if not report.ready_for_live:
            return LiveReleaseDecision(False, "live release requires complete verified external evidence")
        return LiveReleaseDecision(True, "ready_for_live")

    def require_ready(self, *, stage: DeploymentStage, certification: CertificationEvidence,
                      external: ExternalEvidence) -> None:
        decision = self.assess(stage=stage, certification=certification, external=external)
        if not decision.ready:
            raise LiveReleaseBlocked(decision.reason)
