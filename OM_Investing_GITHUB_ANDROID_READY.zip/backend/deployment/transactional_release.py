"""Gate 39: transactional release state and safe rollback boundary."""
from dataclasses import dataclass
from enum import Enum


class ReleaseBlocked(PermissionError):
    pass


class ReleaseStage(str, Enum):
    STAGING = "STAGING"
    VERIFIED = "VERIFIED"
    CHECKPOINTED = "CHECKPOINTED"
    ACTIVATED = "ACTIVATED"
    ROLLED_BACK = "ROLLED_BACK"


@dataclass(frozen=True)
class ReleaseSnapshot:
    release_id: str
    integrity_valid: bool
    compatibility_valid: bool
    master_target_valid: bool
    health_valid: bool


@dataclass
class TransactionalRelease:
    stage: ReleaseStage = ReleaseStage.STAGING
    _snapshot: ReleaseSnapshot | None = None
    _checkpoint: ReleaseSnapshot | None = None

    def stage_release(self, snapshot: ReleaseSnapshot) -> None:
        if not snapshot.release_id.strip():
            raise ReleaseBlocked("release identity is required")
        self._snapshot = snapshot
        self._checkpoint = None
        self.stage = ReleaseStage.STAGING

    def verify(self) -> None:
        if self._snapshot is None:
            raise ReleaseBlocked("no staged release")
        s = self._snapshot
        if not all((s.integrity_valid, s.compatibility_valid,
                    s.master_target_valid, s.health_valid)):
            self.stage = ReleaseStage.STAGING
            raise ReleaseBlocked("release verification failed")
        self.stage = ReleaseStage.VERIFIED

    def checkpoint(self) -> None:
        if self.stage is not ReleaseStage.VERIFIED or self._snapshot is None:
            raise ReleaseBlocked("checkpoint requires verified release")
        self._checkpoint = self._snapshot
        self.stage = ReleaseStage.CHECKPOINTED

    def activate(self) -> None:
        if self.stage is not ReleaseStage.CHECKPOINTED or self._checkpoint is None:
            raise ReleaseBlocked("activation requires checkpoint")
        self.stage = ReleaseStage.ACTIVATED

    def rollback(self) -> str:
        if self._checkpoint is None:
            self.stage = ReleaseStage.STAGING
            self._snapshot = None
            raise ReleaseBlocked("rollback requires a verified checkpoint")
        restored_id = self._checkpoint.release_id
        self._snapshot = self._checkpoint
        self.stage = ReleaseStage.ROLLED_BACK
        return restored_id

    @property
    def checkpointed(self) -> bool:
        return self._checkpoint is not None
