"""Post-Gate-20 external-evidence boundary.

This gate verifies that the live-release evidence contract is explicit and fail-closed.
It does not manufacture evidence from local tests.
"""
from dataclasses import dataclass
from enum import Enum


class EvidenceState(str, Enum):
    MISSING = "missing"
    VERIFIED = "verified"
    REJECTED = "rejected"


class LiveReleaseBlocked(PermissionError):
    pass


@dataclass(frozen=True)
class ExternalEvidence:
    broker: EvidenceState = EvidenceState.MISSING
    primary_server: EvidenceState = EvidenceState.MISSING
    plan_b_servers: EvidenceState = EvidenceState.MISSING
    network: EvidenceState = EvidenceState.MISSING
    device: EvidenceState = EvidenceState.MISSING
    market_feed: EvidenceState = EvidenceState.MISSING
    blockchain: EvidenceState = EvidenceState.MISSING

    def complete(self) -> bool:
        return all(state is EvidenceState.VERIFIED for state in (
            self.broker, self.primary_server, self.plan_b_servers,
            self.network, self.device, self.market_feed, self.blockchain,
        ))


@dataclass(frozen=True)
class EvidenceReport:
    ready_for_live: bool
    missing: tuple[str, ...]
    rejected: tuple[str, ...]


class ExternalEvidenceGate:
    FIELDS = (
        "broker", "primary_server", "plan_b_servers", "network",
        "device", "market_feed", "blockchain",
    )

    def assess(self, evidence: ExternalEvidence) -> EvidenceReport:
        missing = tuple(name for name in self.FIELDS
                        if getattr(evidence, name) is EvidenceState.MISSING)
        rejected = tuple(name for name in self.FIELDS
                         if getattr(evidence, name) is EvidenceState.REJECTED)
        return EvidenceReport(
            ready_for_live=not missing and not rejected,
            missing=missing,
            rejected=rejected,
        )

    def require_live(self, evidence: ExternalEvidence) -> None:
        report = self.assess(evidence)
        if not report.ready_for_live:
            raise LiveReleaseBlocked(
                "live release blocked: external evidence incomplete or rejected"
            )
