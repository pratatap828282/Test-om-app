"""Fresh Gate 18 release boundary for controlled-to-live promotion."""
from dataclasses import dataclass
from enum import Enum

class ReleaseStage(str, Enum):
    STAGING = "staging"
    PRODUCTION = "production"

class ReleaseBlocked(PermissionError):
    pass

@dataclass(frozen=True)
class ExternalReleaseEvidence:
    broker_verified: bool
    deployment_verified: bool
    network_verified: bool
    device_verified: bool

    def complete(self) -> bool:
        return all((self.broker_verified, self.deployment_verified,
                    self.network_verified, self.device_verified))

@dataclass(frozen=True)
class ReleaseManifest:
    target: str
    version: str
    stage: ReleaseStage
    live: bool = False

class ReleaseGate:
    REQUIRED_CHECKS = (
        "security", "integrity", "compatibility", "master_target",
        "owner_auth", "health", "backup_checkpoint"
    )

    def evaluate(self, manifest: ReleaseManifest, checks: dict[str, bool],
                 owner_authenticated: bool, target_validated: bool,
                 health_verified: bool, external_evidence: ExternalReleaseEvidence | None = None) -> bool:
        if manifest.target != "S1_TO_1T":
            raise ReleaseBlocked("invalid Master Target")
        if not manifest.version.strip():
            raise ReleaseBlocked("release version is required")
        if not all(checks.get(k, False) for k in self.REQUIRED_CHECKS):
            raise ReleaseBlocked("release checks incomplete")
        if not (owner_authenticated and target_validated and health_verified):
            raise ReleaseBlocked("release authorization/health prerequisites incomplete")
        if manifest.live:
            if manifest.stage is not ReleaseStage.PRODUCTION:
                raise ReleaseBlocked("live release requires production stage")
            if external_evidence is None or not external_evidence.complete():
                raise ReleaseBlocked("external release evidence incomplete")
        return True
