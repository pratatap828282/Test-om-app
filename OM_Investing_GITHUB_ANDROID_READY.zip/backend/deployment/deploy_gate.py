"""Fresh deployment authorization boundary for OM Investing System."""
from dataclasses import dataclass
from enum import Enum


class DeploymentStage(str, Enum):
    STAGING = "STAGING"
    VERIFIED = "VERIFIED"
    ACTIVATED = "ACTIVATED"
    ROLLED_BACK = "ROLLED_BACK"


class DeploymentBlocked(PermissionError):
    pass


@dataclass(frozen=True)
class DeploymentEvidence:
    owner_authenticated: bool
    integrity_valid: bool
    compatibility_valid: bool
    master_target_valid: bool
    health_valid: bool
    backup_checkpoint_valid: bool


@dataclass
class DeploymentGate:
    stage: DeploymentStage = DeploymentStage.STAGING

    def verify(self, evidence: DeploymentEvidence) -> None:
        if not all((evidence.owner_authenticated, evidence.integrity_valid,
                    evidence.compatibility_valid, evidence.master_target_valid,
                    evidence.health_valid, evidence.backup_checkpoint_valid)):
            self.stage = DeploymentStage.STAGING
            raise DeploymentBlocked("deployment verification gate failed")
        self.stage = DeploymentStage.VERIFIED

    def activate(self) -> None:
        if self.stage is not DeploymentStage.VERIFIED:
            raise DeploymentBlocked("activation requires verified deployment")
        self.stage = DeploymentStage.ACTIVATED

    def rollback(self) -> None:
        self.stage = DeploymentStage.ROLLED_BACK
