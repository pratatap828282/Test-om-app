"""Fresh owner authentication contract for protected control operations."""
from dataclasses import dataclass
from enum import Enum
import hashlib
import hmac


class AuthState(str, Enum):
    LOCKED = "LOCKED"
    AUTHENTICATED = "AUTHENTICATED"


class AuthenticationError(RuntimeError):
    pass


@dataclass
class OwnerAuthenticator:
    secret: bytes
    max_failures: int = 5
    lockout_seconds: int = 5 * 60 * 60
    _failures: int = 0
    _locked_until: float = 0.0
    _state: AuthState = AuthState.LOCKED

    def __post_init__(self) -> None:
        if not self.secret or self.max_failures != 5 or self.lockout_seconds != 18000:
            raise ValueError("invalid owner authentication policy")

    @staticmethod
    def _digest(value: str) -> bytes:
        return hashlib.sha256(value.encode("utf-8")).digest()

    def authenticate(self, supplied: str, now: float) -> None:
        if now < self._locked_until:
            self._state = AuthState.LOCKED
            raise AuthenticationError("owner authentication locked")
        if not supplied:
            self._record_failure(now)
            raise AuthenticationError("authentication failed")
        if not hmac.compare_digest(self._digest(supplied), self._digest(self.secret.decode("utf-8"))):
            self._record_failure(now)
            raise AuthenticationError("authentication failed")
        self._failures = 0
        self._locked_until = 0.0
        self._state = AuthState.AUTHENTICATED

    def _record_failure(self, now: float) -> None:
        self._failures += 1
        if self._failures >= self.max_failures:
            self._locked_until = now + self.lockout_seconds
            self._state = AuthState.LOCKED

    def require_authenticated(self, now: float) -> None:
        if now < self._locked_until or self._state is not AuthState.AUTHENTICATED:
            raise AuthenticationError("authenticated owner session required")

    @property
    def state(self) -> AuthState:
        return self._state
