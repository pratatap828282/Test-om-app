"""Secure broker login and automatic post-login metadata capture.

The connector performs authentication.  After successful authentication it
returns the broker/session metadata needed by the system.  Secrets are used
only in-memory for the login operation and are never persisted or returned as
verification evidence.
"""
from dataclasses import dataclass
from typing import Protocol


class BrokerLoginError(RuntimeError):
    pass


@dataclass(frozen=True)
class BrokerLoginDetails:
    broker_name: str
    server: str
    account_id: str

    def validate(self) -> None:
        if not all((self.broker_name.strip(), self.server.strip(), self.account_id.strip())):
            raise BrokerLoginError("broker name, server, and account identity are required")


@dataclass(frozen=True)
class BrokerLoginCredentials:
    """Ephemeral credentials supplied to the connector; never returned/stored by the gate."""
    username: str
    password: str
    platform: str  # MT4, MT5, or Trade W

    def validate(self) -> None:
        if not all((self.username, self.password, self.platform.strip())):
            raise BrokerLoginError("complete broker login credentials are required")
        if self.platform not in {"MT4", "MT5", "Trade W"}:
            raise BrokerLoginError("unsupported broker login platform")


@dataclass(frozen=True)
class VerifiedBrokerSession:
    broker_name: str
    server: str
    account_id: str
    platform: str
    connection_id: str
    authenticated: bool

    @property
    def verified(self) -> bool:
        return self.authenticated


class BrokerConnector(Protocol):
    def login(self, credentials: BrokerLoginCredentials) -> BrokerLoginDetails:
        """Authenticate and return broker/server/account metadata from the live session."""

    def connection_evidence(self, details: BrokerLoginDetails) -> str:
        """Return a non-secret connection/evidence ID."""


class BrokerLoginGate:
    """Authenticate once and automatically capture verified session metadata.

    The password/API token/private credential is passed only to the connector
    for authentication.  It is never persisted, logged, or included in the
    returned session/evidence object.
    """

    def __init__(self, connector: BrokerConnector) -> None:
        self._connector = connector

    def login_and_capture(self, credentials: BrokerLoginCredentials) -> VerifiedBrokerSession:
        credentials.validate()
        try:
            details = self._connector.login(credentials)
            details.validate()
            evidence_id = self._connector.connection_evidence(details)
        except BrokerLoginError:
            raise
        except Exception as exc:
            raise BrokerLoginError("broker login or verification failed") from exc
        if not evidence_id or not evidence_id.strip():
            raise BrokerLoginError("broker connector returned no verification evidence")
        return VerifiedBrokerSession(
            broker_name=details.broker_name,
            server=details.server,
            account_id=details.account_id,
            platform=credentials.platform,
            connection_id=evidence_id,
            authenticated=True,
        )

    # Backward-compatible verification entry point for non-secret metadata.
    def verify_at_login(self, details: BrokerLoginDetails) -> VerifiedBrokerSession:
        details.validate()
        try:
            if hasattr(self._connector, "verify"):
                evidence_id = self._connector.verify(details)
            else:
                evidence_id = self._connector.connection_evidence(details)
        except Exception as exc:
            raise BrokerLoginError("broker verification failed") from exc
        if not evidence_id or not evidence_id.strip():
            raise BrokerLoginError("broker verifier returned no evidence")
        return VerifiedBrokerSession(
            broker_name=details.broker_name,
            server=details.server,
            account_id=details.account_id,
            platform="UNKNOWN",
            connection_id=evidence_id,
            authenticated=True,
        )
