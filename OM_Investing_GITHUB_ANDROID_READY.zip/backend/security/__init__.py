"""Fresh owner-security boundary."""
