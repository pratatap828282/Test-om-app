"""Authorization boundary: authentication never grants financial authority by itself."""
from dataclasses import dataclass
from .owner_auth import OwnerAuthenticator

@dataclass(frozen=True)
class ProtectedOperation:
    name: str
    owner_authenticated: bool
    integrity_valid: bool

    def authorize(self) -> None:
        if not self.name.strip():
            raise ValueError("operation name is required")
        if not self.owner_authenticated:
            raise PermissionError("owner authentication required")
        if not self.integrity_valid:
            raise PermissionError("integrity validation required")


def require_owner_for_control(auth: OwnerAuthenticator, now: float) -> None:
    auth.require_authenticated(now)
