from dataclasses import dataclass
from decimal import Decimal
from .wallet import WalletDestination, OwnerWallet

D = Decimal

class WithdrawalBlocked(PermissionError):
    pass

@dataclass(frozen=True)
class WithdrawalRequest:
    asset: str
    network: str
    destination: str
    gross_amount: D
    fees: D
    fee_margin: D = D('0')

@dataclass(frozen=True)
class WithdrawalResult:
    delivered_amount: D
    final_net_profit: D
    destination: WalletDestination
    tx_confirmed: bool

class TreasuryWithdrawalEngine:
    """Authorized treasury settlement; no covert/unregistered routing is permitted."""
    def __init__(self, owner_wallet: OwnerWallet):
        self.owner_wallet = owner_wallet

    def prepare(self, request: WithdrawalRequest):
        gross, fees, margin = map(lambda x: D(str(x)), (request.gross_amount, request.fees, request.fee_margin))
        if gross <= 0 or fees < 0 or margin < 0 or fees > gross:
            raise WithdrawalBlocked('invalid withdrawal amount or fee')
        dest = WalletDestination(request.asset, request.network, request.destination)
        self.owner_wallet.authorize(dest)
        return dest, gross - fees

    def confirm(self, request: WithdrawalRequest, delivered_destination: WalletDestination,
                delivered_amount, tx_confirmed: bool):
        dest, expected_net = self.prepare(request)
        delivered = D(str(delivered_amount))
        if delivered_destination != dest:
            raise WithdrawalBlocked('delivered destination mismatch')
        if not tx_confirmed:
            raise WithdrawalBlocked('transaction confirmation required')
        if delivered < 0 or delivered != expected_net:
            raise WithdrawalBlocked('verified delivered amount does not reconcile with gross-fees')
        return WithdrawalResult(delivered, expected_net, dest, True)
