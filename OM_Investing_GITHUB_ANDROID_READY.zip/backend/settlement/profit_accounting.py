from dataclasses import dataclass
from decimal import Decimal

D = Decimal

class SettlementBlocked(ValueError):
    pass

@dataclass(frozen=True)
class SettlementResult:
    gross_profit: D
    fees: D
    fee_margin_used: D
    final_net_profit: D
    treasury_amount: D
    operating_reserve: D

class ProfitSettlement:
    TREASURY_PCT = D('0.90')
    RESERVE_PCT = D('0.10')

    def settle(self, gross_profit, fees, fee_margin=D('0')) -> SettlementResult:
        gross, fee, margin = map(lambda x: D(str(x)), (gross_profit, fees, fee_margin))
        if gross < 0 or fee < 0 or margin < 0:
            raise SettlementBlocked('invalid settlement amount')
        margin_used = min(fee, margin)
        net = gross - fee
        if net < 0:
            raise SettlementBlocked('net profit cannot be negative')
        treasury = net * self.TREASURY_PCT
        reserve = net * self.RESERVE_PCT
        return SettlementResult(gross, fee, margin_used, net, treasury, reserve)
