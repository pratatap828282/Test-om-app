from dataclasses import dataclass

class WalletBlocked(PermissionError):
    pass

@dataclass(frozen=True)
class WalletDestination:
    asset: str
    network: str
    address: str

class OwnerWallet:
    def __init__(self, allowlist=()):
        self._allowlist = frozenset(allowlist)

    def authorize(self, destination: WalletDestination):
        if not destination.asset or not destination.network or not destination.address:
            raise WalletBlocked('asset, network and address are required')
        if destination not in self._allowlist:
            raise WalletBlocked('destination is not owner-allowlisted')
        return True
