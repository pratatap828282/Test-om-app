"""Support-plane failure cannot stop the primary trading bot."""
from dataclasses import dataclass

@dataclass(frozen=True)
class SupportStatus:
    assistant_healthy: bool
    doctor_healthy: bool

class BotContinuity:
    def trading_dependency_ok(self, support: SupportStatus) -> bool:
        # Assistant/Doctor health is informational for the Bot hot path.
        return True
