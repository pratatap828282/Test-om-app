"""Fresh tamper-evident audit ledger for Gate 12."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Any


class LedgerIntegrityError(RuntimeError):
    pass


@dataclass(frozen=True)
class LedgerRecord:
    sequence: int
    event_type: str
    payload: dict[str, Any]
    previous_hash: str
    record_hash: str


class AuditLedger:
    """In-memory reference ledger with deterministic hash chaining.

    Production persistence/encryption is a later infrastructure concern; this gate
    establishes the integrity contract without importing legacy ledger code.
    """
    GENESIS = "0" * 64

    def __init__(self) -> None:
        self._records: list[LedgerRecord] = []

    @property
    def records(self) -> tuple[LedgerRecord, ...]:
        return tuple(self._records)

    @staticmethod
    def _digest(sequence: int, event_type: str, payload: dict[str, Any], previous_hash: str) -> str:
        body = {
            "sequence": sequence,
            "event_type": event_type,
            "payload": payload,
            "previous_hash": previous_hash,
        }
        encoded = json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()
        return hashlib.sha256(encoded).hexdigest()

    def append(self, event_type: str, payload: dict[str, Any]) -> LedgerRecord:
        if not event_type or not isinstance(payload, dict):
            raise ValueError("event_type and payload are required")
        sequence = len(self._records) + 1
        previous_hash = self._records[-1].record_hash if self._records else self.GENESIS
        record_hash = self._digest(sequence, event_type, payload, previous_hash)
        record = LedgerRecord(sequence, event_type, dict(payload), previous_hash, record_hash)
        self._records.append(record)
        return record

    def verify_integrity(self) -> bool:
        previous_hash = self.GENESIS
        for expected_sequence, record in enumerate(self._records, start=1):
            if record.sequence != expected_sequence:
                raise LedgerIntegrityError("ledger sequence is invalid")
            if record.previous_hash != previous_hash:
                raise LedgerIntegrityError("ledger hash chain is broken")
            expected_hash = self._digest(record.sequence, record.event_type, record.payload, record.previous_hash)
            if record.record_hash != expected_hash:
                raise LedgerIntegrityError("ledger record integrity check failed")
            previous_hash = record.record_hash
        return True

    def require_integrity(self) -> None:
        self.verify_integrity()
